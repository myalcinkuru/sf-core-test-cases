package com.android.fingerprintdialog;

/**
 * Created by metehantoksoy on 7/3/17.
 */
public interface FingerPrintListener {
    void onError();
    void onTimeout();
    void onCancel();
    void onAuthenticated();
    void onLockout();
}