/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */

package com.android.fingerprintdialog;

import android.app.Activity;
import android.app.DialogFragment;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Bundle;
import android.security.keystore.KeyProperties;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;

import io.smartface.SmartfaceDemo.R;

/**
 * A dialog which uses fingerprint APIs to authenticate the user, and falls back to password
 * authentication if fingerprint is not available.
 *
 * Forked from google. Edited to use in Smartface Native Framework
 *
 * Created by metehantoksoy on 7/3/17.
 */
public class FingerprintAuthenticationDialogFragment extends DialogFragment
        implements FingerprintUiHelper.Callback {

    static final String DEFAULT_KEY_NAME = "default_key";
    static final String FINGERPRINT_TAG = "FINGERPRINT_DIALOG";
    private Button mCancelButton;
    private FingerprintManager.CryptoObject mCryptoObject;
    private FingerprintUiHelper mFingerprintUiHelper;
    private Activity mActivity;
    private ArrayList<FingerPrintListener> listeners = new ArrayList<>();
    private int failureCount = 0;
    private int maxFailureCount = 3;
    private KeyStore mKeyStore;
    private KeyGenerator mKeyGenerator;
    private Cipher defaultCipher;
    private FingerprintManager fingerprintManager;
    private TextView mTextView_FingerprintDescription;
    private String mMessage;
    private String mTitle;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Do not create a new Fragment when the Activity is re-created such as orientation changes.
        setRetainInstance(true);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_Dialog);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().setCanceledOnTouchOutside(false);
        getDialog().setTitle(mTitle != null ? mTitle : getString(R.string.sign_in));
        View v = inflater.inflate(R.layout.fingerprint_dialog_container, container, false);
        mCancelButton = (Button) v.findViewById(R.id.cancel_button);
        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(FingerPrintListener listener : listeners){
                    listener.onCancel();
                }
                dismiss();
            }
        });
        mTextView_FingerprintDescription = (TextView) v.findViewById(R.id.fingerprint_description);
        mTextView_FingerprintDescription.setText(mMessage != null ? mMessage : mActivity.getString(R.string.fingerprint_description));

        mFingerprintUiHelper = new FingerprintUiHelper(
                mActivity.getSystemService(FingerprintManager.class),
                (ImageView) v.findViewById(R.id.fingerprint_icon),
                (TextView) v.findViewById(R.id.fingerprint_status), this);

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        mFingerprintUiHelper.startListening(mCryptoObject);
    }

    @Override
    public void onPause() {
        super.onPause();
        mFingerprintUiHelper.stopListening();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        clearFingerPrintListeners();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = getActivity();
        fingerprintManager = mActivity.getSystemService(FingerprintManager.class);
        generateCipher();
    }

    private void generateCipher() {
        try {
            mKeyStore = KeyStore.getInstance("AndroidKeyStore");
        } catch (KeyStoreException e) {
            Log.e(FINGERPRINT_TAG,"Failed to get an instance of KeyStore", e);
            onError();
        }
        try {
            mKeyGenerator = KeyGenerator
                    .getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            Log.e(FINGERPRINT_TAG,"Failed to get an instance of KeyGenerator", e);
            onError();
        }

        try {
            defaultCipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                    + KeyProperties.BLOCK_MODE_CBC + "/"
                    + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            Log.e(FINGERPRINT_TAG,"Failed to get an instance of Cipher", e);
            onError();
        }

        CipherHelper.createKey(mKeyStore, mKeyGenerator, DEFAULT_KEY_NAME, true);
        if (CipherHelper.initCipher(mKeyStore, defaultCipher, DEFAULT_KEY_NAME)) {
            mCryptoObject = new FingerprintManager.CryptoObject(defaultCipher);
        }

    }

    @Override
    public void onAuthenticated() {
        // Callback from FingerprintUiHelper. Authentication was successful.
        failureCount = 0;
        for(FingerPrintListener listener : listeners){
            listener.onAuthenticated();
        }
        dismiss();
    }

    @Override
    public void onError() {
        // Callback from FingerprintUiHelper. Error occurred while authenticating.
        failureCount++;
        if(failureCount < maxFailureCount){
            return;
        }

        for(FingerPrintListener listener : listeners){
            listener.onError();
        }
        dismiss();
    }

    @Override
    public void onTimeout() {
        // Callback from FingerprintUiHelper. Timeout occurred while authenticating.
        failureCount = 0;
        for(FingerPrintListener listener : listeners){
            listener.onTimeout();
        }
        dismiss();
    }

    @Override
    public void onLockout() {
        // Callback from FingerprintUiHelper. Lockout occurred while authenticating.
        failureCount = 0;
        for(FingerPrintListener listener : listeners){
            listener.onLockout();
        }
        dismiss();
    }

    public void setMaxFailureCount(int maxFailureCount){
        this.maxFailureCount = maxFailureCount;
    }

    public void addFingerPrintListener(FingerPrintListener listener){
        listeners.add(listener);
    }

    public void removeFingerPrintListener(FingerPrintListener listener){
        listeners.remove(listener);
    }

    public void setTitle(String title){
        // If user fires this method before show, dialog will be null
        // Store the title and set when onCreateView fired by system.
        if(getDialog() != null){
            getDialog().setTitle(title);
            mTitle = title;
        }
        else{
            mTitle = title;
        }
    }

    public void setMessage(String message){
        // If user fires this method before show(), textview will be null
        // Store the message and set when onCreateView fired by system.
        if(mTextView_FingerprintDescription != null){
            mTextView_FingerprintDescription.setText(message);
            mMessage = message;
        }
        else {
            mMessage = message;
        }
    }

    public void clearFingerPrintListeners(){
        listeners.clear();
    }
}