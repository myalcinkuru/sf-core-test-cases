package io.smartface.android;

import java.lang.ref.WeakReference;

public class WeakHolder {
    private WeakReference<Object> weakRef;

    public WeakHolder (Object obj) {
        weakRef = new WeakReference<Object> (obj);
    }
    public void free() {
        weakRef = null;
    }
    public Object getWeaksObject__N() {
        if (weakRef != null && weakRef.get() != null) {
            return weakRef.get();

        } else {
            return null;
        }
    }

}
