package io.smartface.android.sfcore.ui.listview;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;

public class SFItemTouchHelper extends ItemTouchHelper {

    public SFItemTouchHelper(@NonNull Callback callback) {
        super(callback);
    }
}
