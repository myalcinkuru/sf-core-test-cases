package io.smartface.android.sfcore.net;

import android.util.Log;

import java.io.IOException;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class SFHttpCallback {
    public static Callback getCallback(final SMFJSObject callbacks) {
        return new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                final String message = e.getMessage();
                SpratAndroidActivity.getInstance().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            SMFJSObject jsCallback = callbacks.getProperty("onFailure");
                            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[] { message });
                        } catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final int code = response.code();
                final Headers headers = response.headers();
                final boolean isSuccessful = response.isSuccessful();
                final String message = response.message();
                final ResponseBody body = response.body();
                final byte[] bytes = ((body == null) ? null : body.bytes());

                SpratAndroidActivity.getInstance().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Object[] args = new Object[] { isSuccessful, code, headers, bytes, message };
                            SMFJSObject jsCallback = callbacks.getProperty("onResponse");
                            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, args);
                        } catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }
                });

            }
        };
    }
}
