package io.smartface.android;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Vector;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;

import io.smartface.android.bitmaps.JniBitmapHolder;

public class SpBitmapRef {
    private static final long JNI_HEAP_THRESHOLD_AMOUNT_DIF = 10 * 1024;// remainin
    // kB to
    // free
    // jni
    // memory

    private static HashMap<String, JniBitmapHolder> holders_jni = new
    HashMap<String, JniBitmapHolder>();
    private static HashMap<String, WeakReference<Bitmap>> weakholders_bitmap_jni = new
    HashMap<String, WeakReference<Bitmap>>();
    private static Vector<String> bitmap_orders_jni = new Vector<String>();
    public static HashMap<String, WeakReference<Bitmap>> holders_bitmap = new
    HashMap<String, WeakReference<Bitmap>>();


    // emulator variables
    private static HashMap<String, String> drawawble_paths;
    private static String drawable_size;
    private static String drawable_density;
    private static boolean emulator_setup = false;

    // private static LruCache<String, Bitmap> mMemoryCache;

    private static String density[] = { "ldpi", "mdpi", "hdpi", "xhdpi",
                                        "xxhdpi", "tvdpi"
                                      };
    public static double scaller[] = {0.75, 1, 1.50, 2, 3, 1.33};
    private static String size[] = { "small", "normal", "large", "xlarge" };

    /**
     * implementation is in SpBrResourceManager.cpp
     *
     * @return
     */
    private native static Vector getFileList();

    /**
     * implementation is in SpBrResourceManager.cpp
     *
     * @return
     */
    private native static boolean imageExists (String path);


    private static Bitmap getGarbageBitmap (int w, int h) {
        if (true) {
            return null;
        }

        if (w == 0 || h == 0) {
            return null;
        }

        for (int i = 0; i < bitmap_orders_jni.size(); i++) {
            String path = bitmap_orders_jni.get (i);

            if (!weakholders_bitmap_jni.containsKey (path)) {
                continue;
            }

            WeakReference<Bitmap> weak = weakholders_bitmap_jni.get (path);
            Bitmap b = weak.get();

            if (b != null && b.getWidth() == w && b.getHeight() == h) {
                weakholders_bitmap_jni.remove (path);
                return b;
            }
        }

        return null;
    }

    public static Bitmap getBitmap (SpratAndroidActivity sprat, String path,
                                    int reqWidth, int reqHeight, boolean overrideCache) {
        Bitmap bitmap = null;

        if (path == null || path.equals("")) {
            return null;
        }
        String originalPath = path;
        setupEmulator(sprat);
        path = pathWithoutScheme(path);
        StringBuffer cacheRef = new StringBuffer(path.length() + 20);
        cacheRef.append(path);
        cacheRef.append(':');
        cacheRef.append(reqWidth);
        cacheRef.append('x');
        cacheRef.append(reqHeight);


        // we're caching based on path and dimensions here
        WeakReference<Bitmap> bitmapRef = holders_bitmap.get(cacheRef.toString());

        if (bitmapRef != null && !overrideCache) {
            bitmap = bitmapRef.get();

            if (bitmap == null) {
                if (holders_bitmap.containsKey(cacheRef.toString())) {
                    holders_bitmap.remove(cacheRef.toString());
                }
            }
        }
        if (bitmap == null) {
            String imagePath = originalPath;
            boolean fromResources = false;
            if (imagePath.startsWith("images://") || !imagePath.contains("/")) {
                imagePath = pathWithoutScheme(imagePath);
                fromResources = true;
            }
            if (fromResources) {
                if (imagePath.contains(".")) {
                    imagePath = imagePath.substring(0, imagePath.indexOf('.'));
                }

                imagePath = imagePath.toLowerCase();
                Context context = SpratAndroidActivity.getInstance();
                int id = context.getResources().getIdentifier(imagePath, "drawable",
                        context.getPackageName());
                if (id != 0) {
                    bitmap = decodeSampledBitmapFromResource(context.getResources(), id, reqWidth, reqHeight);
                }
            }
            if (bitmap == null && originalPath.startsWith("assets://")) {
                InputStream inputStream = null;
                try {
                    String imgPath = pathWithoutScheme(originalPath);
                    String imageRauPath = SpratAndroidActivity.getInstance().getFilesDir()+"/system/rau/assets/"+imgPath;
                    File rauImage = new File(imageRauPath);
                    if(rauImage.exists()) {
                        bitmap = decodeSampledBitmapFromResource(imageRauPath, reqWidth, reqHeight);
                    } else {
                        inputStream = sprat.getAssets().open(imgPath);
                        bitmap = decodeSampledBitmapFromResource(inputStream, reqWidth, reqHeight);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }


            if (bitmap == null) {
                try {
                    String decodedPath = originalPath;

                    Uri pathUri = Uri.parse (originalPath);
                    if (pathUri != null) {
                        decodedPath = pathUri.getPath ();
                    }

                    File f = new File(decodedPath);
                    if (f.exists()) {
                        bitmap = decodeSampledBitmapFromResource(decodedPath, reqWidth, reqHeight);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (bitmap == null && sprat.isemulator && !sprat.isScannerEmulator) {
                Log.e("SpBitmapRef", "path  " + path);
                String src_path = getEmulatorPath(sprat, path);


                if (src_path != null) {
                    bitmap = BitmapFactory.decodeFile(src_path);
                } else {
                    if (path.startsWith("assets://"))
                        src_path = sprat.getUnsecureDbPath__N() + "/assets/" + path.substring("assets://".length());
                    else
                        src_path = sprat.getUnsecureDbPath__N() + "/assets/" + path;

                    Log.e("SpBitmapRef", "src_path  " + src_path);
                    bitmap = BitmapFactory.decodeFile(src_path);
                }
            }
        }

        if (bitmapRef == null && bitmap != null) {
            bitmapRef = new WeakReference<Bitmap>(bitmap);
            holders_bitmap.put(cacheRef.toString(), bitmapRef);
            //bitmap.prepareToDraw();
        }
        if (bitmap == null) {
            System.out.println("image not found=" + path);
        }

        return bitmap;
    }

    public static boolean pictureIsInCache (String path) {
        boolean retval;

        if (path != null && path.contains ("://")) {
            path = path.substring (path.indexOf ("://") + 3);
        }

        if (holders_bitmap.containsKey (path) && holders_bitmap.get (path).get() != null) {
            retval = true;

        } else if (weakholders_bitmap_jni.containsKey (path) &&
                   weakholders_bitmap_jni.get (path).get() != null) {
            retval = true;

        } else {
            retval = false;
        }

        return retval;
    }
    private static void checkNDKMemory (Activity sprat, String path) {
        MemoryInfo mi = new MemoryInfo();
        ActivityManager activityManager = (ActivityManager) sprat
                                          .getSystemService (Activity.ACTIVITY_SERVICE);
        activityManager.getMemoryInfo (mi);
        long availableMegsOnRam = mi.availMem / 1024L;
        System.err.println ("availableMegsOnRam : " + availableMegsOnRam);
        System.err.println ("threshold : " + mi.threshold / 1024);
        System.err.println ("threshold(x) : " + ( (mi.threshold / 1024) + JNI_HEAP_THRESHOLD_AMOUNT_DIF));
        boolean lowMemory = availableMegsOnRam < ( (mi.threshold / 1024) + JNI_HEAP_THRESHOLD_AMOUNT_DIF);
        int counterForInfiniteLoop = 0;
        int counterForInfiniteLoopX = 0;

        while (lowMemory && counterForInfiniteLoop++ < 10
                && counterForInfiniteLoopX++ < 50 && bitmap_orders_jni.size() > 0) {
            String willRemove = bitmap_orders_jni.get (0);

            if (willRemove.equals (path)) {
                bitmap_orders_jni.remove (willRemove);
                bitmap_orders_jni.add (willRemove);

                if (bitmap_orders_jni.size() == 1) {
                    break;
                }

                counterForInfiniteLoop = 0;
                continue;
            }

            if (holders_jni.containsKey (willRemove)) {
                JniBitmapHolder holder = holders_jni.get (willRemove);
                holder.freeBitmap();
                MemoryInfo mi1 = new MemoryInfo();
                activityManager.getMemoryInfo (mi1);
                availableMegsOnRam = mi.availMem / 1024L;
                lowMemory = availableMegsOnRam < ( (mi1.threshold / 1024) + 5 * JNI_HEAP_THRESHOLD_AMOUNT_DIF);
                holders_jni.remove (willRemove); // TODO check memory leak in
                // c++
                weakholders_bitmap_jni.remove (willRemove);
                System.err.println ("availableMegsOnRam after freed some mem: " + availableMegsOnRam);
                bitmap_orders_jni.remove (willRemove);
                counterForInfiniteLoop = 0;
            }
        }

        if (counterForInfiniteLoop == 10) {
            System.err.println ("ERROR IN DELETING JNI MEMORY");
        }

        if (counterForInfiniteLoopX == 50) {
            System.err.println ("ERROR IN DELETING JNI MEMORY(X)");
        }
    }

    private static JniBitmapHolder getBitmap (String path, int width, int height) {
        if (imageExists (path)) {
            JniBitmapHolder bitmapHolder = new JniBitmapHolder (path, width,
                    height);

            if (bitmapHolder.ok()) {
                return bitmapHolder;

            } else {
                return null;
            }

        } else {
            return null;
        }
    }

    private static void setScreenPrefs (SpratAndroidActivity sprat) {
        Configuration configuration = sprat.getResources().getConfiguration();

        if ( (configuration.screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) ==
                Configuration.SCREENLAYOUT_SIZE_SMALL) {
            drawable_size = "small";

        } else if ( (configuration.screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) {
            drawable_size = "normal";

        } else if ( (configuration.screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) ==
                    Configuration.SCREENLAYOUT_SIZE_LARGE) {
            drawable_size = "large";

        } else if ( (configuration.screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) {
            drawable_size = "large";

        } else {
            drawable_size = "normal";
        }

        DisplayMetrics metrics = sprat.getResources().getDisplayMetrics();

        if (metrics.densityDpi == 213) {
            drawable_density = "tvdpi";

        } else if (metrics.densityDpi <= DisplayMetrics.DENSITY_LOW) {
            drawable_density = "ldpi";

        } else if (metrics.densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            drawable_density = "mdpi";

        } else if (metrics.densityDpi <= DisplayMetrics.DENSITY_HIGH) {
            drawable_density = "hdpi";

        } else if (metrics.densityDpi <= DisplayMetrics.DENSITY_XHIGH) {
            drawable_density = "xhdpi";

        } else {
            drawable_density = "xxhdpi";
        }
    }

    private static int calculateInSampleSize (BitmapFactory.Options options,
            int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            // Calculate ratios of height and width to requested height and
            // width
            final int heightRatio = Math.round ( (float) height / (float) reqHeight);
            final int widthRatio = Math.round ( (float) width / (float) reqWidth);
            // Choose the smallest ratio as inSampleSize value, this will
            // guarantee
            // a final image with both dimensions larger than or equal to the
            // requested height and width.
            inSampleSize = Math.min (heightRatio, widthRatio);
        }

        return inSampleSize;
    }

    private static Bitmap decodeSampledBitmapFromResource (String path,
            int reqWidth, int reqHeight) {
        File file = new File (path);

        try {
            if (reqHeight == 0 || reqHeight == 0) {
                FileInputStream fi = new FileInputStream (file);
                return BitmapFactory.decodeStream (fi);

            } else {
                // First decode with inJustDecodeBounds=true to check dimensions
                final BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                FileInputStream fi = new FileInputStream (file);
                BitmapFactory.decodeStream (fi, null, options);
                fi.close();
                fi = new FileInputStream (file);
                // Calculate inSampleSize
                options.inSampleSize = calculateInSampleSize (options, reqWidth,
                                       reqHeight);
                // Decode bitmap with inSampleSize set
                options.inJustDecodeBounds = false;
                return BitmapFactory.decodeStream (fi, null, options);
            }

        } catch (Exception e) {
            return null;
        }
    }

    private static Bitmap decodeSampledBitmapFromResource (InputStream in,
            int reqWidth, int reqHeight) {
        if (reqHeight == 0 || reqHeight == 0) {
            return BitmapFactory.decodeStream (in);

        } else {
            // First decode with inJustDecodeBounds=true to check dimensions
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream (in, null, options);

            try {
                //reset the inputstream to be able to read the image
                //The stream's position will be where ever it was after the encoded data was read.
                in.reset();

            } catch (IOException e) {
                e.printStackTrace();
            }

            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize (options, reqWidth,
                                   reqHeight);
            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream (in, null, options);
        }
    }

    private static Bitmap decodeSampledBitmapFromResource (Resources res,
            int resId, int reqWidth, int reqHeight) {
        if (reqHeight == 0 || reqHeight == 0) {
            return BitmapFactory.decodeResource (res, resId);

        } else {
            // First decode with inJustDecodeBounds=true to check dimensions
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeResource (res, resId, options);
            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize (options, reqWidth,
                                   reqHeight);
            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeResource (res, resId, options);
        }
    }

    public static String getEmulatorPath (SpratAndroidActivity sprat,
                                           String path) {
        if(drawawble_paths == null)
            drawawble_paths = new HashMap<>();
        if (path != null && path.startsWith ("images://")) {
            path = path.substring ("images://".length());
        }

        if (drawawble_paths != null && drawawble_paths.containsKey (path)) {
            return drawawble_paths.get (path);

        } else {
            String string = pathToDrawableName (path);
            String targetPath = sprat.getUnsecureDbPath__N() + "/res/drawable-"
                                + drawable_size + "-" + drawable_density + "/" + string
                                + ".png";
            String target9Path = sprat.getUnsecureDbPath__N()
                                 + "/res/drawable-" + drawable_size + "-" + drawable_density
                                 + "/" + string + ".9.png";

            if (new File (targetPath).exists()) {
                drawawble_paths.put (path, targetPath);
                return targetPath;

            } else if (new File (target9Path).exists()) {
                drawawble_paths.put (path, target9Path);
                return target9Path;

            }

            int density_index = 0;
            int size_index = 0;

            for (int j = 0; j < size.length; j++) {
                if (size[j].equals (drawable_size)) {
                    size_index = j;
                    break;
                }
            }

            for (int i = 0; i < density.length; i++) {
                if (density[i].equals (drawable_density)) {
                    density_index = i;
                    break;
                }
            }

            for (int j = size_index; j >= 0; j--) {
                for (int i = density_index; i >= 0; i--) {
                    targetPath = sprat.getUnsecureDbPath__N()
                            + "/res/drawable-" + size[j] + "-" + density[i]
                            + "/" + string + ".png";
                    target9Path = sprat.getUnsecureDbPath__N()
                            + "/res/drawable-" + size[j] + "-" + density[i]
                            + "/" + string + ".9.png";

                    if (new File(targetPath).exists()) {
                        drawawble_paths.put(path, targetPath);
                        return targetPath;

                    } else if (new File(target9Path).exists()) {
                        drawawble_paths.put(path, target9Path);
                        return target9Path;

                    }

                    targetPath = sprat.getUnsecureDbPath__N()
                            + "/res/drawable-" + density[i] + "/"
                            + string + ".png";
                    target9Path = sprat.getUnsecureDbPath__N()
                            + "/res/drawable-" + density[i] + "/"
                            + string + ".9.png";

                    if (new File(targetPath).exists()) {
                        drawawble_paths.put(path, targetPath);
                        return targetPath;

                    } else if (new File(target9Path).exists()) {
                        drawawble_paths.put(path, target9Path);
                        return target9Path;

                    }
                }

                targetPath = sprat.getUnsecureDbPath__N()
                        + "/res/drawable-" + size[j] + "/"
                        + string + ".png";
                target9Path = sprat.getUnsecureDbPath__N()
                        + "/res/drawable-" + size[j] + "/"
                        + string + ".9.png";

                if (new File(targetPath).exists()) {
                    drawawble_paths.put(path, targetPath);
                    return targetPath;

                } else if (new File(target9Path).exists()) {
                    drawawble_paths.put(path, target9Path);
                    return target9Path;

                }
            }

            for (int j = size.length - 1; j > size_index; j--) {
                for (int i = density.length - 1; i > density_index; i--) {
                    targetPath = sprat.getUnsecureDbPath__N()
                                 + "/res/drawable-" + size[j] + "-" + density[i]
                                 + "/" + string + ".png";
                    target9Path = sprat.getUnsecureDbPath__N()
                                  + "/res/drawable-" + size[j] + "-" + density[i]
                                  + "/" + string + ".9.png";

                    if (new File (targetPath).exists()) {
                        drawawble_paths.put (path, targetPath);
                        return targetPath;

                    } else if (new File (target9Path).exists()) {
                        drawawble_paths.put (path, target9Path);
                        return target9Path;

                    }

                    targetPath = sprat.getUnsecureDbPath__N()
                                 + "/res/drawable-" + density[i] + "/"
                                 + string + ".png";
                    target9Path = sprat.getUnsecureDbPath__N()
                                  + "/res/drawable-" + density[i] + "/"
                                  + string + ".9.png";

                    if (new File (targetPath).exists()) {
                        drawawble_paths.put (path, targetPath);
                        return targetPath;

                    } else if (new File (target9Path).exists()) {
                        drawawble_paths.put (path, target9Path);
                        return target9Path;

                    }

                }

                targetPath = sprat.getUnsecureDbPath__N()
                        + "/res/drawable-" + size[j] + "/"
                        + string + ".png";
                target9Path = sprat.getUnsecureDbPath__N()
                        + "/res/drawable-" + size[j] + "/"
                        + string + ".9.png";

                if (new File (targetPath).exists()) {
                    drawawble_paths.put (path, targetPath);
                    return targetPath;

                } else if (new File (target9Path).exists()) {
                    drawawble_paths.put (path, target9Path);
                    return target9Path;

                }
            }

            targetPath = sprat.getUnsecureDbPath__N()
                         + "/res/drawable/"
                         + string + ".png";
            target9Path = sprat.getUnsecureDbPath__N()
                          + "/res/drawable/"
                          + string + ".9.png";

            if (new File (targetPath).exists()) {
                drawawble_paths.put (path, targetPath);
                return targetPath;

            } else if (new File (target9Path).exists()) {
                drawawble_paths.put (path, target9Path);
                return target9Path;

            }

            drawawble_paths.put (path, null);
            return null;
        }
    }

    private static String pathToDrawableName (String path) {
        StringBuffer buf = new StringBuffer();
// todo nosaiba check this when emulator works
//        if (!SpratAndroidActivity.getInstance().isemulator  && !SpratAndroidActivity.getInstance().isScannerEmulator) {
//            buf.append ("drw_");
//        }

        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt (i);

            if (c >= 'A' && c <= 'Z') {
                c = (char) (c - 'A' + 'a');
            }

            if ( (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                buf.append (c);

            } else if ( (c == '.' && i == path.length() - 4)
                        || (c == '.' && path.charAt (i + 1) == '9'
                            && path.charAt (i + 2) == '.' && i == path.length() - 6)) {
                break;

            } else {
                buf.append ('_');
            }
        }

        return buf.toString();
    }

    public synchronized static String crop (String path, int x1, int y1, int x2, int y2, int _format,
                                            float compressionRate) {
        SpratAndroidActivity sprat = SpratAndroidActivity.getInstance();
        Bitmap.CompressFormat format;

        switch (_format) {
            case 0:
                format = Bitmap.CompressFormat.JPEG;
                break;

            case 1:
                format = Bitmap.CompressFormat.PNG;
                break;

            default:
                format = Bitmap.CompressFormat.JPEG;
                break;
        }

        Bitmap b = getBitmap (sprat, path, 0, 0, false);

        try {
            if (b != null) {
                int x = x2 - x1 >= 0 ? x2 - x1 : 0;
                int y = y2 - y1 >= 0 ? y2 - y1 : 0;
                Bitmap nB = Bitmap.createBitmap (b, x1 <= b.getWidth() ? x1 : 0,
                                                 y1 <= b.getHeight() ? y1 : 0,
                                                 x <= b.getWidth() ? x : (b.getWidth() - x1),
                                                 y <= b.getHeight() ? y : (b.getHeight() - y1));
                String fname = sprat.getUnsecureDbPath__N() + File.separator
                               + "temp_crop_" + System.currentTimeMillis() + (_format == 1 ? ".png" : ".jpg");
                File file = new File (fname);

                try {
                    FileOutputStream out = new FileOutputStream (file);
                    boolean val = nB.compress (format, (int) (compressionRate * 100), out);
                    out.flush();
                    out.close();

                } catch (Exception e) {
                    e.printStackTrace();
                }

                ExifInterface oldExif = new ExifInterface (path);
                String exifOrientation = oldExif.getAttribute (ExifInterface.TAG_ORIENTATION);
                ExifInterface newExif = new ExifInterface (fname);

                if (exifOrientation != null) {
                    newExif.setAttribute (ExifInterface.TAG_ORIENTATION, exifOrientation);
                }

                newExif.saveAttributes();
                return fname;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    public synchronized static String resize (String path, int width, int height, int _format,
            float compressionRate) {
        SpratAndroidActivity sprat = SpratAndroidActivity.getInstance();
        Bitmap.CompressFormat format;

        switch (_format) {
            case 0:
                format = Bitmap.CompressFormat.JPEG;
                break;

            case 1:
                format = Bitmap.CompressFormat.PNG;
                break;

            default:
                format = Bitmap.CompressFormat.JPEG;
                break;
        }

        Bitmap b = getBitmap (sprat, path, width, height, false);

        try {
            if (b != null) {
                Bitmap nB = Bitmap.createScaledBitmap (b, width, height, true);
                String fname = sprat.getPath__N (3) + File.separator
                               + "temp_resize_" + System.currentTimeMillis() + (_format == 1 ? ".png" : ".jpg");
                File file = new File (fname);

                try {
                    FileOutputStream out = new FileOutputStream (file);
                    boolean val = nB.compress (format, (int) (compressionRate * 100), out);
                    System.err.println ("smfimage val : " + val);
                    out.flush();
                    out.close();

                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    ExifInterface oldExif = new ExifInterface (path);
                    String exifOrientation = oldExif.getAttribute (ExifInterface.TAG_ORIENTATION);
                    ExifInterface newExif = new ExifInterface (fname);

                    if (exifOrientation != null) {
                        newExif.setAttribute (ExifInterface.TAG_ORIENTATION, exifOrientation);
                    }

                    newExif.saveAttributes();

                } catch (Exception e) {
                    e.printStackTrace();
                }

                return fname;
            }

        } catch (Exception e) {
        }

        return "";
    }

    public synchronized static String rotate (String path, int angle, int _format,
            float compressionRate) {
        SpratAndroidActivity sprat = SpratAndroidActivity.getInstance();
        Bitmap.CompressFormat format;

        switch (_format) {
            case 0:
                format = Bitmap.CompressFormat.JPEG;
                break;

            case 1:
                format = Bitmap.CompressFormat.PNG;
                break;

            default:
                format = Bitmap.CompressFormat.JPEG;
                break;
        }

        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile (path, options);
            Bitmap b = getBitmap (sprat, path, options.outWidth, options.outHeight, false);
            ExifInterface oldExif = new ExifInterface (path);
            String exifOrientation = oldExif
                                     .getAttribute (ExifInterface.TAG_ORIENTATION);
            int orientation = oldExif.getAttributeInt (ExifInterface.TAG_ORIENTATION,
                              ExifInterface.ORIENTATION_NORMAL);
            int degrees = angle;

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degrees += 90;
                    break;

                case ExifInterface.ORIENTATION_ROTATE_180:
                    degrees += 180;
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    degrees += 270;
                    break;
            }

            Matrix matrix = new Matrix();
            matrix.postRotate (degrees);
            Bitmap rotatedBitmap = Bitmap.createBitmap (b, 0, 0, b.getWidth(),
                                   b.getHeight(), matrix, false);
            String fname = sprat.getUnsecureDbPath__N() + File.separator
                           + "temp_rotate_" + angle + "_" + System.currentTimeMillis()
                           + (_format == 1 ? ".png" : ".jpg");
            File file = new File (fname);

            try {
                FileOutputStream out = new FileOutputStream (file);
                boolean val = rotatedBitmap.compress (format, (int) (compressionRate * 100), out);
                System.err.println ("smfimage val : " + val);
                out.flush();
                out.close();

            } catch (Exception e) {
                //e.printStackTrace();
            }

            ExifInterface newExif = new ExifInterface (fname);

            if (exifOrientation != null) {
                newExif.setAttribute (ExifInterface.TAG_ORIENTATION,
                                      exifOrientation);
            }

            newExif.saveAttributes();
            return fname;

        } catch (Exception e) {
        }

        return "";
    }

    // TODO implementation of function should use URI.
    public static void setupEmulator (SpratAndroidActivity sprat) {
        if (!emulator_setup) {
            emulator_setup = true;

            if (sprat.isemulator && !sprat.isScannerEmulator) {
                setScreenPrefs (sprat);
                drawawble_paths = new HashMap<String, String>();
            }
        }
    }

    public static String pathWithoutScheme (String path) {
        if (path != null) {
            int schemeSeparator = path.indexOf ("://");

            if (schemeSeparator != -1) {
                return path.substring (schemeSeparator + 3);
            }
        }

        return path;
    }

    public static void clearCache(){
        if(drawawble_paths != null){
            drawawble_paths.clear();
        }
        holders_bitmap.clear();
        bitmap_orders_jni.clear();
        weakholders_bitmap_jni.clear();
        holders_jni.clear();
    }
}
