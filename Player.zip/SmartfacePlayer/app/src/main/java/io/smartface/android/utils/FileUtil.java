package io.smartface.android.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * This class is required upto AND-3271 is fixed. Mostly contains helper methods for file.
 */

public class FileUtil {
    public static int DEFAULT_BUFFER_SIZE = 1024 * 4;

    public static void copyStream(InputStream in, OutputStream out) throws IOException{
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
    }

    public static byte[] toByteArray(InputStream input) throws IOException {
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        try(ByteArrayOutputStream output = new ByteArrayOutputStream()){
            int n;
            while (-1 != (n = input.read(buffer))) {
                output.write(buffer, 0, n);
            }
            return  output.toByteArray();
        }
    }
}