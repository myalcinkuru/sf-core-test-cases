package io.smartface.android.sfcore;

import android.widget.ScrollView;
import android.content.Context;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

public class SFScrollView extends ScrollView {
    SMFJSObject callbacks = null;

    public SFScrollView(Context context, SMFJSObject callbacks) {
        super(context);
        this.callbacks = callbacks;
    }

    @Override
    protected void onScrollChanged(int x, int y, int oldX, int oldY) {
        super.onScrollChanged(x, y, oldX, oldY);

        try {
            SMFJSObject successCallback = this.callbacks.getProperty("onScrollChanged");
            Object[] params = { x, y, oldX, oldY };
            successCallback.callAsNativeFunctionNew(successCallback.jsValueRef, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int computeVerticalScrollOffset() {
        return super.computeVerticalScrollOffset();
    }

    @Override
    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }
}