package io.smartface.android.sfcore.ui.mapview;

import android.graphics.Color;
import android.graphics.drawable.Drawable;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

public class MapClusterItem implements ClusterItem {
    private final LatLng mPosition;
    private String mTitle;
    private String mSnippet;
    public final BitmapDescriptor  mColor;
    public final Drawable mImage;

    public MapClusterItem(double lat, double lng) {
        mPosition = new LatLng(lat, lng);
        mTitle = null;
        mSnippet = null;
        mColor = null;
        mImage = null;
    }

    public MapClusterItem(double lat, double lng, String title, String snippet , BitmapDescriptor color , Drawable image) {
        mPosition = new LatLng(lat, lng);
        mTitle = title;
        mSnippet = snippet;
        mColor = color;
        mImage = image;
    }

    @Override
    public LatLng getPosition() {
        return mPosition;
    }

    @Override
    public String getTitle() { return mTitle; }

    @Override
    public String getSnippet() { return mSnippet; }

    /**
     * Set the title of the marker
     * @param title string to be set as title
     */
    public void setTitle(String title) {
        mTitle = title;
    }

    /**
     * Set the description of the marker
     * @param snippet string to be set as snippet
     */
    public void setSnippet(String snippet) {
        mSnippet = snippet;
    }

    public Drawable getmImage() {
        return this.mImage;
    }
    public BitmapDescriptor getmColor() {
        return this.mColor;
    }
}