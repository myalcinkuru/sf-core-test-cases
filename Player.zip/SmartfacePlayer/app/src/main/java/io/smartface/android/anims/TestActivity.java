package io.smartface.android.anims;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.yoga.YogaEdge;
import com.facebook.yoga.YogaNode;
import com.facebook.yoga.android.YogaLayout;

public class TestActivity extends AppCompatActivity {

    static {
        try {
            System.loadLibrary("sprat-jni");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RelativeLayout layout = new RelativeLayout(this);
        layout.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        YogaLayout yogaLayout = new YogaLayout(this);
        yogaLayout.setLayoutParams(new YogaLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        yogaLayout.setBackgroundColor(Color.RED);


        YogaNode yogaNode = yogaLayout.getYogaNode();
        yogaNode.setMargin(YogaEdge.LEFT, 50);
        yogaNode.setWidth(150);

        layout.addView(yogaLayout);
        setContentView(layout);
    }
}
