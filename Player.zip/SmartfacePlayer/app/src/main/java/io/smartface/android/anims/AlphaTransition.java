package io.smartface.android.anims;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import androidx.transition.Transition;
import androidx.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;

public class AlphaTransition extends Transition {

    public static final String PROPERTYNAME_ALPHA = "io.smartface:AlphaTransition:alpha";

    @Override
    public void captureEndValues(TransitionValues transitionValues) {
        captureValues(transitionValues);
    }

    @Override
    public void captureStartValues(TransitionValues transitionValues) {
        captureValues(transitionValues);
    }

    public void captureValues(TransitionValues transitionValues) {
        View view = transitionValues.view;
        transitionValues.values.put(PROPERTYNAME_ALPHA, view.getAlpha());
    }

    @Override
    public Animator createAnimator(ViewGroup sceneRoot, TransitionValues startValues, TransitionValues endValues) {
        if(sceneRoot == null || startValues == null || endValues == null)
            return null;
        if(startValues.values == null || endValues.values == null)
            return null;
        return ObjectAnimator.ofFloat(startValues.view, View.ALPHA,
                (float) startValues.values.get(PROPERTYNAME_ALPHA), (float) endValues.values.get(PROPERTYNAME_ALPHA));
    }

}