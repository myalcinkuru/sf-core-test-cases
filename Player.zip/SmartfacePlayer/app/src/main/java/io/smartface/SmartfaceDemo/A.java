package io.smartface.SmartfaceDemo;

import io.smartface.android.B;

public class A extends B {

}
