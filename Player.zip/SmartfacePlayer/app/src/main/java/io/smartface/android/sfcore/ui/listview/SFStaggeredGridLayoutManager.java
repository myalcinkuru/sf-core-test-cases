package io.smartface.android.sfcore.ui.listview;

import androidx.recyclerview.widget.StaggeredGridLayoutManager;

public class SFStaggeredGridLayoutManager extends StaggeredGridLayoutManager {
    public boolean isScrollHorizontally = true;
    public boolean isScrollVerically = true;

    public SFStaggeredGridLayoutManager(int spanCount, int orientation) {
        super(spanCount, orientation);
    }

    public void setCanScrollHorizontally(boolean scrollHorizontally){
        isScrollHorizontally = scrollHorizontally;
    }
    public void setCanScrollVerically(boolean scrollVerically){
        isScrollVerically = scrollVerically;
    }

    @Override
    public boolean canScrollHorizontally() {
        if(isScrollHorizontally)
            return super.canScrollHorizontally();
        else
            return isScrollHorizontally;
    }

    @Override
    public boolean canScrollVertically() {
        if(isScrollVerically)
            return super.canScrollVertically();
        else
            return  isScrollVerically;
    }
}
