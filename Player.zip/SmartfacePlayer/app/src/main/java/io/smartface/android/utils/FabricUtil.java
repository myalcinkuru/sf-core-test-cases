package io.smartface.android.utils;

import android.content.Context;
import com.crashlytics.android.Crashlytics;

/**
 * Created by metehantoksoy on 3/13/17. FabricUtil is developed for managing
 * Fabric and Crashlytics operations like sending user data or sending project
 * id to the fabric etc.
 */
public class FabricUtil {
    public static final String FABRIC_DEVICEPROVIDER = "deviceProvider";
    public static final String FABRIC_USERID = "User ID";
    public static final String FABRIC_PROJECTNAME = "Project Name";

    public static void initializeFabricDeviceInfo(Context context) {
        String deviceId = DeviceUtil.getDeviceId(context);
        String deviceProvider = "Device ID";
        if (deviceId == null) {
            deviceId = DeviceUtil.getSecureAndroidID(context);
            deviceProvider = "Secure Android ID";
        }
        Crashlytics.setUserIdentifier(deviceId);
        Crashlytics.setString(FABRIC_DEVICEPROVIDER, deviceProvider);
    }

    public static void setUserId(String userId) {
        setCrashlyticsProperty(FABRIC_USERID, userId);
    }

    public static void setProjectName(String projectName) {
        setCrashlyticsProperty(FABRIC_PROJECTNAME, projectName);
    }

    public static void setCrashlyticsProperty(String key, float value) {
        Crashlytics.setFloat(key, value);
    }

    public static void setCrashlyticsProperty(String key, double value) {
        Crashlytics.setDouble(key, value);
    }

    public static void setCrashlyticsProperty(String key, boolean value) {
        Crashlytics.setBool(key, value);
    }

    public static void setCrashlyticsProperty(String key, int value) {
        Crashlytics.setInt(key, value);
    }

    public static void setCrashlyticsProperty(String key, long value) {
        Crashlytics.setLong(key, value);
    }

    public static void setCrashlyticsProperty(String key, String value) {
        Crashlytics.setString(key, value);
    }
}
