package io.smartface.android.sfcore.device.accelerometer;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

public class SFAccelerometerListener implements SensorEventListener
{
    private Context context = null;
    private SensorManager sensorManager = null;
    public SMFJSObject onAccelerateCallback = null;

    public SFAccelerometerListener() {
        context = SpratAndroidActivity.getInstance().getApplicationContext();
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    }

    public void startListener() {
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
    }
    public void stopListener() {
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(onAccelerateCallback == null) 
            return;

        float[] values = event.values;
        float x = values[0];
        float y = values[1];
        float z = values[2];
        try {
            Object [] params = {x, y, z};
            onAccelerateCallback.callAsNativeFunctionNew(onAccelerateCallback.jsValueRef, params);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}