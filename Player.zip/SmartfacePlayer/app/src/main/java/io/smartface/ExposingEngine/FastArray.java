package io.smartface.ExposingEngine;

/**
 *  FastArray is a collection class. Since it is using arrays with basic functionalities it is
 *  supposed to be faster than ArrayList or LinkedList etc. It doesn't have search/copy capabilities,
 *  you may use FastArray if you want to work with indexes.
 *
 *  It requires capacity while creating an instance but under the hood created array's capacity is not
 *  same with requested. Capacity increases when needed. So that you may save some space in memory.
 */
public class FastArray {

    private int capacity = 0;
    private Object[][] jsObjectsArray = null;
    private int size = 0;

    /**
     *  Constructor.
     *
     *  @param  capacity    Requested capacity for FastArray
     */
    public FastArray(int capacity) {
        this.capacity = (int) Math.ceil(Math.sqrt(capacity));
        jsObjectsArray = new Object[this.capacity][];
    }

    /**
     * Gets object from collection at the given index.
     *
     * @param   index   Index of the object
     * @return          Object at the given index, null if given index is bigger or lower than capacity
     */
    public Object get(int index) {
        if (index < 0) return null;

        return jsObjectsArray[index/capacity][index%capacity];
    }

    /**
     * Adds object to collection and returns its index. If there is a problem while
     * adding object to collection returns -1.
     *
     * @param   object  Object to add collection
     * @return          Index of the object in the collection
     */
    public int add(Object object) {
        if (size % capacity == 0) {
            jsObjectsArray[size/capacity] = new Object[capacity];
        }

        jsObjectsArray[size/capacity][size%capacity] = object;
        return size++;
    }

    /**
     *  Returns the size of the array.
     *
     *  @return     Size of the array
     */
    public int size() {
        return size;
    }

    /**
     *  Removes all elements in the collection.
     */
    public void clear() {
        jsObjectsArray = new Object[capacity][];
        size = 0;
    }
}
