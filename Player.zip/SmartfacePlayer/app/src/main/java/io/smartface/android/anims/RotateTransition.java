package io.smartface.android.anims;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import androidx.transition.Transition;
import androidx.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/**
 * Created by metehantoksoy on 5/18/17.
 */
public class RotateTransition extends Transition {

    public static final String PROPERTYNAME_ROTATION  = "io.smartface:RotateTransition:rotation";
    public static final String PROPERTYNAME_ROTATION_X = "io.smartface:RotateTransition:rotationx";
    public static final String PROPERTYNAME_ROTATION_Y = "io.smartface:RotateTransition:rotationy";


    @Override
    public void captureStartValues(TransitionValues transitionValues) {
        transitionValues.values.put(PROPERTYNAME_ROTATION, transitionValues.view.getRotation());
        transitionValues.values.put(PROPERTYNAME_ROTATION_X, transitionValues.view.getRotationX());
        transitionValues.values.put(PROPERTYNAME_ROTATION_Y, transitionValues.view.getRotationY());
    }

    @Override
    public void captureEndValues(TransitionValues transitionValues) {
        transitionValues.values.put(PROPERTYNAME_ROTATION, transitionValues.view.getRotation());
        transitionValues.values.put(PROPERTYNAME_ROTATION_X, transitionValues.view.getRotationX());
        transitionValues.values.put(PROPERTYNAME_ROTATION_Y, transitionValues.view.getRotationY());
    }

    @Override
    public Animator createAnimator(ViewGroup sceneRoot, TransitionValues startValues,
                                   TransitionValues endValues) {
        if (startValues == null || endValues == null) {
            return null;
        }

        final View view = endValues.view;
        ArrayList<PropertyValuesHolder> propertyValuesHolders = new ArrayList<>();

        float startValue = (Float) startValues.values.get(PROPERTYNAME_ROTATION);
        float endValue = (Float) endValues.values.get(PROPERTYNAME_ROTATION);
        if (startValue != endValue) {
            propertyValuesHolders.add(PropertyValuesHolder.ofFloat(View.ROTATION, startValue, endValue));
        }

        startValue = (Float) startValues.values.get(PROPERTYNAME_ROTATION_X);
        endValue = (Float) endValues.values.get(PROPERTYNAME_ROTATION_X);
        if (startValue != endValue) {
            propertyValuesHolders.add(PropertyValuesHolder.ofFloat(View.ROTATION_X, startValue, endValue));
        }

        startValue = (Float) startValues.values.get(PROPERTYNAME_ROTATION_Y);
        endValue = (Float) endValues.values.get(PROPERTYNAME_ROTATION_Y);
        if (startValue != endValue) {
            propertyValuesHolders.add(PropertyValuesHolder.ofFloat(View.ROTATION_Y, startValue, endValue));
        }

        if(propertyValuesHolders.size() > 0){
            // Return animation for all changed rotation properties
            return ObjectAnimator.ofPropertyValuesHolder(view, propertyValuesHolders.toArray(new PropertyValuesHolder[0]));
        }
        // Nothing changes. No animation needes.
        return null;
    }
}