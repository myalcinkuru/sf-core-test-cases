package io.smartface.android.sfcore.ui.materialtextbox;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.facebook.yoga.YogaNode;
import com.facebook.yoga.android.YogaLayout;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import io.smartface.SmartfaceDemo.R;
import io.smartface.android.utils.AndroidUnitConverterUtil;

/*
ToDo: These wrapper class is intended to prevent  exceptions related to JS layer. Consider when getDeclatedMethods exceptions are handled.
 */
public class SFMaterialTextBoxWrapper extends LinearLayout {
    TextInputLayout mTextInputLayout;
    TextInputEditText mTextInputEditText;

    public SFMaterialTextBoxWrapper(Context uiContext) {
        super(uiContext);
        mTextInputLayout = new TextInputLayout(uiContext);
        mTextInputLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        this.addView(mTextInputLayout);
        setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        mTextInputEditText = new TextInputEditText(mTextInputLayout.getContext());
        mTextInputEditText.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        mTextInputLayout.addView(mTextInputEditText);
    }

    public TextInputLayout getInstance() {
        return mTextInputLayout;
    }

    /*
     * This method gives more flexablity than implementing TextInputLayout's toggle
     * password icon. After using this, user cannot use toggle password icon.
     */
    public void setRightLayout(View view, YogaNode viewNode, YogaLayout parentView, int width) {
        FrameLayout.LayoutParams frameLayout = new FrameLayout.LayoutParams(AndroidUnitConverterUtil.dpToPixel(width),
                -1, Gravity.END);
        frameLayout.setMargins(0, 0, 0, AndroidUnitConverterUtil.dpToPixel(9)); // 9dp given re-position top of textbox
                                                                                // line.

        FrameLayout innerFrameLayout = (FrameLayout) mTextInputLayout.getChildAt(0); // 0 child is FrameLayout
        TextInputEditText textViewNativeObject = mTextInputEditText;

        parentView.addView(view, viewNode);
        parentView.setLayoutParams(frameLayout);
        innerFrameLayout.addView(parentView);

        ColorDrawable mPasswordToggleDummyDrawable = new ColorDrawable();
        mPasswordToggleDummyDrawable.setBounds(0, 0, AndroidUnitConverterUtil.dpToPixel(width), 1);

        /*
         * ToDo:After solving AND-3433 issue, retrieve compound drawables from textview
         * and assign to directions Assigning null to directions, fine for now but in
         * feature user can assign compound drawables and we should not write over it.
         */
        textViewNativeObject.setCompoundDrawablesRelative(null, null, mPasswordToggleDummyDrawable, null);
    }

    /*
     * TextInputLayout re-creates error & counter view when enabling.
     */
    public View getReCreatedErrorView() {
        LinearLayout materialLinearLayout = (LinearLayout) mTextInputLayout.getChildAt(1); // LinearLayout which
                                                                                           // contains errorView &
                                                                                           // counterView
        View errorTextView = materialLinearLayout.findViewById(R.id.textinput_error);
        return errorTextView;
    }

    public View getReCreatedCounterView() {
        LinearLayout materialLinearLayout = (LinearLayout) mTextInputLayout.getChildAt(1); // LinearLayout which
                                                                                           // contains errorView &
                                                                                           // counterView
        View counterTextView = materialLinearLayout.findViewById(R.id.textinput_counter);
        return counterTextView;
    }

    public void setExpandedHintTextSize(int textSize) {
        try {
            Field filedCollapsingTextHelper = TextInputLayout.class.getDeclaredField("collapsingTextHelper");
            filedCollapsingTextHelper.setAccessible(true);

            Object helper = filedCollapsingTextHelper.get(mTextInputLayout);

            Field fieldExpandedTextSize = helper.getClass().getDeclaredField("expandedTextSize");
            fieldExpandedTextSize.setAccessible(true);
            fieldExpandedTextSize.set(helper, textSize);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void changedErrorTextColor(String fieldName, int color) {
        try {
            Field field = TextInputLayout.class.getDeclaredField(fieldName);
            field.setAccessible(true);

            int states[][] = new int[][] { new int[] {} };

            int[] colors = new int[] { color };

            ColorStateList singleColorState = new ColorStateList(states, colors);
            field.set(mTextInputLayout, singleColorState);

            Method method = TextInputLayout.class.getDeclaredMethod("updateLabelState", boolean.class);
            method.setAccessible(true);
            method.invoke(mTextInputLayout, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public TextInputEditText getTextInputEditTextInstance() {
        return mTextInputEditText;
    }

    public void setTypeface(@Nullable Typeface typeface) {
        mTextInputLayout.setTypeface(typeface);
    }

    @NonNull
    public Typeface getTypeface() {
        return mTextInputLayout.getTypeface();
    }

    @Nullable
    public EditText getEditText() {
        return mTextInputLayout.getEditText();
    }

    public void setHint(@Nullable CharSequence hint) {
        mTextInputLayout.setHint(hint);
    }

    @Nullable
    public CharSequence getHint() {
        return mTextInputLayout.getHint();
    }

    public void setHintEnabled(boolean enabled) {
        mTextInputLayout.setHintEnabled(enabled);
    }

    public boolean isHintEnabled() {
        return mTextInputLayout.isHintEnabled();
    }

    public void setHintTextAppearance(int resId) {
        mTextInputLayout.setHintTextAppearance(resId);
    }

    public void setErrorEnabled(boolean enabled) {
        mTextInputLayout.setErrorEnabled(enabled);
    }

    public void setErrorTextAppearance(int resId) {
        mTextInputLayout.setErrorTextAppearance(resId);
    }

    public boolean isErrorEnabled() {
        return mTextInputLayout.isErrorEnabled();
    }

    public void setError(@Nullable CharSequence error) {
        mTextInputLayout.setError(error);
    }

    public void setCounterEnabled(boolean enabled) {
        mTextInputLayout.setCounterEnabled(enabled);
    }

    public boolean isCounterEnabled() {
        return mTextInputLayout.isCounterEnabled();
    }

    public void setCounterMaxLength(int maxLength) {
        mTextInputLayout.setCounterMaxLength(maxLength);
    }

    public int getCounterMaxLength() {
        return mTextInputLayout.getCounterMaxLength();
    }

    @Nullable
    public CharSequence getError() {
        return mTextInputLayout.getError();
    }

    public boolean isHintAnimationEnabled() {
        return mTextInputLayout.isHintAnimationEnabled();
    }

    public void setHintAnimationEnabled(boolean enabled) {
        mTextInputLayout.setHintAnimationEnabled(enabled);
    }
}