package io.smartface.android.sfcore.device.multimedia;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.core.content.FileProvider;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;

import io.smartface.android.SpratAndroidActivity;

public class SFMultimedia {
    public static Intent getCameraIntent(Context context, Uri outputFileUri) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (outputFileUri != null) {
            intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        }
        return intent;
    }

    public static Uri createImageFile(Context context) {
        File getImage = context.getExternalCacheDir();
        if (getImage != null) {
            String authority = SpratAndroidActivity.getAuthority();
            File outputFile = new File(getImage.getPath(), "imageResult.jpeg");
            return FileProvider.getUriForFile(context, authority, outputFile);
        }
        return null;
    }

    public static void startCropActivity(Uri uri, Context context, Fragment fragment, int cropShape, int aspectRatioX,
                                         int aspectRatioY) {
        getCropActivityBuilder(uri, cropShape).
                setAspectRatio(aspectRatioX, aspectRatioY).
                start(context, fragment);
    }

    public static void startCropActivity(Uri uri, Context context, Fragment fragment, int cropShape) {
        getCropActivityBuilder(uri, cropShape)
                .start(context, fragment);
    }

    private static CropImage.ActivityBuilder getCropActivityBuilder(Uri uri, int cropShape) {
        CropImageView.CropShape cropImageViewShape;
        switch (cropShape) {
            case 2:
                cropImageViewShape = CropImageView.CropShape.OVAL;
                break;
            default:
                cropImageViewShape = CropImageView.CropShape.RECTANGLE;
                break;
        }

        return CropImage.activity(uri).setCropShape(cropImageViewShape);
    }
}