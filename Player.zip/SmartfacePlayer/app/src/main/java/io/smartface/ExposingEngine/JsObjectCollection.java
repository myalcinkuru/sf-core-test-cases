package io.smartface.ExposingEngine;

import android.util.Log;

import java.util.ArrayDeque;
import java.util.Queue;

public class JsObjectCollection {
    private static final int MAX_SIZE_PER_ARRAY = 3000;
    private static Object[][] jsObjectsArray = new Object[MAX_SIZE_PER_ARRAY][];
    private static int totalSize = 0;
    private static Queue<Integer> removedIndexes = new ArrayDeque<>();

    /**
     * Gets object from cache at the given index. If there is an exception returns null;
     *
     * @param index Index of the object
     * @return Object, if found at given index, null otherwise
     */
    public static Object get(int index) {
        if (index < 0) return null;

        return jsObjectsArray[index/MAX_SIZE_PER_ARRAY][index%MAX_SIZE_PER_ARRAY];
    }

    public static Object getExchangeValue(int index) {
        Object object = get(index);
        if(object instanceof JsAbstractObject) {
            return ((JsAbstractObject)object).getJavaObject();
        }
        return null;
    }

    /**
     * Adds object to cache and returns its index in the cache. If there is a problem while
     * adding object to cache returns -1.
     *
     * @param object Object to add collection
     * @return Identifier of the object in the collection
     */
    public static int add(Object object) {
        if (removedIndexes.size() > 0) {
            int index = removedIndexes.poll();
            jsObjectsArray[index/MAX_SIZE_PER_ARRAY][index%MAX_SIZE_PER_ARRAY] = object;
            return index;
        }

        if (totalSize % MAX_SIZE_PER_ARRAY == 0) {
            jsObjectsArray[totalSize/MAX_SIZE_PER_ARRAY] = new Object[MAX_SIZE_PER_ARRAY];
        }

        jsObjectsArray[totalSize/MAX_SIZE_PER_ARRAY][totalSize%MAX_SIZE_PER_ARRAY] = object;
        return totalSize++;
    }

    /**
     *  Clears the cache
     */
    public static void clear() {
        jsObjectsArray = new Object[MAX_SIZE_PER_ARRAY][];
        totalSize = 0;
    }

    public static void remove(int index) {
        removedIndexes.add(index);
    }
}