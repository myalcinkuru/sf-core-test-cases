package io.smartface.android.utils;

import androidx.transition.Transition;
import io.smartface.plugin.SMFJSObject;

public final class AnimationUtil {

    public static void setSharedElementTransitionCallback(final SMFJSObject callbacks, Transition transition){
        transition.addListener(new Transition.TransitionListener() {
            @Override
            public void onTransitionStart(Transition transition) {
                try {
                    SMFJSObject jsCallback = callbacks.getProperty("onTransitionStart");
                    jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onTransitionEnd(Transition transition) {
                try {
                    SMFJSObject jsCallback = callbacks.getProperty("onTransitionEnd");
                    jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onTransitionCancel(Transition transition) {}
            @Override
            public void onTransitionPause(Transition transition) {}
            @Override
            public void onTransitionResume(Transition transition) {}
        });
    }
}
