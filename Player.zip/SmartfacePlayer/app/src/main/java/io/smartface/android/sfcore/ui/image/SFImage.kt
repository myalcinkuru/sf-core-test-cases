package io.smartface.android.sfcore.ui.image

import android.content.res.Resources
import android.graphics.Bitmap
import androidx.core.graphics.drawable.RoundedBitmapDrawable
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import io.smartface.android.utils.AndroidUnitConverterUtil

class SFImage {
    companion object {
        @JvmStatic
        fun getRoundedBitmapDrawable(resources: Resources,  bitmap: Bitmap, radius: Float): RoundedBitmapDrawable {
            val drawable = RoundedBitmapDrawableFactory.create(resources, bitmap);
            drawable.setCornerRadius(AndroidUnitConverterUtil.dpToPixel(radius).toFloat());
            return drawable;
        }

        @JvmStatic
        fun getRoundedBitmapDrawable(resources: Resources,  imgPath: String, radius: Float): RoundedBitmapDrawable {
            val drawable = RoundedBitmapDrawableFactory.create(resources, imgPath);
            drawable.setCornerRadius(AndroidUnitConverterUtil.dpToPixel(radius).toFloat());
            return drawable;
        }
    }
}