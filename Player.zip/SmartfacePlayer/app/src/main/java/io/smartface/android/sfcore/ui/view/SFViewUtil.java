package io.smartface.android.sfcore.ui.view;

import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Build;
import androidx.core.view.ViewCompat;

import android.view.View;
import android.view.ViewGroup;
import android.view.Window;


public class SFViewUtil {
    public static int[] getLocationOnScreen(View v) {
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        return location;
    }

    public static void setBackground(View view, int bgColor, int color, int width, float[] radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(bgColor);
        drawable.setStroke(width, color);
        // Provide backward support in case of diff behavior of border radius.
        if (radius.length == 1){
            drawable.setCornerRadius(radius[0]);
        }else {
            drawable.setCornerRadii(radius);
        }
        view.setBackground(drawable);
    }

    public static void setBackground(View view, int[] bgColors, GradientDrawable.Orientation direction, int color,
            int width, float[] radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setOrientation(direction);
        drawable.setColors(bgColors);
        drawable.setStroke(width, color);
        // Provide backward support in case of diff behavior of border radius.
        if (radius.length == 1){
            drawable.setCornerRadius(radius[0]);
        }else {
            drawable.setCornerRadii(radius);
        }
        view.setBackground(drawable);
    }

    public static ShapeDrawable getShapeDrawable(int borderColor, int borderWidth, int borderRadius) {
        float[] radii = { borderRadius, borderRadius, borderRadius, borderRadius, borderRadius, borderRadius,
                borderRadius, borderRadius };
        RectF rectF = new RectF(borderWidth, borderWidth, borderWidth, borderWidth);
        RoundRectShape roundRect = new RoundRectShape(radii, rectF, radii);
        ShapeDrawable shapeDrawable = new ShapeDrawable(roundRect);

        if (borderWidth != 0) {
            shapeDrawable.getPaint().setColor(borderColor);
        } else {
            shapeDrawable.getPaint().setColor(0);
        }
        return shapeDrawable;
    }

    public static void setZ(View view, float index) {
        ViewCompat.setZ(view, index);
    }

    public static float getZ(View view) {
        return ViewCompat.getZ(view);
    }

    public static void setElevation(View view, float index) {
        ViewCompat.setElevation(view, index);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            view.setStateListAnimator(null);
        }
    }

    public static float getElevation(View view) {
        return ViewCompat.getElevation(view);
    }

    public static void setTransitionName(View view, String id) {
        ViewCompat.setTransitionName(view, id);
    }

    public static String getTransitionName(View view) {
        return ViewCompat.getTransitionName(view);
    }

    public static void setFitsSystemWindows(Window window, boolean isSetFitsSystemWindows) {
        // ID_ANDROID_CONTENT = The ID that the main layout in the XML layout file should have.
        ViewGroup mContentView = window.findViewById(Window.ID_ANDROID_CONTENT);
        View mChildView = mContentView.getChildAt(0);
        if (mChildView != null) {
            mChildView.setFitsSystemWindows(isSetFitsSystemWindows);
            ViewCompat.requestApplyInsets(mChildView);
        }
    }
}