package io.smartface.android.utils;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.google.android.gms.common.GoogleApiAvailability;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;

import io.smartface.SmartfaceDemo.R;
import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

/**
 * Created by metehantoksoy on 3/13/17. FCMRegisterUtil is an util for making
 * Google Cloud Messaging Operations.
 *
 * This class implemented for nf-core/global/notifications
 */
public class FCMRegisterUtil {
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String firebaseAppName = "[DEFAULT]";

    /**
     * Register to Google Cloud Messaging Implement on Android side due to not
     * maunregisterRemoteNotificationListenerking async task on nf-core side.
     *
     * @param senderID
     * @param activity
     * @param callbacks
     */
    public static void registerPushNotification(String senderID, Activity activity, SMFJSObject callbacks) {
        if (!senderID.equals("")) {
            if (checkPlayServices(activity)) {
                initFirebaseApp(senderID, activity);
                processFCMOnBackground(true, senderID, activity, callbacks);
                return;
            }
        }
        callJsCallback(callbacks, null);
    }

    /***
     * Get sender ID from core due to the encryption of the project.json
     *
     * @return decrypted senderID;
     */
    public static String getSenderID() {
        return SpratAndroidActivity.getSenderID();
    }

    /**
     * Unregister from Google Cloud Messaging Implement on Android side due to not
     * making async task on nf-core side.
     *
     * @param context
     */
    public static void unregisterPushNotification(Context context) {
        try {
            processFCMOnBackground(false, null, context, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Check Google Play Services. If not exists or available, we can not register
     * the Google Cloud Messaging.
     *
     * @param activity
     * @return the status of Google Play Services
     */
    public static boolean checkPlayServices(Activity activity) {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(activity);
        if (result != 0) {
            if (googleAPI.isUserResolvableError(result)) {
                googleAPI.getErrorDialog(activity, result, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            }
            return false;
        }
        return true;
    }

    public static FirebaseApp initFirebaseApp(String senderId, Context context) {
        if (!isFirebaseAppInit(firebaseAppName, context)) {
            FirebaseOptions options = new FirebaseOptions.Builder().setApplicationId(firebaseAppName)
                    .setGcmSenderId(senderId).build();
            return FirebaseApp.initializeApp(context, options, firebaseAppName);
        } else {
            return FirebaseApp.getInstance(firebaseAppName);
        }
    }


    public static boolean isFirebaseAppInit(String firebaseAppName, Context context) {
        boolean isFirebaseAppInit = false;
        for (FirebaseApp firebaseApp : FirebaseApp.getApps(context)) {
            if (firebaseApp.getName() == firebaseAppName) {
                isFirebaseAppInit = true;
                break;
            }
        }
        return isFirebaseAppInit;
    }


    public static void processFCMOnBackground(final boolean isRegister,
                                              final String senderID, final Context context, final SMFJSObject callbacks) {
        if (isFirebaseAppInit(firebaseAppName, context)) {

            final FirebaseApp firebaseApp = FirebaseApp.getInstance(firebaseAppName);
            final FirebaseInstanceId firebaseInstanceId = FirebaseInstanceId.getInstance(firebaseApp);

            new AsyncTask<Void, Void, String>() {
                @Override
                protected String doInBackground(Void[] params) {
                    try {
                        String token = null;
                        if (isRegister) {
                            token = firebaseInstanceId.getToken(senderID, FirebaseMessaging.INSTANCE_ID_SCOPE);
                        } else {
                            firebaseInstanceId.deleteInstanceId();
                            firebaseApp.delete();
                        }
                        return token;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(String token) {
                    if (isRegister) {
                        if (callbacks != null) {
                            callJsCallback(callbacks, token);
                        }
                    }
                }
            }.execute();
        }
    }

    private static void callJsCallback(SMFJSObject callbacks, String token) {
        try {
            if (token != null) {
                if (callbacks.hasProperty("onSuccess")) {
                    SMFJSObject successCallback = callbacks.getProperty("onSuccess");
                    ExchangeValue[] params = new ExchangeValue[1];
                    params[0] = JavaJsInterface.wrapValue(token);
                    successCallback.callAsFunctionNew(successCallback.jsValueRef, params);
                }
            } else {
                if (callbacks.hasProperty("onFailure")) {
                    SMFJSObject failureCallback = callbacks.getProperty("onFailure");
                    failureCallback.callAsFunctionNew(failureCallback.jsValueRef, null);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}