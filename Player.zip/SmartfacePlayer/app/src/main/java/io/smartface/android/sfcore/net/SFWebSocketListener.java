package io.smartface.android.sfcore.net;

import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

public class SFWebSocketListener extends WebSocketListener {
    SMFJSObject callbacks = null;

    public SFWebSocketListener(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }
    
    @Override
    public void onOpen(WebSocket webSocket, Response response) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onOpen");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onMessage(WebSocket webSocket, String text) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onMessage");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{text});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onMessage(WebSocket webSocket, ByteString bytes) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onMessage");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{bytes});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onClosing(WebSocket webSocket, int code, String reason) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onClosing");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{code,reason});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onFailure(WebSocket webSocket, Throwable t, Response response) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onFailure");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{t.getMessage(),response.code()});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}