package io.smartface.ExposingEngine;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class JsClassManager extends Thread {
    private static Map<String, JsClass> classCache = new HashMap<>();
    private static Queue<JsClass> classQueue = new LinkedList<>();
    private static JsClassManager instance = new JsClassManager();

    private static Lock queueLock = new ReentrantLock();

    /**
     *  Tries to load class from runtime. If found adds it to object collection and returns its
     *  identifier.
     *
     *  @return Class identifier if class found, -1 otherwise
     */
    public static JsClass GetClass(String className) {
        JsClass classFromCache = classCache.get(className);
        if (classFromCache != null) {
            return classFromCache;
        }

        try {
            Class<?> clazz = Class.forName(className);
            return GetClass(clazz);
        } catch(ClassNotFoundException exception) {
            return null;
        }
    }

    public static JsClass GetClass(Class<?> javaClass) {
        String className = javaClass.getName();

        JsClass jsClass = classCache.get(className);
        if(jsClass != null) {
            return jsClass;
        } else {
            jsClass = new JsClass(javaClass);
            classCache.put(className, jsClass);

            queueLock.lock();
            classQueue.add(jsClass);
            queueLock.unlock();

            return jsClass;
        }
    }

    public static void Start() {
        if (!instance.isAlive()) {
            instance.start();
        }
    }

    public static void ClearCache() {
        classQueue.clear();
        classCache.clear();
    }

    @Override
    public void run() {
        while (true) {
            if (!classQueue.isEmpty()) {
                try {
                    queueLock.lock();
                    JsClass jsClass = classQueue.remove();
                    queueLock.unlock();
                    jsClass.crawlClass();
                    jsClass.setReady(true);
                    jsClass.unlock();
                } catch (Exception e) {
                    // do nothing, exception may occur due to concurrency and it should be fixed. Current
                    // structure is not final.
                } catch (Error e) {
                    // do nothing
                }
            }
        }
    }
}