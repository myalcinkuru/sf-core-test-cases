package io.smartface.ExposingEngine;

import java.lang.reflect.Method;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class JsAbstractObject {
    protected Object javaObject;

    private volatile boolean ready = false;
    private Lock readyLock = new ReentrantLock();

    public JsAbstractObject(Object javaObject) {
        this.javaObject = javaObject;
    }

    public void setJavaObject(Object javaObject) {
        this.javaObject = javaObject;
    }

    public Object getJavaObject() {
        return this.javaObject;
    }

    public synchronized boolean isReady() {
        return ready;
    }

    public synchronized void setReady(boolean ready) {
        this.ready = ready;
    }

    public void lock() {
        readyLock.lock();
    }

    public void unlock() {
        readyLock.unlock();
    }

    public abstract JsAbstractObject getProperty(String name) throws Exception;
    public abstract boolean setProperty(String name, Object value);
    public abstract JsAbstractObject invokeMethod(String name, Object[] parameters) throws Throwable;

    public String toString() {
        return javaObject.toString();
    }

    protected void waitUntilReady() {
        // Main intention for having locks is to avoid busy wait and we're assuming (and trying to
        // make sure) that a JsClass will be locked until it's ready. But there is a case that I
        // couldn't find it's root cause and it force me to double check ready state.
        // Hopefully we will get rid of busy wait here, actually it's busy wait for just that case
        // occuring for 1 class.
        while (!isReady()) {
            readyLock.lock();
            readyLock.unlock();
        }
    }

    protected JsAbstractObject wrapObjectIntoJsAbstractObject(Object object) {
        if (object == null) {
            return null;
        }

        if (object instanceof Class) {
            return JsClassManager.GetClass((Class) object);
        } else if (object instanceof Method) {
            JsMethod jsMethod = new JsMethod((Method) object);
            jsMethod.setHolder(this);
            return jsMethod;
        } else if (object instanceof JsAbstractObject) {
            return (JsAbstractObject) object;
        } else {
            return new JsObject(object);
        }
    }

    protected JsAbstractObject wrapObjectIntoJsAbstractObject(Object object, JsAbstractObject holder) {
        if (object == null) {
            return null;
        }

        if (object instanceof Class) {
            return JsClassManager.GetClass((Class) object);
        } else if (object instanceof Method) {
            JsMethod jsMethod = new JsMethod((Method) object);
            jsMethod.setHolder(holder);
            return jsMethod;
        } else if (object instanceof JsAbstractObject) {
            return (JsAbstractObject) object;
        } else {
            return new JsObject(object);
        }
    }
}