package io.smartface.android.sfcore.ui.floatingmenu;

import android.content.Context;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

import uk.co.markormesher.android_fab.SpeedDialMenuAdapter;

public class SFSpeedDialAdapter extends SpeedDialMenuAdapter{
    SMFJSObject callbacks = null;
    public SFSpeedDialAdapter(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }

    @Override
    public int getCount() {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getCount");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);

            return ((int)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public SpeedDialMenuAdapter.MenuItem getViews(Context context, int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getViews");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{position});

            return ((SpeedDialMenuAdapter.MenuItem)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int getBackgroundColour(int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getBackgroundColour");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{position});
            return ((int)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public boolean onMenuItemClick(int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onMenuItemClick");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{position});
            return ((boolean)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public boolean rotateFab() {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("rotateFab");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
            return ((boolean)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}