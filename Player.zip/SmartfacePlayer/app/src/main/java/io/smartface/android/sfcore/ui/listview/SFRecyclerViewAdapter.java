package io.smartface.android.sfcore.ui.listview;

import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;

import io.smartface.plugin.SMFJSObject;

public class SFRecyclerViewAdapter extends RecyclerView.Adapter {
    SMFJSObject callbacks = null;
    public SFRecyclerViewAdapter(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }

    @Override
    public SFRecyclerViewHolder onCreateViewHolder(ViewGroup parent,
                                                    int viewType) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onCreateViewHolder");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{viewType});
            return ((SFRecyclerViewHolder)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onBindViewHolder");
            int hashCode = holder.itemView.hashCode();
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{hashCode, position});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemViewType(int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getItemViewType");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{position});
            return ((int)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return 1;
    }

    @Override
    public int getItemCount() {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getItemCount");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
            return ((int)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void onItemSelected(int position, int itemViewHashCode) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onItemSelected");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{position, itemViewHashCode});
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    // todo:The return value should be specified by the developer.
    // Current usage is not best-practice.
    public boolean onItemLongSelected(int position, int itemViewHashCode) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onItemLongSelected");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{position, itemViewHashCode});
            return true;
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}