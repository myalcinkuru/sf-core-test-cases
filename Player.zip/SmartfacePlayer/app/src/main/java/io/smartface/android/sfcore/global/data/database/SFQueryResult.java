package io.smartface.android.sfcore.global.data.database;

import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.collection.ArrayMap;

import java.util.ArrayList;

public class SFQueryResult {
    private final Cursor oCursor;
    private ArrayList<SFDatabaseObject> resultList = new ArrayList<>();

    public SFQueryResult(@NonNull Cursor oCursor) {
        this.oCursor = oCursor;

    }
    public int moveToFirst(){
        boolean isInFirst = oCursor.moveToFirst();
        int index = -1;
        if(isInFirst){
            index = gatherObject();
        }
        return  index;
    }
    public int moveToLast(){
        boolean isInLast = oCursor.moveToLast();
        int index = -1;
        if(isInLast){
            index = gatherObject();
        }
        return  index;
    }
    public int moveToPosition(int position){
        boolean isInPosition = oCursor.moveToPosition(position);
        int index = -1;
        if(isInPosition){
            index = gatherObject();
        }
        return  index;
    }

    private int gatherObject(){
        final  int index = resultList.size();
        SFDatabaseObject sfDObj = new SFDatabaseObject(oCursor);
        resultList.add(index,sfDObj);
        return  index;
    }

    public void close(){
        oCursor.close();
    }

    public int getCount(){
        return  oCursor.getCount();
    }

    public int getPosition(int index) {
        return resultList.get(index).getPosition();
    }

    public int getColumnCount(int index) {
        return  resultList.get(index).getColumnCount();
    }

    public byte[] getBlob(int index, String cName) {
        return resultList.get(index).getBlob(cName);
    }

    public String getString(int index,String cName) {
        return resultList.get(index).getString(cName);
    }

    public boolean getBoolean(int index,String cName){
        return resultList.get(index).getBoolean(cName);
    }

    public Integer getInt(int index,String cName) {
        return resultList.get(index).getInt(cName);
    }

    public Long getLong(int index,String cName) {
        return resultList.get(index).getLong(cName);
    }

    public Float getFloat(int index,String cName) {
        return resultList.get(index).getFloat(cName);
    }

    public Double getDouble(int index,String cName) { return resultList.get(index).getDouble(cName); }

    public class SFDatabaseObject {
        private final Cursor mCursor;
        private ArrayMap<String ,? super Object> cArrayMap = new ArrayMap<>();
        private final int cPosition;

        public SFDatabaseObject(@NonNull  Cursor mCursor) {
            this.mCursor = mCursor;
            cPosition = mCursor.getPosition();
            obtainRows(mCursor);
        }

        private void obtainRows(Cursor mCursor){
            if(mCursor == null)
                return;

            String[] columnCount = mCursor.getColumnNames();
            for (String cName : columnCount) {
                int indexCName = mCursor.getColumnIndex(cName);
                int cType = mCursor.getType(indexCName);

                switch (cType){
                    case Cursor.FIELD_TYPE_STRING:
                        String cString= mCursor.getString(indexCName);
                        cArrayMap.put(cName,  cString);
                        break;

                    case Cursor.FIELD_TYPE_BLOB:
                        byte[] cBlob= mCursor.getBlob(indexCName);
                        cArrayMap.put(cName, cBlob);
                        break;

                    case Cursor.FIELD_TYPE_FLOAT:
                        float cFloat = mCursor.getFloat(indexCName);
                        cArrayMap.put(cName,  cFloat);
                        break;

                    case  Cursor.FIELD_TYPE_INTEGER:
                        int cInt = mCursor.getInt(indexCName);
                        cArrayMap.put(cName, cInt);
                        break;
                    case Cursor.FIELD_TYPE_NULL:
                        cArrayMap.put(cName, null);
                        break;
                }
            }
        }

        public int getCount() {
            return cArrayMap.size();
        }

        public int getPosition() {
            return cPosition;
        }

        public int getColumnCount() {
            return cArrayMap.size();
        }

        public byte[] getBlob(String cName) {
            return ((byte[]) cArrayMap.get(cName));
        }

        public String getString(String cName) {
            return String.valueOf(cArrayMap.get(cName));
        }

        public boolean getBoolean(String cName){
            boolean value = (Integer) cArrayMap.get(cName) > 0;
            return value;
        }

        public Integer getInt(String cName) {
            Object value = cArrayMap.get(cName);

            if(value != null) {
                if (value instanceof Integer) {
                    return (Integer) value;
                } else if (value instanceof String) {
                    return Integer.valueOf((String) value);
                } else if (value instanceof Float) {
                    return ((Float) value).intValue();
                } else if (value instanceof Long) {
                    return ((Long) value).intValue();
                } else if (value instanceof Double) {
                    return ((Double) value).intValue();
                }
            }
            return  null;
        }

        public Long getLong(String cName) {
            Object value = cArrayMap.get(cName);

            if(value != null) {
                if (value instanceof Long) {
                    return (Long) value;
                } else if (value instanceof String) {
                    return Long.valueOf((String) value);
                } else if (value instanceof Float) {
                    return ((Float) value).longValue();
                } else if (value instanceof Integer) {
                    return ((Integer) value).longValue();
                } else if (value instanceof Double) {
                    return ((Double) value).longValue();
                }
            }
            return  null;
        }

        public Float getFloat(String cName) {
            Object value = cArrayMap.get(cName);

            if(value != null) {
                if (value instanceof Float) {
                    return (Float) value;
                } else if (value instanceof String) {
                    return Float.valueOf((String) value);
                } else if (value instanceof Long) {
                    return ((Long) value).floatValue();
                } else if (value instanceof Integer) {
                    return ((Integer) value).floatValue();
                } else if (value instanceof Double) {
                    return ((Double) value).floatValue();
                }
            }
            return  null;
        }

        public Double getDouble(String cName) {
            Object value = cArrayMap.get(cName);

            if(value != null) {
                if (value instanceof Double) {
                    return (Double) value;
                } else if (value instanceof String) {
                    return Double.valueOf((String) value);
                } else if (value instanceof Long) {
                    return ((Long) value).doubleValue();
                } else if (value instanceof Integer) {
                    return ((Integer) value).doubleValue();
                } else if (value instanceof Float) {
                    return ((Float) value).doubleValue();
                }
            }
            return null;
        }
        public boolean isNull(String cName) {
            return ( cArrayMap.get(cName) == null ? true : false);
        }

    }

}
