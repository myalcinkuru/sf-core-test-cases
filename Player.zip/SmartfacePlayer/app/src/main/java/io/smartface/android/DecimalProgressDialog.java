package io.smartface.android;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.NumberFormat;

import io.smartface.SmartfaceDemo.R;

/**
 * Created by metehantoksoy on 3/16/17.
 * Modified by yunus-atmaca on 7/29/19.
 * DecimalProgressDialog is implemented for showing decimal progress
 * values on progress dialog.
 */
public class DecimalProgressDialog extends Dialog {
    public static int STYLE_SPINNER = 0;
    public static int STYLE_HORIZONTAL = 1;

    private TextView progressBarMessage;
    private ProgressBar progressBar;
    private TextView progressPercent;
    private TextView progressNumber;

    //Using for internally
    private float mMax;
    private float mProgressVal;
    private ProgressUpdateListener listener;
    private NumberFormat mProgressPercentFormat;
    private String mNumberFormat;

    public DecimalProgressDialog(Context context) {
        super(context);
    }

    /**
     * Set message of progressDialog
     * @param message the message to set
     */
    public void setMessage(String message){
        progressBarMessage.setText(message);
    }

    /**
     * Set style of progressDialog
     * @param style the style to set
     */
    private void setProgressStyle(int style){
        if(style == STYLE_HORIZONTAL){
            setContentView(R.layout.horizontal_progress_bar);
        }
        else if(style == STYLE_SPINNER){
            setContentView(R.layout.spinner_progress_bar);
        }
    }

    /**
     * Set indeterminate of progressDialog
     * @param indeterminate the indeterminate to set
     */
    private void setIndeterminate(boolean indeterminate){
        progressBar.setIndeterminate(indeterminate);
    }

    /**
     * Set common properties of progressDialog
     * @param progressDialogStyle the style to set
     * @param message the message to set
     * @param indeterminate the indeterminate to set
     */
    public void setCommonProps(int progressDialogStyle, String message, boolean indeterminate){
        setProgressStyle(progressDialogStyle);
        initializeFormats();
        initializeProgressDialogUI(progressDialogStyle);
        setMessage(message);
        setCancelable(false);
        setIndeterminate(indeterminate);
        setProgress(0);
    }

    /**
     * Initialize progressDialog's UI
     * @param progressDialogStyle the style to set
     */
    private void initializeProgressDialogUI(int progressDialogStyle){
        if(progressDialogStyle == STYLE_HORIZONTAL){
            this.progressBar = findViewById(R.id.progress_bar_horizontal);
            this.progressBarMessage = findViewById(R.id.title_progress_bar);
            this.progressPercent = findViewById(R.id.progress_percent);
            this.progressNumber = findViewById(R.id.progress_number);
        }else if(progressDialogStyle == STYLE_SPINNER) {
            this.progressBar = findViewById(R.id.progress_bar_spinner);
            this.progressBarMessage = findViewById(R.id.title_progress_bar);
        }
    }

    /**
     * Assigning default formats.
     */
    private void initializeFormats() {
        mProgressPercentFormat = NumberFormat.getPercentInstance();
        mProgressPercentFormat.setMaximumFractionDigits(0);
        mNumberFormat = "%1.2f MB / %2.2f MB";
    }

    /**
     * Set max value of the progress.
     * Implemented for working with float values.
     * @param max Max value of the progress.
     */
    public void setMax(float max) {
        mMax = max;
        if(progressBar != null){
            progressBar.setMax((int) max);
        }
    }

    /**
     * Set max value of the progress.
     * Overloaded for prevent ProgressDialog handle this property itself.
     * @param max Max value of the progress.
     */
    public void setMax(int max){
        setMax((float)max);
    }

    /**
     * Set progress.
     * Implemented for working with float values.
     * @param value progress value
     */
    public void setProgress(float value) {
        mProgressVal = value;
        if(progressBar != null){
            progressBar.setProgress((int)value);
        }
        if(progressNumber != null && progressPercent != null){
            updateTextViews();
        }
    }

    /**
     * Set progress.
     * Overloaded for prevent ProgressDialog handle this property itself.
     * @param value progress value
     */
    public void setProgress(int value) {
        setProgress((float) value);
    }

    /**
     * Increment progress by diff value.
     * Implemented for working with float values.
     * @param diff increment amount
     */
    public void incrementProgressBy(float diff) {
        setProgress(mProgressVal + diff);
    }

    /**
     * Increment progress by diff value.
     * Overloaded for prevent ProgressDialog handle this property itself.
     * @param diff increment amount
     */
    public void incrementProgressBy(int diff) {
        incrementProgressBy((float) diff);
    }

    /**
     * Update textView internal if they are successfully get.
     */
    private void updateTextViews() {
        if(listener != null){
            progressNumber.setText(listener.onProgressUpdate(mProgressVal, mMax));
        }
        else {
            progressNumber.setText(String.format(mNumberFormat,mProgressVal, mMax));
        }

        float percent =  mProgressVal / mMax;
        if(Float.isNaN(percent) || Float.isInfinite(percent)){
            percent = 0;
        }
        SpannableString tmp = new SpannableString(mProgressPercentFormat.format(percent));
        tmp.setSpan(new StyleSpan(Typeface.NORMAL),
                0, tmp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        this.progressPercent.setText(tmp);
    }

    /**
     * Set listener of progress change. Listener will be triggered when progress changes.
     * @param listener
     */
    public void setOnProgressUpdateListener(ProgressUpdateListener listener){
        this.listener = listener;
    }

    /**
     * Listener of progress change.
     */
    public interface ProgressUpdateListener{
        String onProgressUpdate(float current, float total);
    }
}