package io.smartface.android.utils;

import android.content.pm.PackageManager;
import java.io.File;

import io.smartface.android.SpratAndroidActivity;

public class RootDetectionUtil {

    public  boolean checkAppPackages(String[] pNames){
        boolean packageFound = false;
        for(String pName : pNames){
            try {
                SpratAndroidActivity.getActivity().getPackageManager().getPackageInfo(pName, 0);
                packageFound = true;
                break;
            }catch (PackageManager.NameNotFoundException e){
                //ignore
            }
        }
        return packageFound;
    }

    public boolean checkSuBinaryExistance(String[] suAbsBinaryPaths){
        boolean suFilesThere = false;
        for (String suAbsBinaryPath : suAbsBinaryPaths) {
            File suFile = new File(suAbsBinaryPath, "su");
            suFilesThere = suFile.exists();
            if(suFilesThere)
                break;
        }
        return  suFilesThere;
    }

     public boolean checkRootAccessGained(String[] systemPaths){
        boolean accessGained = false;
        for (String systemPath : systemPaths) {
            File sPath = new File(systemPath);
            if(accessGained = sPath.canWrite())
                break;
        }
        return  accessGained;
    }
}
