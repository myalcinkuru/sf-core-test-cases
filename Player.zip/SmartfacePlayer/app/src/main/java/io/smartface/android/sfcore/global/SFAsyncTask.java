package io.smartface.android.sfcore.global;

import android.os.AsyncTask;
import io.smartface.ExposingEngine.ExchangeValue;
import io.smartface.ExposingEngine.JavaJsInterface;

import io.smartface.plugin.SMFJSObject;

public class SFAsyncTask extends AsyncTask<Void, Void, Void> {
    final int RUN = 1;
    final int END = 2;
    final int PRERUN = 3;
    final int ONCANCELLED = 4;

    SMFJSObject callbacks;

    protected Void doInBackground(Void... params) {
        callJsCallback(RUN);
        return null;
    }

    protected void onPostExecute(Void result) {
        callJsCallback(END);
    }

    @Override
    protected void onPreExecute() {
        callJsCallback(PRERUN);
    }

    @Override
    protected void onCancelled() {
        callJsCallback(ONCANCELLED);
    }

    public void setJsCallback(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }

    public void executeTask() {
        this.execute();
    }

    private void callJsCallback(int stateID) {
        try {
            SMFJSObject jsCallback = null;
            switch (stateID) {
            case RUN:
                if (this.callbacks.hasProperty("doInBackground")) {
                    jsCallback = this.callbacks.getProperty("doInBackground");
                }
                break;
            case END:
                if (this.callbacks.hasProperty("onPostExecute")) {
                    jsCallback = this.callbacks.getProperty("onPostExecute");
                }
                break;
            case PRERUN:
                if (this.callbacks.hasProperty("onPreExecute")) {
                    jsCallback = this.callbacks.getProperty("onPreExecute");
                }
                break;
            case ONCANCELLED:
                if (this.callbacks.hasProperty("onCancelled")) {
                    jsCallback = this.callbacks.getProperty("onCancelled");
                }
                break;
            default:
                break;
            }
            if (jsCallback != null) {
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}