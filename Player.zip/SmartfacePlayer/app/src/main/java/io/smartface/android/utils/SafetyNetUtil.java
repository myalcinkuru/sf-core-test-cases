package io.smartface.android.utils;

import androidx.annotation.NonNull;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.nio.charset.StandardCharsets;
import java.util.Random;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;

public final class SafetyNetUtil {
    private final String apiKey;

    public SafetyNetUtil(String apiKey){
        this.apiKey = apiKey;
    }

    public void sendAttestationRequest(String nonce, final SMFJSObject callbacks){
        SafetyNet.getClient(SpratAndroidActivity.getActivity()).attest(nonce.getBytes(StandardCharsets.UTF_8), apiKey)
                .addOnSuccessListener(new OnSuccessListener<SafetyNetApi.AttestationResponse>() {
                    @Override
                    public void onSuccess(SafetyNetApi.AttestationResponse attestationResponse) {
                        String safetyNetJws = attestationResponse.getJwsResult();
                        try {
                            SMFJSObject smfjsObject = callbacks.getProperty("onSuccess");
                            smfjsObject.callAsNativeFunctionNew(smfjsObject.jsValueRef, new String[]{safetyNetJws});
                        }catch (Exception e ){
                            e.printStackTrace();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        try {
                            SMFJSObject smfjsObject = callbacks.getProperty("onFailure");
                            smfjsObject.callAsNativeFunctionNew(smfjsObject.jsValueRef, new String[]{e.getMessage()});
                        }catch (Exception  exc){
                            exc.printStackTrace();
                        }
                    }
                });
    }

    public String generateNonce(){
        byte[] rByte = new byte[16];
        new Random().nextBytes(rByte);
        return  new String(rByte, StandardCharsets.UTF_8);
    }

    public boolean isPlayServicesAvailable(){
        return GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(SpratAndroidActivity.getActivity()) == ConnectionResult.SUCCESS;
    }
}
