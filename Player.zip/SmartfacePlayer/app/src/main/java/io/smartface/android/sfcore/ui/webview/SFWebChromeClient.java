package io.smartface.android.sfcore.ui.webview;

import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.net.Uri;

import io.smartface.plugin.SMFJSObject;

public class SFWebChromeClient extends WebChromeClient {
    SMFJSObject callbacks = null;

    public SFWebChromeClient(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }

    @Override
    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onConsoleMessage");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{
                    consoleMessage.sourceId(), consoleMessage.message(),
                    consoleMessage.lineNumber(),consoleMessage.messageLevel().toString()});
            return ((boolean)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return super.onConsoleMessage(consoleMessage);
    }

    @Override
    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                        FileChooserParams fileChooserParams) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onShowFileChooser");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{filePathCallback});
            return ((boolean)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}