package io.smartface.android.utils;

import android.content.res.ColorStateList;

/*
The intention of creation this util is enable to use some of ColorStateList methods in Smartface.
A few method might not be used in Smartface. Such as valueOf , etc methods are confuses with JavaScripts methods.
That causes the error in runtime.
 */

public class ColorStateListUtil {
    public  static ColorStateList getColorStateListWithValueOf(int color){
        return ColorStateList.valueOf(color);
    }
}
