package io.smartface.android.bitmaps;

import java.nio.ByteBuffer;

import android.graphics.Bitmap;

public class JniBitmapHolder {
    ByteBuffer _handler = null;
    private static Object staticLock = new Object();
    private final static boolean debug_prints = false;
    private native ByteBuffer jniStoreBitmapData (String path, int width, int height, int returnSize[]);

    private native Bitmap jniGetBitmapFromStoredBitmapData (Bitmap garbageBitmap, String path,
            ByteBuffer handler);

    private native long jniFreeBitmapData (String path, ByteBuffer handler);

    private native void jniRotateBitmapCcw90 (ByteBuffer handler);

    private native void jniRotateBitmapCw90 (ByteBuffer handler);

    private native void jniCropBitmap (ByteBuffer handler, final int left, final int top,
                                       final int right, final int bottom);

    private native void jniScaleNNBitmap (ByteBuffer handler, final int newWidth, final int newHeight);

    public JniBitmapHolder() {
    }
    private String path;
    private int realWidth;
    private int realHeight;
    public JniBitmapHolder (final String path, int width, int height) {
        this.path = path;
        storeBitmap (path, width, height);
    }
    public int getWidth() {
        return realWidth;
    }
    public int getHeight() {
        return realHeight;
    }

    public void storeBitmap (final String path, int width, int height) {
        this.path = path;

        if (_handler != null) {
            long ti = System.currentTimeMillis();

            if (debug_prints) {
                System.out.println ("JniBitmapHolder.storeBitmap.freeBitmap <");
            }

            freeBitmap();

            if (debug_prints) {
                System.out.println ("JniBitmapHolder.storeBitmap.freeBitmap >");
            }

            ti = System.currentTimeMillis() - ti;

            if (debug_prints) {
                System.out.println ("JniBitmapHolder.storeBitmap(1): path=" + path + ",w=" + width + ",h=" + height
                                    + ", time=" + ti);
            }
        }

        long ti = System.currentTimeMillis();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.storeBitmap.jniStoreBitmapData <");
        }

        synchronized (staticLock) {
            int returnSize[] = {0, 0};
            _handler = jniStoreBitmapData (path, width, height, returnSize);
            realWidth = returnSize[0];
            realHeight = returnSize[1];
        }

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.storeBitmap.jniStoreBitmapData >");
        }

        ti = System.currentTimeMillis() - ti;

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.storeBitmap(2): path=" + path + ",w=" + width + ",h=" + height
                                + ", realWidht=" + realWidth + ", realHeight=" + realHeight + ", time=" + ti);
        }
    }
    public boolean ok() {
        return true;
    }

    public Bitmap getBitmap (Bitmap garbageBitmap, int width, int height) {
        if (_handler == null) {
            return null;
        }

        long ti = System.currentTimeMillis();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmap <");
        }

        Bitmap b = jniGetBitmapFromStoredBitmapData (garbageBitmap, path, _handler);

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmap >");
        }

        ti = System.currentTimeMillis() - ti;

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmap: path=" + path + ",w=" + width + ",h=" + height +
                                ", time=" + ti);
        }

        return b;
    }

    public Bitmap getBitmapAndFree (int width, int height) {
        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmapAndFree.getBitmap <");
        }

        final Bitmap bitmap = getBitmap (null, width, height);

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmapAndFree.getBitmap >");
        }

        long ti = System.currentTimeMillis();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmapAndFree.freeBitmap <");
        }

        freeBitmap();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.getBitmapAndFree.freeBitmap >");
        }

        ti = System.currentTimeMillis() - ti;

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.freeBitmap: path=" + path + ",w=" + width + ",h=" + height +
                                ", time=" + ti);
        }

        return bitmap;
    }

    public long freeBitmap() {
        if (_handler == null) {
            return 0;
        }

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.freeBitmap <");
        }

        long retval;

        synchronized (staticLock) {
            retval = jniFreeBitmapData (path, _handler);
        }

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.freeBitmap >");
        }

        _handler = null;
        return retval;
    }

    @Override
    protected void finalize() throws Throwable {
        if (debug_prints) {
            System.out.println ("JniBitmapHolder.finalize1 <");
        }

        super.finalize();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.finalize1 >");
        }

        if (_handler == null) {
            return;
        }

        if (debug_prints) {
            System.out.println ("finalize1");
        }

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.finalize2 <");
        }

        freeBitmap();

        if (debug_prints) {
            System.out.println ("JniBitmapHolder.finalize2 >");
        }

        if (debug_prints) {
            System.out.println ("finalize2");
        }
    }

    public void rotateBitmapCcw90() {
        if (_handler == null) {
            return;
        }

        jniRotateBitmapCcw90 (_handler);
    }

    public void rotateBitmapCw90() {
        if (_handler == null) {
            return;
        }

        jniRotateBitmapCw90 (_handler);
    }

    public void cropBitmap (final int left, final int top, final int right,
                            final int bottom) {
        if (_handler == null) {
            return;
        }

        jniCropBitmap (_handler, left, top, right, bottom);
    }

    public void scaleBitmap (final int newWidth, final int newHeight) {
        if (_handler == null) {
            return;
        }

        jniScaleNNBitmap (_handler, newWidth, newHeight);
    }
}