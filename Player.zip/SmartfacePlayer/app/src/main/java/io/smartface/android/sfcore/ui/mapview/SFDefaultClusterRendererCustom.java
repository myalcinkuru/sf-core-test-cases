package io.smartface.android.sfcore.ui.mapview;

import android.content.Context;

import com.google.android.gms.maps.GoogleMap;
import com.google.maps.android.clustering.ClusterManager;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.ui.SquareTextView;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;
import io.smartface.android.sfcore.ui.mapview.DefaultClusterRendererCustom;
import io.smartface.android.sfcore.ui.mapview.MapClusterItem;

public class  SFDefaultClusterRendererCustom {
    private SMFJSObject callbacks = null;

    private Context context;
    private GoogleMap map;
    private ClusterManager manager;
    
    public SFDefaultClusterRendererCustom(SMFJSObject callbacks,Context context, GoogleMap map, ClusterManager manager){
        this.context = context;
        this.map = map;
        this.manager = manager;
        this.callbacks = callbacks;
    }

    public SFCustomizeClusterRender getPersonRenderer(){
        return new SFCustomizeClusterRender();
    }
    
    private class SFCustomizeClusterRender extends DefaultClusterRendererCustom<MapClusterItem> {
    
    public SFCustomizeClusterRender() {
        super(context, map, manager);
    }

    /**
     * Called before the marker for a ClusterItem is added to the map.
     */
    protected void onBeforeClusterItemRendered(MapClusterItem item, MarkerOptions markerOptions) {
        try {
            SMFJSObject jsCallback = callbacks.getProperty("onBeforeClusterItemRendered");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{item,markerOptions});
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Determine whether the cluster should be rendered as individual markers or a cluster.
     */
    protected boolean shouldRenderAsCluster(Cluster cluster) {
        try {
            SMFJSObject jsCallback = callbacks.getProperty("shouldRenderAsCluster");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{cluster.getSize()});
            return ((boolean)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    protected int getColor(int clusterSize) {
        try {
            SMFJSObject jsCallback = callbacks.getProperty("getColor");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
            return ((int)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public SquareTextView makeSquareTextView(Context context) {
        try {
            SMFJSObject jsCallback = callbacks.getProperty("makeSquareTextView");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{context});
            return ((SquareTextView)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return new SquareTextView(context);
        }

    @Override
    public int setOutlineColor() {
        try {
            SMFJSObject jsCallback = callbacks.getProperty("setOutlineColor");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
            return ((int)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
        }

        
}
}