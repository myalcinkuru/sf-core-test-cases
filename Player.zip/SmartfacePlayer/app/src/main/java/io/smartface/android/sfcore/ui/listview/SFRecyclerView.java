package io.smartface.android.sfcore.ui.listview;

import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ContextThemeWrapper;
import android.content.Context;

import java.lang.Exception;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.ExchangeValue;

public class SFRecyclerView extends RecyclerView {
    private GestureDetector mGestureDetector;
    private SMFJSObject onScrollJsCallback = null;
    public SMFJSObject dynamicCallbacks = null;
    public SMFJSObject constCallbacks = null;

    public SFRecyclerView(ContextThemeWrapper wrapper, SMFJSObject callbacks) {
        super(wrapper);
        constCallbacks = callbacks;
        mGestureDetector = new GestureDetector(this.getContext(), new SFScrollDetector());
    }

    public SFRecyclerView(Context context, SMFJSObject callbacks) {
        super(context);
        constCallbacks = callbacks;
        mGestureDetector = new GestureDetector(this.getContext(), new SFScrollDetector());
    }

    public void setJsCallbacks(SMFJSObject callbacks) {
        this.onScrollJsCallback = null;
        this.dynamicCallbacks = callbacks;
        this.initOnScrollCallback();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        try {
            SMFJSObject jsCallback = constCallbacks.getProperty("onAttachedToWindow");
            ExchangeValue ret = jsCallback.callAsFunctionNew(jsCallback.jsValueRef, null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        try {
            SMFJSObject jsCallback = constCallbacks.getProperty("onDetachedFromWindow");
            ExchangeValue ret = jsCallback.callAsFunctionNew(jsCallback.jsValueRef, null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        boolean returnFromSuper = super.onInterceptTouchEvent(ev);
        if (onScrollJsCallback != null) {
            return mGestureDetector.onTouchEvent(ev);
        }
        return returnFromSuper;
    }

    public void initOnScrollCallback() {
        try {
            if (this.dynamicCallbacks == null) {
                return;
            }
            this.onScrollJsCallback = this.dynamicCallbacks.getProperty("onScrollGesture");
            if (this.onScrollJsCallback == null)
                return;

            if (this.onScrollJsCallback.params == null) {
                this.onScrollJsCallback.params = new ExchangeValue[2];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class SFScrollDetector extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            try {
                Object[] params = { distanceX, distanceY };
                Object result = onScrollJsCallback.callAsNativeFunctionNew(onScrollJsCallback.jsValueRef, params);
                return ((boolean) result);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    }
}