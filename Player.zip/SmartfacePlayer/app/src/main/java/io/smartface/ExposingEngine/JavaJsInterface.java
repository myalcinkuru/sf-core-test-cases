package io.smartface.ExposingEngine;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.ArrayList;

/**
 *  This class is the communication interface between C++/Java for exposing engine. Jni methods
 *  (such as JsJavaInterface.cpp) calls JavaJsInterface class' methods to run Java code from JavaScript. 
 *
 *  Exposing engine's responsibilities are requiring Java class, creating an instance of exposed class,
 *  getting a class' or object's property,which can be a field or method, setting a class' or object's 
 *  property or run a method of class or object.
 */
public class JavaJsInterface {
    /**
     *  Holding exposed classes in cache to not get everytime from runtime
     */
    private static Map<String, ExchangeValue> classCache = new HashMap<>();

    /**
     *  Returns required Java class from runtime, Java class is wrapped in ExchangeValue object.
     *
     *  @param  name    Full name of the required class (e.g. java.lang.String)
     *  @return         Required class as object wrapped inside ExchangeValue object, null if required
     *                  class is not found in runtime
     */
    public static ExchangeValue RequireClass(String name) {
        ExchangeValue integerObject = classCache.get(name);

        if (integerObject != null) {
            return integerObject;
        }

        JsAbstractObject clazz = JsClassManager.GetClass(name);
        if (clazz == null) return null;

        ExchangeValue returnType = new ExchangeValue();
        returnType.objectId = JsObjectCollection.add(clazz);;
        classCache.put(name, returnType);

        return returnType;
    }

    /**
     *  Creates an instance from given class with given parameters. A Java class may contain one or
     *  more constructors, a suitable constructor is found according to given parameters. This method
     *  may throw exception if an exception occurs while creating instance.
     *
     *  @param  classValue      Class object wrapped in ExchangeValue
     *  @param  parameterValues Parameters to be passed to suitable constructor
     *  @return                 Created instance wrapped in ExchangeValue, null if an instance couldn't
     *                          be created
     */
    public static ExchangeValue ConstructObject(ExchangeValue classValue, ExchangeValue[] parameterValues) throws Throwable {
        if (classValue.type != ExchangeValue.Type.OBJECT) return null;

        JsAbstractObject object = (JsAbstractObject) JsObjectCollection.get(classValue.objectId);
        Object[] parameterObjects = new Object[0];
        if (parameterValues != null) {
            parameterObjects = new Object[parameterValues.length];
            for (int i = 0; i < parameterValues.length; i++) {
                parameterObjects[i] = unwrapValue(parameterValues[i]);
            }
        }

        if (object != null && object instanceof JsClass) {
            JsClass jsClass = (JsClass) object;
            JsAbstractObject result = jsClass.createInstance(parameterObjects);
            return wrapValue(result);
        }

        return null;
    }

    /**
     *  Returns the requested property of class or object. Property is requested by name, if property
     *  is a Java field its value is returned, if property is a Java method a Method object is returned
     *  as it represents the Java method.
     *
     *  @param  value   The target object to get property from, this can be a class or object
     *  @param  name    Requested property's name
     *  @return         Requested property's value wrapped in ExchangeValue
     */
    public static ExchangeValue GetProperty(ExchangeValue value, String name) throws Exception {
        if (value.type != ExchangeValue.Type.OBJECT) return null;

        JsAbstractObject object = (JsAbstractObject) JsObjectCollection.get(value.objectId);
        if (object != null) {
            JsAbstractObject result = object.getProperty(name);
            return wrapValue(result);
        }

        return null;
    }

    /**
     *  Sets the property of the target object.
     *
     *  @param  objectValue The target object to set property, this can be a class or object
     *  @param  name        Property's name
     *  @param  toSetValue  The value to be set to the property of target object
     *  @return             True if setting operation is successful, false otherwise
     */
    public static boolean SetProperty(ExchangeValue objectValue, String name, ExchangeValue toSetValue) {
        if (objectValue.type != ExchangeValue.Type.OBJECT) return false;

        JsAbstractObject object = (JsAbstractObject) JsObjectCollection.get(objectValue.objectId);
        if (object != null) {
            Object valueObject = unwrapValue(toSetValue);
            return object.setProperty(name, valueObject);
        }

        return false;
    }

    /**
     *  Invokes method of object or class and returns the result. The objectValue parameter should be
     *  a method that is returned from {@link GetProperty} method. An object or class may have overloaded
     *  methods, in that case given parameters is used to find the correct method.
     *
     *  @param objectValue      The method object that previously returned from {@link GetProperty} method
     *  @param parameterValues  Parameters to be used while finding and calling the method
     *  @return                 Result of the invoked method wrapped in ExchangeValue
     */
    public static ExchangeValue InvokeMethod(ExchangeValue objectValue, ExchangeValue[] parameterValues) throws Throwable {
        if (objectValue.type != ExchangeValue.Type.OBJECT) return null;

        JsAbstractObject jsObject = (JsAbstractObject) JsObjectCollection.get(objectValue.objectId);
        if (!(jsObject instanceof JsMethod)) throw new NoSuchMethodException(jsObject.toString() + " is not a function");

        JsMethod method = (JsMethod) jsObject;
        Method javaMethod = (Method) method.getJavaObject();
        Object[] parametersAsArray = new Object[parameterValues.length];
        for (int i = 0; i < parameterValues.length; i++) {
            Object value = unwrapValue(parameterValues[i]);
            parametersAsArray[i] = value;
        }

        JsAbstractObject holder = method.getHolder();
        JsAbstractObject result = holder.invokeMethod(javaMethod.getName(), parametersAsArray);
        return wrapValue(result);
    }

    /**
     *  TODO    this method is planned to get element of an array wrapped in ExchangeValue. Currently
     *          it is not used and not complete.
     */
    public static ExchangeValue GetElementAtIndex(ExchangeValue objectValue, int index) throws Throwable {
        if (objectValue.type != ExchangeValue.Type.OBJECT) return null;

        Object object = JsObjectCollection.get(objectValue.objectId);
        if (object instanceof JsAbstractObject) {
            object = ((JsAbstractObject)object).getJavaObject();
        }

        if (!object.getClass().isArray()) {
            throw new Exception("Given object is not an array");
        }

        return wrapValue(Array.get(object, index));
    }

    /**
     *  Clears the class cache filled by RequireClass method.
     */
    public static void ClearCache() {
        classCache.clear();
    }

    /**
     *  This method unwraps the actual object from ExchangeValue. Primitive values wrapped in ExchangeValue
     *  will be returned in its Object type, e.g. int value will be returned as Integer object.
     *
     *  @param  value   Wrapped object
     *  @return         Unwrapped actual object
     */
    public static Object unwrapValue(ExchangeValue value) {
        if (value == null) return null;

        switch (value.type) {
            case ExchangeValue.Type.OBJECT: {
                Object object = JsObjectCollection.get(value.objectId);
                return unwrapJSObject(object);
            }
            case ExchangeValue.Type.INT:
                return value.intValue;
            case ExchangeValue.Type.DOUBLE:
                return value.doubleValue;
            case ExchangeValue.Type.LONG:
                return value.longValue;
            case ExchangeValue.Type.FLOAT:
                return value.floatValue;
            case ExchangeValue.Type.BOOLEAN:
                return value.booleanValue;
            case ExchangeValue.Type.STRING:
                return value.stringValue;
        }
       
        return null;
    }

    public static Object unwrapJSObject(Object object) {
        if (object instanceof JsAbstractObject) {
            object = ((JsAbstractObject)object).getJavaObject();
        }

        if(object instanceof ExchangeValue) {
            ExchangeValue exchangeValue = (ExchangeValue)object;
            switch(exchangeValue.type) {
                case ExchangeValue.Type.STRINGARRAY:
                    return exchangeValue.stringArray;
                case ExchangeValue.Type.BYTEARRAY:
                    return exchangeValue.byteArray;
                case ExchangeValue.Type.SHORTARRAY:
                    return exchangeValue.shortArray;
                case ExchangeValue.Type.INTARRAY:
                    return exchangeValue.intArray;
                case ExchangeValue.Type.FLOATARRAY:
                    return exchangeValue.floatArray;
                case ExchangeValue.Type.DOUBLEARRAY:
                    return exchangeValue.doubleArray;
                case ExchangeValue.Type.LONGARRAY:
                    return exchangeValue.longArray;
                case ExchangeValue.Type.BOOLEANARRAY:
                    return exchangeValue.booleanArray;
                case ExchangeValue.Type.OBJECTARRAY:
                    return exchangeValue.objectArray;
            }
        } else {
            return object;
        }
        return null;
    }

    /**
     *  This method wraps given object inside an ExchangeValue object.
     *
     *  @param  object  Object to be wrapped
     *  @return         Wrapped ExchangeValue object
     */
    public static ExchangeValue wrapValue(Object object) {
        if (object == null) return null;

        ExchangeValue returnValue = new ExchangeValue();
        Object actualObject = object;
        if (actualObject instanceof JsAbstractObject) {
            actualObject = ((JsAbstractObject)object).getJavaObject();
        }

        if (actualObject instanceof Integer) {
            returnValue.type = ExchangeValue.Type.INT;
            returnValue.intValue = ((Integer)actualObject).intValue();
        } else if(actualObject instanceof Double) {
            returnValue.type = ExchangeValue.Type.DOUBLE;
            returnValue.doubleValue = ((Double)actualObject).doubleValue();
        } else if(actualObject instanceof Long) {
            returnValue.type = ExchangeValue.Type.LONG;
            returnValue.longValue = ((Long)actualObject).longValue();
        } else if(actualObject instanceof Float) {
            returnValue.type = ExchangeValue.Type.FLOAT;
            returnValue.floatValue = ((Float)actualObject).floatValue();
        } else if(actualObject instanceof Boolean) {
            returnValue.type = ExchangeValue.Type.BOOLEAN;
            returnValue.booleanValue = ((Boolean)actualObject).booleanValue();
        } else if(actualObject instanceof String) {
            returnValue.type = ExchangeValue.Type.STRING;
            returnValue.stringValue = (String) actualObject;
        } else if(actualObject.getClass().isArray()) {
            Class componentClass = actualObject.getClass().getComponentType();
            if (componentClass.isPrimitive()) {
                if (componentClass == byte.class) {
                    returnValue.type = ExchangeValue.Type.BYTEARRAY;
                    returnValue.byteArray = (byte[]) actualObject;
                    returnValue.arrayLength = returnValue.byteArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == short.class) {
                    returnValue.type = ExchangeValue.Type.SHORTARRAY;
                    returnValue.shortArray = (short[]) actualObject;
                    returnValue.arrayLength = returnValue.shortArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == int.class) {
                    returnValue.type = ExchangeValue.Type.INTARRAY;
                    returnValue.intArray = (int[]) actualObject;
                    returnValue.arrayLength = returnValue.intArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == float.class) {
                    returnValue.type = ExchangeValue.Type.FLOATARRAY;
                    returnValue.floatArray = (float[]) actualObject;
                    returnValue.arrayLength = returnValue.floatArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == double.class) {
                    returnValue.type = ExchangeValue.Type.DOUBLEARRAY;
                    returnValue.doubleArray = (double[]) actualObject;
                    returnValue.arrayLength = returnValue.doubleArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == long.class) {
                    returnValue.type = ExchangeValue.Type.LONGARRAY;
                    returnValue.longArray = (long[]) actualObject;
                    returnValue.arrayLength = returnValue.longArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else if (componentClass == boolean.class) {
                    returnValue.type = ExchangeValue.Type.BOOLEANARRAY;
                    returnValue.booleanArray = (boolean[]) actualObject;
                    returnValue.arrayLength = returnValue.booleanArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else {
                    throw new NoSuchFieldError("There is no such field in ExchangeValue for type " + actualObject.getClass().getName());
                }
            } else {
                if (componentClass == String.class) {
                    returnValue.type = ExchangeValue.Type.STRINGARRAY;
                    returnValue.stringArray = (String[]) actualObject;
                    returnValue.arrayLength = returnValue.stringArray.length;
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                } else {
                    returnValue.objectArray = (Object[]) actualObject;
                    returnValue.arrayLength = returnValue.objectArray.length;
                    returnValue.type = ExchangeValue.Type.OBJECTARRAY;

                    if(returnValue.objectArrayId == null) {
                        returnValue.objectArrayId = new ArrayList<Integer>(); 
                    }
                    for(int i = 0; i < returnValue.arrayLength; i++) {
                        ExchangeValue exchValue = wrapValue(returnValue.objectArray[i]);
                        returnValue.objectArrayId.add(exchValue.objectId);
                    }
                    returnValue.objectId = JsObjectCollection.add(new JsObject(returnValue));
                }
            }
        } else {
            if (!(object instanceof JsAbstractObject)) {
                object = new JsObject(object);
            }
            returnValue.objectId = JsObjectCollection.add(object);
        }

        return returnValue;
    }
}