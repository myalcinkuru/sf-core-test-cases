package io.smartface.plugin;

import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.List;

import io.smartface.android.SpratAndroidActivity;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMethod;
import javassist.CtNewConstructor;
import javassist.NotFoundException;

public class SMFCtClassFactory {

    private static HashMap<String, String> returnCommandMap;

    static {
        returnCommandMap = new HashMap<String, String>();
        returnCommandMap.put("void"   , "");
        returnCommandMap.put("int"    , "return res == null ? 0 : ((java.lang.Integer)res).intValue();");
        returnCommandMap.put("boolean", "return res == null ? false : ((java.lang.Boolean)res).booleanValue();");
        returnCommandMap.put("double" , "return res == null ? 0 : ((java.lang.Double)res).doubleValue();");
        returnCommandMap.put("long"   , "return res == null ? 0 : ((java.lang.Long)res).longValue();");
    }

    static ClassPool cp = ClassPool.getDefault(SpratAndroidActivity.getInstance().getApplicationContext());

    public static CtClass create(String className, String superName, List<String> methods, List<String> methodsWithSuperCall) throws NotFoundException, CannotCompileException {
        CtClass generatedClass = cp.makeClass(className);
        CtClass superClass = cp.get(superName);
        generatedClass.setSuperclass(superClass);

        CtField callbacks = CtField.make("public io.smartface.plugin.SMFJSObject callbacks;", generatedClass);
        generatedClass.addField(callbacks);
        addConstructors(generatedClass, superClass);
        addMethods(generatedClass, superClass, methods);
        addMethods(generatedClass, superClass, methodsWithSuperCall, true);

        return generatedClass;
    }

    private static void addConstructors(CtClass generatedClass, CtClass superClass) throws NotFoundException, CannotCompileException {
        CtConstructor[] declaredConstructors = superClass.getConstructors();
        for (CtConstructor constructor : declaredConstructors) {
            String constructorBody = "{}";
            if(constructor.getParameterTypes().length > 0) {
                constructorBody = "super($$);";
            }
            CtConstructor classConstructor = CtNewConstructor.make(constructor.getParameterTypes(), constructor.getExceptionTypes(), constructorBody, generatedClass);
            classConstructor.setModifiers(classConstructor.getModifiers() & ~Modifier.ABSTRACT);
            generatedClass.addConstructor(classConstructor);
        }
    }

    private static void addMethods(CtClass generatedClass, CtClass superClass, List<String> methods) throws NotFoundException, CannotCompileException {
        addMethods(generatedClass, superClass, methods, false);
    }

    private static void addMethods(CtClass generatedClass, CtClass superClass, List<String> methods, boolean callSuperForAll) throws NotFoundException, CannotCompileException {
        for(String methodName : methods){
            if(methodName != null) {
                CtMethod ctm = findMethod(superClass, methodName);
                if(ctm != null) {
                    StringBuilder body = new StringBuilder();
                    body.append("{");
                    if(callSuperForAll){
                        body.append("super.").append(methodName).append("($$);");
                    }
                    body.append("io.smartface.ExposingEngine.ExchangeValue[] arguments = new io.smartface.ExposingEngine.ExchangeValue[$args.length];");
                    CtClass[] parameterTypes = ctm.getParameterTypes();
                    for (int i = 0; i < parameterTypes.length; i++) {
                        body.append("arguments[").append(i).append("] = io.smartface.ExposingEngine.JavaJsInterface.wrapValue($args[").append(i).append("]);");
                    }

                    body.append("java.lang.Object res = null;");
                    body.append("io.smartface.plugin.SMFJSObject callback = callbacks.getProperty(\"").append(methodName).append("\");");
                    body.append("io.smartface.ExposingEngine.ExchangeValue ret = callback.callAsFunctionNew(callback.jsValueRef, arguments);");

                    if (returnCommandMap.containsKey(ctm.getReturnType().getName())) {
                        body.append("if(ret != null)")
                                .append("res = io.smartface.ExposingEngine.JavaJsInterface.unwrapValue(ret);");
                        body.append(returnCommandMap.get(ctm.getReturnType().getName()));
                    } else {
                        if (!ctm.getReturnType().isPrimitive()) {
                            body.append("if(ret == null) return null;" )
                                    .append("res = io.smartface.ExposingEngine.JavaJsInterface.unwrapValue(ret);")
                                    .append("return  ($r)res;");
                        }
                    }
                    body.append("}");

                    CtMethod m = new CtMethod(ctm.getReturnType(), ctm.getName(), ctm.getParameterTypes(), body.toString(), generatedClass);
                    m.setModifiers(m.getModifiers() & ~Modifier.ABSTRACT);
                    generatedClass.addMethod(m);
                }
            }
        }
    }

    private static CtMethod findMethod(CtClass superClass, String methodName) {
        try{
            // Find method as declareted
            return superClass.getDeclaredMethod(methodName);

        }
        catch (NotFoundException e){
            for (CtMethod ctm : superClass.getMethods()) {
                if(Modifier.toString(ctm.getModifiers()).contains("abstract") || (methodName.equals(ctm.getName()))){
                    return ctm;
                }
            }
        }
        return null;
    }

}
