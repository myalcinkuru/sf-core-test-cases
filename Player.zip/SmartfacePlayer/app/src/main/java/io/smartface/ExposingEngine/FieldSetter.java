package io.smartface.ExposingEngine;

import java.lang.reflect.Field;

public class FieldSetter extends PropertySetter {
    public FieldSetter(Field field) {
        super(field);
    }

    @Override
    public boolean set(Object holder, Object value) {
        try {
            ((Field) propertyObject).set(holder, value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
