package io.smartface.android.notifications;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Environment;
import android.view.View;
import android.widget.RemoteViews;
import java.io.File;
import io.smartface.SmartfaceDemo.A;
import io.smartface.SmartfaceDemo.R;
import io.smartface.android.SpratAndroidActivity;

/**
 * WidgetProvider is a class for listening and managing Smartface Native Framework Android Emulator.
 * The intent data's of the actions should be the same as notification because we dont want to make
 * extra operation for handle widgets.
 *
 * Created by metehantoksoy on 6/29/17.
 */
public class WidgetProvider extends AppWidgetProvider {

    private String unsecureDbPath;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final int count = appWidgetIds.length;

        // Updating all widgets. User can create multiple widget.
        for (int widgetId : appWidgetIds) {
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_smartface);

            setApplicationName(context, remoteViews);
            setApplicationIcon(context, remoteViews);

            Class cls;
            try {
                cls = Class.forName(context.getPackageName() + ".A");
            } catch (Exception e) {
                cls = A.class;
            }

            // Start SpratAndroidActivity with scan just as notification click.
            Intent intentScan = new Intent(context, cls);
            intentScan.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intentScan.putExtra("EmulatorNotificationType", "scan");
            PendingIntent scanPIntent = PendingIntent.getActivity(context, SpratAndroidActivity.REQUEST_CODE_EMULATOR_SCAN,
                    intentScan, PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.linearLayout_scan, scanPIntent);

            // Start SpratAndroidActivity with update just as notification click.
            Intent intentUpdate = new Intent(context, cls);
            intentUpdate.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intentUpdate.putExtra("EmulatorNotificationType", "update");
            PendingIntent updatePIntent = PendingIntent.getActivity(context, SpratAndroidActivity.REQUEST_CODE_EMULATOR_UPDATE,
                    intentUpdate, PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.linearLayout_update, updatePIntent);

            // Start SpratAndroidActivity with clear just as notification click.
            Intent intentClear = new Intent(context, cls);
            intentClear.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intentClear.putExtra("EmulatorNotificationType", "clear");
            PendingIntent clearPIntent = PendingIntent.getActivity(context, SpratAndroidActivity.REQUEST_CODE_EMULATOR_CLEAR,
                    intentClear, PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.linearLayout_clear, clearPIntent);

            // Start just activity when user clicked project name or icon.
            Intent intentSpratAndroid = new Intent(context, cls);
            PendingIntent pendingIntentSpratAndroid = PendingIntent.getActivity(context, 0, intentSpratAndroid, 0);
            remoteViews.setOnClickPendingIntent(R.id.linearLayout_projectDetail, pendingIntentSpratAndroid);

            // If zip not exists don't show clear and update options
            if (!(new File(getUnsecureDbPath__N(context) + "/SmartfaceEmulator.zip").exists())) {
                remoteViews.setViewVisibility(R.id.linearLayout_clear, View.GONE);
                remoteViews.setViewVisibility(R.id.linearLayout_update, View.GONE);
            } else {
                remoteViews.setViewVisibility(R.id.linearLayout_clear, View.VISIBLE);
                remoteViews.setViewVisibility(R.id.linearLayout_update, View.VISIBLE);
            }

            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }
    }

    private void setApplicationIcon(Context context, RemoteViews remoteViews) {
        String projectIconFile = findProjectIconFile(context);
        if(projectIconFile != null){
            remoteViews.setImageViewBitmap(R.id.imageView_icon, BitmapFactory.decodeFile(projectIconFile));
        }
        else {
            remoteViews.setImageViewResource(R.id.imageView_icon, R.drawable.icon);
        }
    }

    private void setApplicationName(Context context, RemoteViews remoteViews) {
        SharedPreferences settings = context.getSharedPreferences(SpratAndroidActivity.EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        String projectName = settings.getString(SpratAndroidActivity.EMULATOR_PROJECT_NAME, null);

        if(projectName != null){
            remoteViews.setTextViewText(R.id.textView_projectTitle, projectName);

        }
        else{
            remoteViews.setTextViewText(R.id.textView_projectTitle, context.getString(R.string.widget_noproject));
        }
    }

    public String getUnsecureDbPath__N(Context context) {
        if (unsecureDbPath == null) {
            String s = Environment.getExternalStorageDirectory().toString();
            s += "/Android/data/" + context.getPackageName();

            if (Build.VERSION.SDK_INT >= 8) {
                String cache_dir = "" + context.getExternalCacheDir();

                if (!cache_dir.equals ("null")) {
                    s = cache_dir;

                } else {
                    s += "/cache";
                }
            }

            File f = new File (s);

            if (!f.exists()) {
                boolean dir = f.mkdirs();
                System.out.println ("dir:" + dir);

                if (!dir) {
                    f = context.getFilesDir();
                    s = f.getAbsolutePath();
                }
            }

            unsecureDbPath = s;
        }

        return unsecureDbPath;
        //return getExternalCacheDir().toString().replace("Demo", "Emulator");
    }

    private String findProjectIconFile(Context context) {
        File emulatorDir = context.getExternalCacheDir();
        if(emulatorDir == null){
            return null;
        }
        String basePath = emulatorDir.getAbsolutePath() + "/res";
        File iconFile = new File(basePath + "/drawable-ldpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable-mdpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable-hdpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable-xhdpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable-xxhdpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable-xxxhdpi/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        iconFile = new File(basePath + "/drawable/icon.png");
        if(iconFile.exists()){
            return iconFile.getAbsolutePath();
        }
        return null;
    }
}
