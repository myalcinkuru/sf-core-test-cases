package io.smartface.android.sfcore.ui.textview;

import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.TypefaceSpan;

public class SFTypefaceSpan extends TypefaceSpan {
	Typeface mTypeface;
	public SFTypefaceSpan(String text, Typeface typeface) {
		super(text);
		mTypeface = typeface;
	}

	@Override
	public void updateDrawState(TextPaint ds) {
		applyCustomTypeFace(ds,mTypeface);
	}

	@Override
	public void updateMeasureState(TextPaint paint) {
		applyCustomTypeFace(paint,mTypeface);
	}

	public void applyCustomTypeFace(TextPaint paint, Typeface tf) {
		int oldStyle;
		Typeface old = paint.getTypeface();
		if (old == null) {
			oldStyle = 0;
		}
		else {
			oldStyle = old.getStyle();
		}
		int fake = oldStyle & ~tf.getStyle();
		if ((fake & Typeface.BOLD) != 0) {
			paint.setFakeBoldText(true);
		}
		if ((fake & Typeface.ITALIC) != 0) {
			paint.setTextSkewX(-0.25f);
		}
		paint.setTypeface(tf);
	}
}