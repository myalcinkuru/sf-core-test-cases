package io.smartface.ExposingEngine;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dalvik.system.DexClassLoader;
import io.smartface.android.SFProxyInvocationHandler;
import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFCtClassFactory;
import io.smartface.plugin.SMFJSObject;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.android.DexFile;

public class JsClassProxyOperations {
    private static final boolean FORCE_GENRATE_DEX = true;
    public static Map classesCache = new HashMap<String, Class>();
    static ClassPool cp = ClassPool.getDefault(SpratAndroidActivity.getInstance().getApplicationContext());

    public static ExchangeValue generateInterfaceProxyInstance(ExchangeValue classId, final SMFJSObject jscallbacksImpl) {
        Object object = (Class) JavaJsInterface.unwrapValue(classId);
        if (object == null || !(object instanceof Class)) {
            return null;
        }

        Class[] classes = new Class[1];
        classes[0] = (Class) object;

        Object ret = Proxy.newProxyInstance(SpratAndroidActivity.class.getClassLoader(), classes, new SFProxyInvocationHandler(jscallbacksImpl));
        if (ret == null) {
            return null;
        } else {
            return JavaJsInterface.wrapValue(new JsObject(classes[0].cast(ret)));
        }
    }

    // JS
    public static ExchangeValue generateExtendingProxyInstance(ExchangeValue className, ExchangeValue superName, SMFJSObject callbacks, ExchangeValue[] params) throws Throwable {
        return generateExtendingProxyInstance(className, superName, callbacks, null, params);
    }

    // JS
    public static ExchangeValue generateExtendingProxyInstance(ExchangeValue classNameId, ExchangeValue superClassNameId, SMFJSObject callbacks, SMFJSObject callbackWithSuperCall, ExchangeValue[] paramsAsInt) throws Throwable {
        String className =  (String) JavaJsInterface.unwrapValue(classNameId);
        JsClass jsClass = JsClassManager.GetClass(className);
        if (jsClass == null) {
            String superClassName = ((Class) (JavaJsInterface.unwrapValue(superClassNameId))).getName();

            String[] props = callbacks.copyPropertyNames();
            String[] propsWithSuper = callbackWithSuperCall != null ? callbackWithSuperCall.copyPropertyNames() : new String[0];
            generateExtendingProxyInstance(className, superClassName, Arrays.asList(props), Arrays.asList(propsWithSuper));
            jsClass = JsClassManager.GetClass(className);
        }

        Object[] params = new Object[0];
        if (paramsAsInt != null) {
            params = new Object[paramsAsInt.length];
            for (int i = 0; i < paramsAsInt.length; ++i) {
                Object param = JavaJsInterface.unwrapValue(paramsAsInt[i]);
                if (param instanceof JsAbstractObject) {
                    param = ((JsAbstractObject)param).getJavaObject();
                }
                params[i] = param;
            }
        }

        if(jsClass != null) {
            JsObject object = (JsObject) jsClass.createInstance(params);
            if (object == null) return null;

            if (callbackWithSuperCall != null) {
                String[] superProbNames = callbackWithSuperCall.copyPropertyNames();
                for (String superProbName : superProbNames) {
                    try {
                        callbacks.setProperty(superProbName, callbackWithSuperCall.getProperty(superProbName));
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            object.setProperty("callbacks", callbacks);
            return JavaJsInterface.wrapValue(object);
        }

        return null;
    }

    public static Object generateExtendingProxyInstance(String className, String superName, List<String> methods) {
        return generateExtendingProxyInstance(className, superName, methods, null);
    }

    public static Object generateExtendingProxyInstance(String className, String superName, List<String> methods, List<String> methodsWithSuperCall) {
        if(classesCache.containsKey(className)) {
            return classesCache.get(className);
        }

        File dexFile = new File(SpratAndroidActivity.getInstance().getFilesDir(), "sf_"+className+".dex");

        if (!dexFile.exists() || FORCE_GENRATE_DEX) {
            // generate DEX and ODEX file.
            try {
                // Checking the that want to be extend is already loaded and frozen.We should check
                // this because in emulator clear case we delete all dex files but class still exists on classloader
                try{
                    CtClass existingClass = cp.get(className);
                    if(existingClass.isFrozen()){
                        existingClass.defrost();
                    }
                }
                catch (NotFoundException e){
                }
                catch (Exception e) {
                }
                // generate "xxx.class" file via Javassist.
                CtClass cls = SMFCtClassFactory.create(className, superName, methods, methodsWithSuperCall);
                cls.writeFile(SpratAndroidActivity.getInstance().getFilesDir().getAbsolutePath());
                // convert from "xxx.class" to "xxx.dex"
                String dexFilePath = dexFile.getAbsolutePath();
                DexFile df = new DexFile();
                df.addClass(new File(SpratAndroidActivity.getInstance().getFilesDir(), className + ".class"));
                df.writeFile(dexFilePath);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (dexFile.exists()) {
            try {
                DexClassLoader dcl = new DexClassLoader(
                        dexFile.getAbsolutePath(),
                        SpratAndroidActivity.getInstance().getCacheDir().getAbsolutePath(),
                        SpratAndroidActivity.getInstance().getApplicationInfo().nativeLibraryDir,
                        SpratAndroidActivity.getInstance().getClassLoader());

                Class proxyClass = dcl.loadClass(className);

                // Register to class manager
                JsClassManager.GetClass(proxyClass);

                return proxyClass;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return null;
    }

    private static HashMap<String, ArrayList<String>> assignableClasses;
    static {
        assignableClasses = new HashMap<String, ArrayList<String>>();
        
        ArrayList<String> intCompatibles = new ArrayList<String>();
        intCompatibles.add("java.lang.Integer");
        assignableClasses.put("int", intCompatibles);

        ArrayList<String> doubleCompatibles = new ArrayList<String>();
        doubleCompatibles.add("java.lang.Double");
        assignableClasses.put("double", doubleCompatibles);

        ArrayList<String> floatCompatibles = new ArrayList<String>();
        floatCompatibles.add("java.lang.Float");
        assignableClasses.put("float", floatCompatibles);
    }
    private static boolean isAssignableFromExtended(Class to, Class from) {
        return assignableClasses.get(to.getName()).contains(from.getName());
    }
}
