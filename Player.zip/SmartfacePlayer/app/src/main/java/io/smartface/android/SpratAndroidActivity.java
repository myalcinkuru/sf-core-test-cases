package io.smartface.android;

import io.fabric.sdk.android.Fabric;
import io.smartface.SmartfaceDemo.A;
import io.smartface.SmartfaceDemo.BuildConfig;
import io.smartface.SmartfaceDemo.R;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.JsClassManager;
import io.smartface.ExposingEngine.JsObjectCollection;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.opengl.GLES10;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebStorage;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.hardware.display.DisplayManager;

import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.ndk.CrashlyticsNdk;
import com.google.android.gms.samples.vision.barcodereader.BarcodeGraphic;
import com.google.android.gms.samples.vision.barcodereader.BarcodeTrackerFactory;
import com.google.android.gms.samples.vision.barcodereader.ui.camera.CameraSource;
import com.google.android.gms.samples.vision.barcodereader.ui.camera.CameraSourcePreview;
import com.google.android.gms.samples.vision.barcodereader.ui.camera.GraphicOverlay;
import com.google.android.gms.vision.MultiProcessor;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import io.smartface.android.notifications.FCMListenerService;
import io.smartface.android.notifications.LocalNotificationReceiver;
import io.smartface.android.notifications.WidgetProvider;
import io.smartface.android.utils.DeviceUtil;
import io.smartface.android.utils.FabricUtil;
import io.smartface.android.utils.EmulatorUtil;
import io.smartface.android.utils.FCMRegisterUtil;
import io.smartface.android.listeners.ActivityLifeCycleListener;
import io.smartface.plugin.SMFJSObject;
import io.smartface.android.utils.LocaleConfigurationUtil;
import io.smartface.android.sfcore.global.SFHandler;

public class SpratAndroidActivity extends AppCompatActivity {

    static {
        try {
            System.loadLibrary("sprat-jni");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }

    public static final int NOTIFICATION_LOCAL = 0;
    public static final int NOTIFICATION_REMOTE = 1;

    public static AppCompatActivity instance;
    RelativeLayout main_layout;
    public SpDrawerLayout parent_layout;
    public int pageShowAnimDuration = 0;
    public long jniRef;
    private int lastConnectionType = -1;

    /**
     * Request Codes
     *
     * it s used in SpratAndroidActivity.onActivityResult
     */
    private static final int REQUEST_CODE_CALL_APPLICATION = 114;
    public static final int REQUEST_CODE_EMULATOR_SCAN = 119;
    public static final int REQUEST_CODE_EMULATOR_UPDATE = 120;
    public static final int REQUEST_CODE_EMULATOR_CLEAR = 121;

    public static final int EMULATOR_PERMISSIONS_REQUEST_CAMERA = 124;
    public static final int EMULATOR_PERMISSIONS_REQUEST_READ_PHONE_STATE = 125;
    public static final String EMULATOR_Private_Perferences = "emulatorPrivatePrefences";
    public static final String EMULATOR_Scanned_URL = "emulatorLastScannedUrl";
    public static final String EMULATOR_DISPATCHER_URL = "emulatorDispatcherScannedUrl";
    public static final String EMULATOR_PROJECT_NAME = "emulatorProjectName";
    public static final String EMULATOR_Device_Info = "emulatorDeviceInfo";
    public static final String EMULATOR_Device_Id = "emulatorDeviceId";
    public static final String EMULATOR_APP_VERSION = "emulatorappVersion";
    public static final String EMULATOR_BUILD_VERSION = "emulatorbuildVersion";
    private static final String EMULATOR_ZIP_SIZE = "emulatorzipsize";
    private static final String NOTIFICATION_TITLE = BuildConfig.EMULATOR_NOTIFICATION_TITLE;

    public static final int EMULATOR_NOTIFICATION_CODE = 987;

    public final static String APPLICATION_CALL_TYPE_CALL = "call";
    private static final String APPLICATION_CALL_TYPE_CALLBACK = "callback";

    public static final String LOCAL_NOTIFICATION_ID = "id";
    public static final String LOCAL_NOTIFICATION_RECEIVED = "localNotificationReceived";

    public static boolean readPhoneStateGranted = true;

    public static boolean SFPAGE_ANIMATION_STARTED = false;
    /**
     * the path all the applications files will be located.
     *
     * it s construected by getDbPath function
     */
    private String dbPath;
    private String unsecureDbPath;

    SharedPreferences mPrefs;
    int oldOrientation;
    boolean[] orientationsAllowed = { true, false, false, false };

    private boolean isRestartingActivity = false;
    private boolean app_is_started_with_start_activity = true;
    public boolean splashShown = false;
    private boolean startingDownloadEmulatorResources = false;
    private boolean comesFromNotification = false;
    private boolean willFireReceivedNotificationEventOn = false;
    public boolean isemulator = false;
    boolean isScannerEmulator = false;
    boolean inScannerMode = false;
    DecimalProgressDialog progressBar;

    public static boolean useActionBar = true;

    private String availableFontNames = null;

    private String urlKeyValue = null;

    private Hashtable<Long, WeakReference<AlertDialog>> openAlerts = new Hashtable<Long, WeakReference<AlertDialog>>();

    protected Vector<SpPluginInterface> pInterfaceList;
    public SharedPreferences sharedPrefs;
    private JSONObject callAppData;
    private boolean willFireOnApplicationCallReceived = false;;
    public static int[] maxTextureSize = new int[1];

    public ValueCallback<Uri[]> mFilePathCallback = null;
    public ValueCallback<Uri> mUploadMsg = null;
    public Uri mCameraPhotoPath = null;

    public static boolean firstSliderDrawer = true;

    private Map<Integer, AlertDialog> alertDialogs = new HashMap<>();
    private String screenDisplaySize = null;
    private boolean isRelease = false;
    private AlertDialog networkErrorAlert = null;

    // Supporting lifecycle events on sf-core and giving lifecycle to the SF Plugin
    // Developer.
    private ArrayList<ActivityLifeCycleListener> activityLifeCycleListeners = new ArrayList<>();
    private SMFJSObject onBackPressedCallback = null;
    private SMFJSObject onItemSelectedCallback = null;
    private Configuration applicationConfiguration;
    private boolean isNotificationHandled = false;
    private boolean isCoreStarted = false;
    private boolean isSetSplashInUiCalled = false;
    // Supporting permission check on sf-core and giving permission check results to
    // the SF Plugin Developer.

    // Native functions
    public native static String getSenderID();

    public native void setCoverageFolder(String folder);

    public native void runPageLoadActivityIndicators(long pageJniRef);
    // public static native void grabObject(long pageJniRef);
    // public static native void releaseObject(long pageJniRef);

    private native void performOnMainThread(long selectorId, long selectorArg, Object semaphore);

    public native void downloadEmulatorResources(String emulatorIndexUrl, String density);

    public native void startEmulatorConnection(String emulatorIndexUrl, String deviceInfo);

    public native void clearEmulatorConnection();

    public native void cancelDebugSession();

    public native String initialize(String apkFilename);

    public native void initializeAfterSplash();

    private native void fireEventNatively(int id, long jni);


    private native void fireEventWithOptionNatively(int id, String args, long jni);

    /**
     *
     * @param callbackGroupRef
     * @param callbackID
     * @param json             optional
     */
    private native void fireCallback(long callbackGroupRef, int callbackID, String json);

    /**
     * Signals to native Core to display new page because the tabbar has been used.
     */
    public native void setCallApplicationData(String data, int resultCode, int type);

    public native void setCallApplicationUrl(String url);

    private static native void setNotificationDataNative(String nData, int notificationType);

    private int mainLayoutoutId = 112233;

    // Defined in framework-core
    public native static long getJSContextRef();

    // Defined in framework-core
    public native static long getJNIVMapRef();

    public native void freeResources();

    private CameraSource mCameraSource;
    private CameraSourcePreview mPreview;
    private GraphicOverlay<BarcodeGraphic> mGraphicOverlay;
    public static String lastScanned = null;
    boolean cameraIsOn = false;

    abstract class EmulatorState {
        long time;
        long timeOut = 60000;
        boolean isNotInternalWorking = false;

        public EmulatorState() {
            time = System.currentTimeMillis();
        }

        public boolean isTimeOut() {
            return isNotInternalWorking && System.currentTimeMillis() - time > timeOut;
        }

        public void reset() {
            time = System.currentTimeMillis();
        }

        public void cancelTimeout() {
            isNotInternalWorking = false;
        }

        public void startTimeout() {
            reset();
            isNotInternalWorking = true;
        }
    }

    class IdleEmulator extends EmulatorState {
    }

    class UpdatingEmulator extends EmulatorState {
    }

    volatile EmulatorState emulatorState = new IdleEmulator();

    Thread emulatorTimeoutThread = new Thread(new Runnable() {
        @Override
        public void run() {
            if (SpratAndroidActivity.getInstance().isemulator) {
                while (true) {
                    try {
                        Thread.currentThread().sleep(5000);
                        if (SpratAndroidActivity.getInstance().emulatorState instanceof UpdatingEmulator
                                && SpratAndroidActivity.getInstance().emulatorState.isTimeOut()) {
                            SpratAndroidActivity.getInstance().EmulatorOnError__N("Time out");
                            newEmulatorZip = true;
                            SpratAndroidActivity.getInstance().clearEmulatorIndex();
                            if (SpratAndroidActivity.getInstance().getEmulatorZip().exists() == false) {
                                SpratAndroidActivity.getInstance().clearEmulatorResources__N();
                            }
                            chunkSavingThread.join();
                        } else if (SpratAndroidActivity.getInstance().emulatorState instanceof UpdatingEmulator
                                && SpratAndroidActivity.getInstance().getNetworkConnType() == 0) {
                            chunkSavingThread.join();
                            SpratAndroidActivity.getInstance().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    // SpratAndroidActivity.getInstance().clearEmulatorIndex();
                                    // SpratAndroidActivity.getInstance().clearEmulatorResources__N();
                                    SpratAndroidActivity.getInstance().showEmulatorNetworkErrorAlert();
                                    deleteTempSmartfaceEmulatorZipFile();

                                    if (SpratAndroidActivity.getInstance().progressBar != null) {
                                        SpratAndroidActivity.getInstance().progressBar.cancel();
                                    }
                                    SpratAndroidActivity.getInstance().progressBar = null;
                                }
                            });
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    });

    public SpratAndroidActivity() {
        instance = this;
    }

    @Override
    public void onBackPressed() {
        if (this.onBackPressedCallback == null) {
            super.onBackPressed();
            return;
        }
        try {
            /*
             * ToDo: Block in case of page transaction is started and not over yet. This is
             * not best solution
             */
            if (SFPAGE_ANIMATION_STARTED)
                return;
            SMFJSObject callback = this.onBackPressedCallback.getProperty("onBackPressed");
            callback.callAsFunctionNew(callback.jsValueRef, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void attachBackPressedListener(SMFJSObject callback) {
        this.onBackPressedCallback = callback;
    }

    public void attachItemSelectedListener(SMFJSObject callback) {
        this.onItemSelectedCallback = callback;
    }

    private void deleteTempSmartfaceEmulatorZipFile() {
        // remove TempSmartfaceEmulator.zip if download failed
        File corruptedEmulatorFile = new File(getUnsecureDbPath__N() + "/TempSmartfaceEmulator.zip");
        if (corruptedEmulatorFile.exists()) {
            corruptedEmulatorFile.delete();
        }
    }

    public void finishApplication__N() {
        cancelEmulatorNotification();
        this.finish();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleConfigurationUtil.adjustFontSize(newBase));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setAppTheme();
        LocaleConfigurationUtil.changeConfigurationLocale(this);
        setSplashScreenOnUI();
        applicationConfiguration = new Configuration(getResources().getConfiguration());
        main_layout = new RelativeLayout(this);
        main_layout
                .setLayoutParams(new DrawerLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        main_layout.setId(mainLayoutoutId);
        parent_layout = new SpDrawerLayout(this);
        parent_layout.setBackgroundColor(Color.BLACK);
        parent_layout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        parent_layout.addView(main_layout);
        GLES10.glGetIntegerv(GLES10.GL_MAX_TEXTURE_SIZE, maxTextureSize, 0);

        if (BuildConfig.FLAVOR.toLowerCase().contains("emulator")) {
            isemulator = true;
            isScannerEmulator = true;
            isNotificationHandled = false;
            FCMRegisterUtil.registerPushNotification(getString(R.string.smartface_emulator_senderID), this, null);
            if (BuildConfig.BUILD_TYPE.equals("release")) {
                isRelease = true;
                Fabric.with(this, new Crashlytics(), new CrashlyticsNdk(), new Answers());
                FabricUtil.initializeFabricDeviceInfo(this);
            }
        }

        sharedPrefs = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);

        if (!sharedPrefs.contains("pushCustomAlertTitle")) {
            sharedPrefs.edit().putString("pushCustomAlertTitle", "alertTitle").commit();
        }

        if (!sharedPrefs.contains("pushCustomAlertBody")) {
            sharedPrefs.edit().putString("pushCustomAlertBody", "alertBody").commit();
        }

        if (!sharedPrefs.contains("pushCustomIcon")) {
            sharedPrefs.edit().putString("pushCustomIcon", "icon").commit();
        }

        SpBitmapRef.clearCache();

        JsObjectCollection.clear();
        JavaJsInterface.ClearCache();
        JsClassManager.ClearCache();
        JsClassManager.Start();

        Intent intent = getIntent();

        moveJsFiles();
        instance = this;

        // Preparing font list
        new Thread(new Runnable() {
            @Override
            public void run() {
                SpratAndroidActivity.this.availableFontNames = SpratAndroidActivity.this.getAvailableFontsList__N();
            }
        }).start();
        mPrefs = getPreferences(MODE_PRIVATE);

        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String key = getPackageName() + ".useActionBar";
            useActionBar = bundle.getBoolean(key);

        } catch (NameNotFoundException e) {
            System.out.println("Failed to load meta-data, NameNotFound: " + e.getMessage());

        } catch (NullPointerException e) {
            System.out.println("Failed to load meta-data, NullPointer: " + e.getMessage());
        }

        getIntent().removeExtra("EmulatorRestart");
        emulatorState = new IdleEmulator();
        if (isemulator && emulatorTimeoutThread.getState() == Thread.State.NEW)
            emulatorTimeoutThread.start();
        progressBar = new DecimalProgressDialog(SpratAndroidActivity.this);

        initScreenSizeAndRest();

        /*
         * ToDo: Launching App at second time, extras of intent won't be null. So making
         * true the willFireOnApplicationCallReceived variable causes to call
         * fireApplicationOnCallReceived unnecessary.
         */
        if (intent != null) {
            Bundle extras = intent.getExtras();
            if (extras == null || !intent.getExtras().containsKey("EmulatorNotificationType")) {
                // Cannot be notification. Application started with application call
                callAppData = new JSONObject();

                if (extras != null) {
                    setAppData(extras);
                    willFireOnApplicationCallReceived = true;
                }

                if (intent.getData() != null) {
                    urlKeyValue = intent.getData().toString();
                    willFireOnApplicationCallReceived = true;
                }
            }
        }

        // Firing listeners for onCreate
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onCreate();
        }
    }


    private void setAppTheme() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int themeRes = preferences.getInt("SFCurrentBaseTheme", -1);
        if (themeRes != -1)
            setTheme(themeRes);
    }

    private PendingIntent createEmulatorNotificationIntent(String type, int requestCode) {
        Class cls;
        try {
            cls = Class.forName(getPackageName() + ".A");
        } catch (Exception e) {
            cls = A.class;
        }

        Intent intent = new Intent(this, cls);
        intent.putExtra("EmulatorNotificationType", type);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        return pendingIntent;
    }

    NotificationManager mNotificationManager = null;

    public void prepareEmulatorControls() {
        if (!isemulator)
            return;
        PendingIntent scanPIntent = createEmulatorNotificationIntent("scan", REQUEST_CODE_EMULATOR_SCAN);
        PendingIntent updatePIntent = createEmulatorNotificationIntent("update", REQUEST_CODE_EMULATOR_UPDATE);
        PendingIntent clearPIntent = createEmulatorNotificationIntent("clear", REQUEST_CODE_EMULATOR_CLEAR);

        String ns = Context.NOTIFICATION_SERVICE;
        final String defaultSmarfaceId = "7";
        mNotificationManager = (NotificationManager) getSystemService(ns);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(defaultSmarfaceId, NOTIFICATION_TITLE,
                    importance);
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder notiBuilder = new NotificationCompat.Builder(this, defaultSmarfaceId)
                .setOnlyAlertOnce(true);
        Notification emulatorNotification = notiBuilder.setContentTitle(NOTIFICATION_TITLE)
                .setSmallIcon(R.drawable.notificationicon_sb).addAction(R.drawable.smf_scan, "scan", scanPIntent)
                .build();

        if (getEmulatorZip().exists()) {
            emulatorNotification = notiBuilder.addAction(R.drawable.smf_update, "update", updatePIntent)
                    .addAction(R.drawable.smf_clear, "clear", clearPIntent).build();
        }
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        String projectName = settings.getString(EMULATOR_PROJECT_NAME, null);
        if (projectName != null) {
            emulatorNotification = notiBuilder.setContentText(projectName).build();
        }
        emulatorNotification.flags |= Notification.FLAG_ONGOING_EVENT;
        mNotificationManager.notify(EMULATOR_NOTIFICATION_CODE, emulatorNotification);

        updateSmartfaceWidget();
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Firing listeners for onStop
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onStop();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (splashShown && isemulator && inScannerMode) {
            startCamera();
        }

        if (intent == null || (intent.getExtras() == null))
            return;

        Bundle extras = intent.getExtras();
        boolean notificationClicked = extras.getBoolean(LocalNotificationReceiver.NOTIFICATION_CLICKED, false);
        if (notificationClicked) {
            FCMListenerService
                    .onRemoteNotificationReceived(extras.getString(LocalNotificationReceiver.NOTIFICATION_JSON), true);
        }
        if (extras.containsKey("EmulatorNotificationType")) {
            // This is emulator notification.
            handleEmulatorNotification(intent);
            return;
        }
        if (!notificationClicked) {
            setAppData(extras);

            if (intent.getData() != null) {
                urlKeyValue = intent.getData().toString();
            }
            if (isOnBackground) {
                fireNativeEvent(EventID.ON_APPLICATION_CALL_RECEIVED, getApplicationCallData(-1), jniRef);
                willFireOnApplicationCallReceived = false;
            } else {
                willFireOnApplicationCallReceived = true;
            }
        }
        setIntent(intent);
    }

    HashMap<String, List<String>> assetsListCache = new HashMap<String, List<String>>();

    public int getFileType__N(String path) {
        if (isemulator) {
            String fullPath = getUnsecureDbPath__N() + "/assets/" + path;
            File f = new File(fullPath);
            if (!f.exists()) {
                return -1;
            } else if (f.isDirectory()) {
                return 1;
            } else if (f.isFile()) {
                return 0;
            }
        } else {
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
            AssetManager assetManager = getApplicationContext().getResources().getAssets();
            try {
                assetManager.open(path);
                return 0;
            } catch (IOException e) {
                try {
                    assetManager.open(path + "e");
                    return 0;
                } catch (IOException ex) {
                    e.printStackTrace();
                    String parent = "";
                    String dirName = path;
                    if (path.contains("/")) {
                        parent = path.substring(0, path.lastIndexOf("/"));
                        dirName = path.substring(path.lastIndexOf("/") + 1);
                    }
                    try {
                        if (assetsListCache.containsKey(parent)) {
                            if (assetsListCache.get(parent).contains(dirName)) {
                                return 1;
                            }
                        } else {
                            List<String> entries = Arrays.asList(assetManager.list(parent));
                            assetsListCache.put(parent, entries);
                            if (entries.contains(dirName)) {
                                return 1;
                            }
                        }
                        return 1;
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    return -1;
                }
            }
        }
        return -1;
    }

    private void moveJsFiles() {
        if (getPackageName().equals("biz.mobinex.android.apps.smartface_demo")) {
            String path = "/sdcard/Android/data/" + getPackageName();
            File f = new File(path);

            if (!f.exists()) {
                f.mkdirs();
            }

            File files[] = f.listFiles();
            File db_files[] = new File(getDbPath__N()).listFiles();
            /*
             * for (int i = 0; db_files != null && i < db_files.length; i++) { if
             * (db_files[i].getName().endsWith(".js")) { db_files[i].delete(); } }
             */
            byte data[] = new byte[1024 * 5];

            for (int i = 0; files != null && i < files.length; i++) {
                if (files[i].getName().endsWith(".js")) {
                    String s = getDbPath__N() + "/" + files[i].getName();
                    File tt = new File(s);
                    tt.delete();

                    try {
                        FileOutputStream fo = openFileOutput(files[i].getName(), Activity.MODE_PRIVATE);
                        FileInputStream fi = new FileInputStream(files[i]);
                        int l = fi.read(data);

                        while (l > 0) {
                            fo.write(data, 0, l);
                            l = fi.read(data);
                        }

                        fi.close();
                        fo.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    files[i].delete();
                }
            }
        }
    }

    public static String getAuthority() {
        return BuildConfig.APPLICATION_ID + ".provider";
    }

    public static void runUiOperation(Runnable r) {
        if (instance != null && r != null) {
            try {
                instance.runOnUiThread(r);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * it gives system variables.
     *
     * touch x , touch y, gsp, accelerator, language etc..
     *
     * @param key
     * @return
     */
    public String getSystemVariable__N(String key) {
        if (key.equals("Lang")) {
            String lang = Locale.getDefault().toString();

            if (lang.indexOf('_') != -1) {
                lang = lang.substring(0, lang.indexOf('_'));
            }
            return lang.toLowerCase();

        }
        return key + " NOT IMPL";
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (SFPAGE_ANIMATION_STARTED)
            return false;

        if (menuItem.getItemId() == android.R.id.home) {
            try {
                SMFJSObject callback = this.onItemSelectedCallback.getProperty("onOptionsItemSelected");
                callback.callAsFunctionNew(callback.jsValueRef, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
        return false;
    }

    /**
     * this doesn't work on Android devices which aren't phones such as tablets, it
     * requires the READ_PHONE_STATE permission and it doesn't work reliably on all
     * phones.
     *
     * @return device's IMEI address
     */
    private String getIMEI() {
        return DeviceUtil.getDeviceId(this);
    }

    public static ArrayList<String> voiceResults;

    public boolean checkPermission__N(String permission) {
        if (!permission.startsWith("android.permission."))
            permission = "android.permission." + permission.toUpperCase().replaceAll(" ", "_");
        if (Build.VERSION.SDK_INT < 23) {
            PackageManager pm = getPackageManager();
            return pm.checkPermission(permission, getPackageName()) == PackageManager.PERMISSION_GRANTED;
        }
        return (ContextCompat.checkSelfPermission(SpratAndroidActivity.this,
                permission) == PackageManager.PERMISSION_GRANTED);
    }

    public boolean shouldShowRequestPermissionRationale__N(String permission) {
        if (!permission.startsWith("android.permission."))
            permission = "android.permission." + permission.toUpperCase().replaceAll(" ", "_");
        if (Build.VERSION.SDK_INT < 23) {
            return false;
        }
        return shouldShowRequestPermissionRationale(permission) == true;
    }

    public void requestPermissions__N(String[] permissions, int requestCode) {
        if (Build.VERSION.SDK_INT < 23)
            return;
        for (int i = 0; i < permissions.length; i++) {
            if (!permissions[i].startsWith("android.permission."))
                permissions[i] = "android.permission." + permissions[i].toUpperCase().replaceAll(" ", "_");
        }
        requestPermissions(permissions, requestCode);
    }

    long applicationEventJni = 0;

    public void setApplicationEventJni__N(long appEventJni) {
        jniRef = applicationEventJni = appEventJni;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
        case EMULATOR_PERMISSIONS_REQUEST_CAMERA: {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= 23) {
                    if (ContextCompat.checkSelfPermission(SpratAndroidActivity.this,
                            Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        readPhoneStateGranted = false;
                        if (ActivityCompat.shouldShowRequestPermissionRationale(SpratAndroidActivity.this,
                                Manifest.permission.READ_PHONE_STATE)) {

                            // Show an expanation to the user *asynchronously* -- don't block
                            // this thread waiting for the user's response! After the user
                            // sees the explanation, try again to request the permission.
                            ActivityCompat.requestPermissions(SpratAndroidActivity.this,
                                    new String[] { Manifest.permission.READ_PHONE_STATE },
                                    EMULATOR_PERMISSIONS_REQUEST_READ_PHONE_STATE);
                        } else {

                            // No explanation needed, we can request the permission.
                            ActivityCompat.requestPermissions(SpratAndroidActivity.this,
                                    new String[] { Manifest.permission.READ_PHONE_STATE },
                                    EMULATOR_PERMISSIONS_REQUEST_READ_PHONE_STATE);
                        }
                    }
                }
                // permission was granted
                startCamera();
            } else {

                // permission denied! Disable the
                // functionality that depends on this permission.
            }
            return;
        }
        case EMULATOR_PERMISSIONS_REQUEST_READ_PHONE_STATE:
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                readPhoneStateGranted = true;
            } else {
                readPhoneStateGranted = false;
            }
            break;
        default:
            if (permissions != null && grantResults != null && grantResults.length > 0 && permissions.length > 0) {
                for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
                    listener.onRequestPermissionsResult(requestCode, permissions[0], grantResults[0]);
                }
            }
            break;
        }
    }

    public void prepareAndStartCamera() {
        if (Build.VERSION.SDK_INT >= 23) {

            if (ContextCompat.checkSelfPermission(SpratAndroidActivity.this,
                    Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(SpratAndroidActivity.this,
                        Manifest.permission.CAMERA)) {
                    // Show an expanation to the user *asynchronously* -- don't block
                    // this thread waiting for the user's response! After the user
                    // sees the explanation, try again to request the permission.
                    ActivityCompat.requestPermissions(SpratAndroidActivity.this,
                            new String[] { Manifest.permission.CAMERA }, EMULATOR_PERMISSIONS_REQUEST_CAMERA);
                } else {
                    // No explanation needed, we can request the permission.
                    ActivityCompat.requestPermissions(SpratAndroidActivity.this,
                            new String[] { Manifest.permission.CAMERA }, EMULATOR_PERMISSIONS_REQUEST_CAMERA);
                }
            } else {
                startCamera();
            }
        } else {
            startCamera();
        }
    }

    /**
     * Creates and starts the camera. Note that this uses a higher resolution in
     * comparison to other detection examples to enable the barcode detector to
     * detect small barcodes at long distances.
     *
     * Suppressing InlinedApi since there is a check that the minimum version is met
     * before using the constant.
     */
    @SuppressLint("InlinedApi")
    private void createCameraSource(boolean autoFocus, boolean useFlash) {
        Context context = getApplicationContext();

        // A barcode detector is created to track barcodes. An associated
        // multi-processor instance
        // is set to receive the barcode detection results, track the barcodes, and
        // maintain
        // graphics for each barcode on screen. The factory is used by the
        // multi-processor to
        // create a separate tracker instance for each barcode.
        BarcodeDetector barcodeDetector = new BarcodeDetector.Builder(context).setBarcodeFormats(Barcode.QR_CODE)
                .build();
        BarcodeTrackerFactory barcodeFactory = new BarcodeTrackerFactory(mGraphicOverlay);
        barcodeDetector.setProcessor(new MultiProcessor.Builder<>(barcodeFactory).build());

        if (!barcodeDetector.isOperational()) {
            // Note: The first time that an app using the barcode or face API is installed
            // on a
            // device, GMS will download a native libraries to the device in order to do
            // detection.
            // Usually this completes before the app is run for the first time. But if that
            // download has not yet completed, then the above call will not detect any
            // barcodes
            // and/or faces.
            //
            // isOperational() can be used to check if the required native libraries are
            // currently
            // available. The detectors will automatically become operational once the
            // library
            // downloads complete on device.
            Log.w("SMF", "Detector dependencies are not yet available.");

            // Check for low storage. If there is low storage, the native library will not
            // be
            // downloaded, so detection will not become operational.
            IntentFilter lowstorageFilter = new IntentFilter(Intent.ACTION_DEVICE_STORAGE_LOW);
            boolean hasLowStorage = registerReceiver(null, lowstorageFilter) != null;

            if (hasLowStorage) {
                Toast.makeText(this, R.string.low_storage_error, Toast.LENGTH_LONG).show();
                Log.w("SMF", getString(R.string.low_storage_error));
            }
        }

        // Creates and starts the camera. Note that this uses a higher resolution in
        // comparison
        // to other detection examples to enable the barcode detector to detect small
        // barcodes
        // at long distances.
        CameraSource.Builder builder = new CameraSource.Builder(getApplicationContext(), barcodeDetector)
                .setFacing(CameraSource.CAMERA_FACING_BACK).setRequestedPreviewSize(1600, 1024).setRequestedFps(15.0f);

        // make sure that auto focus is an available option
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            builder = builder.setFocusMode(autoFocus ? Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE : null);
        }

        mCameraSource = builder.setFlashMode(useFlash ? Camera.Parameters.FLASH_MODE_TORCH : null).build();
    }

    static boolean statusbarVisibileBeforeScanner = false;
    static boolean actionbarVisibileBeforeScanner = false;
    static boolean emulatorVersionCheckFailed = false;

    private void hideBars() {
        actionbarVisibileBeforeScanner = false;
    }

    /**
     * Starts or restarts the camera source, if it exists. If the camera source
     * doesn't exist yet (e.g., because onResume was called before the camera source
     * was created), this will be called again when the camera source is created.
     */
    private void startCamera() throws SecurityException {
        Camera camera = null;
        try {
            camera = Camera.open();
        } catch (Throwable e) {
            e.printStackTrace();
            Toast.makeText(SpratAndroidActivity.getInstance(), "Please release the current open camera.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (camera != null) {
            camera.release();
        }
        EmulatorUtil.changeStatusBarVisibility(this, false);
        setContentView(R.layout.barcode_capture);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        cameraIsOn = true;
        mPreview = (CameraSourcePreview) findViewById(R.id.preview);
        mGraphicOverlay = (GraphicOverlay<BarcodeGraphic>) findViewById(R.id.graphicOverlay);
        createCameraSource(true, false);
        inScannerMode = true;
        dismissAllShownDialogs();

        if (mCameraSource != null && mPreview != null) {
            try {
                mPreview.start(mCameraSource, mGraphicOverlay);
            } catch (IOException e) {
                Log.e("SMF", "Unable to start camera source.", e);
                mCameraSource.release();
                mCameraSource = null;
            }
        }
    }

    public boolean onBarcodeRead() {
        BarcodeGraphic graphic = mGraphicOverlay.getFirstGraphic();
        Barcode barcode = null;

        if (graphic != null) {

            barcode = graphic.getBarcode();
            final Barcode mBarcode = barcode;
            if (barcode != null) {
                inScannerMode = false;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        lastScanned = null;
                        if (getNetworkConnType() == 0) {
                            showEmulatorNetworkErrorAlert();
                        } else {
                            if (mPreview != null) {
                                mPreview.stop();
                            }

                            final String contents = mBarcode.displayValue;
                            String contentsLower = contents.toLowerCase();
                            if (contentsLower.startsWith("https://dl.smartface.io/")
                                    || contentsLower.startsWith("https://smf.to/app")) {
                                if (contentsLower.contains("protocolversion=3.0")
                                        || contentsLower.contains("protocolversion=4.0")) {
                                    emulatorVersionCheckFailed = false;
                                    // send to core to start communication with ses and download all emulator files
                                    startEmulatorDownload(contents, false);
                                } else {
                                    emulatorVersionCheckFailed = true;
                                    emulatorState = new IdleEmulator();
                                    final AlertDialog a = constructAlert("Update Required",
                                            "Your Smartface app is out of date. Please update to the latest version to run your projects.");
                                    a.setCancelable(false);
                                    a.setButton(DialogInterface.BUTTON_NEUTRAL, "Visit Google Play Store",
                                            new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    final String appPackageName = getPackageName();
                                                    try {
                                                        startActivity(new Intent(Intent.ACTION_VIEW,
                                                                Uri.parse("market://details?id=" + appPackageName)));
                                                    } catch (android.content.ActivityNotFoundException anfe) {
                                                        startActivity(new Intent(Intent.ACTION_VIEW,
                                                                Uri.parse(
                                                                        "https://play.google.com/store/apps/details?id="
                                                                                + appPackageName)));
                                                    } finally {
                                                        getInstance().finish();
                                                    }
                                                }
                                            });
                                    a.show();
                                }
                            } else {
                                // DC: if it's not a smartface URL, check if its valid and then behave
                                // accordingly.
                                SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences,
                                        Context.MODE_PRIVATE);
                                settings.edit().remove(EMULATOR_PROJECT_NAME).commit();
                                clearEmulatorResources__N();
                                setContentView(R.layout.emulator_qr_open_layout);
                                cameraIsOn = false;
                                TextView tv = (TextView) findViewById(R.id.qr_tv);
                                tv.setText(contents);
                                Button btn = (Button) findViewById(R.id.btnOpen);
                                if (Patterns.WEB_URL.matcher(contents).matches()) {
                                    // DC: valid URL
                                    btn.setVisibility(View.VISIBLE);
                                    btn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(contents));
                                            startActivity(browserIntent);
                                        }
                                    });
                                } else {
                                    // DC: invalid URL, hide the button. show alert
                                    btn.setVisibility(View.GONE);
                                    showEmulatorInvalidURLScannedAlert();
                                }
                            }
                        }
                    }
                });
            } else {
                Log.e("SMF", "barcode data is null");
            }
        } else {
            Log.e("SMF", "no barcode detected");
        }
        return barcode != null;
    }

    public void cancelEmulatorNotification() {
        mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (mNotificationManager != null) {
            mNotificationManager.cancel(EMULATOR_NOTIFICATION_CODE);
        }
    }

    private void clearEmulatorIndex() {
        String emulatorIndex = Environment.getExternalStorageDirectory().toString() + "/Android/data/"
                + getPackageName() + "/emulatorIndex.txt";
        clearFile(emulatorIndex);
    }

    public void clearEmulatorResources__N() {
        String s = Environment.getExternalStorageDirectory().toString();
        s += "/Android/data/" + getPackageName() + "/cache/";
        clearFilesInPath(s);
        s = getFilesDir().getAbsolutePath();
        clearFilesInPath(s);
    }

    private void clearAssignedLocale() {
        // When emulator clear, system language should be given
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        sharedPreferences.edit().putString("AppLocale", "auto").commit();
    }

    private void clearFile(String filePath) {
        if (filePath.endsWith("emulator-cacert.bin") || filePath.toLowerCase().contains(".fabric")) {
            return;
        }
        Runtime runtime = Runtime.getRuntime();
        try {
            runtime.exec(String.format("rm -rf %s", filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void clearFilesInPath(String s) {
        File emulatorDir = new File(s);

        if (emulatorDir.exists()) {
            if (emulatorDir.listFiles() != null) {
                for (File f : emulatorDir.listFiles()) {
                    if (!f.getName().toLowerCase().contains(".fabric")) {
                        if (f.isDirectory()) {
                            if (f.listFiles() != null) {
                                for (File subf : f.listFiles()) {
                                    clearFile(subf.getPath());
                                }
                            }
                            clearFile(f.getPath());
                        } else {
                            clearFile(f.getPath());
                        }
                    }
                }
            }
        }
    }

    public void updateSmartfaceWidget() {
        if (!isemulator)
            return;
        Intent widgetIntent = new Intent(this, WidgetProvider.class);
        widgetIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        // Use an array and EXTRA_APPWIDGET_IDS instead of
        // AppWidgetManager.EXTRA_APPWIDGET_ID,
        // since it seems the onUpdate() is only fired on that:
        int ids[] = AppWidgetManager.getInstance(getApplication())
                .getAppWidgetIds(new ComponentName(getApplication(), WidgetProvider.class));
        widgetIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(widgetIntent);
    }

    public void startEmulatorDownload(final String url, boolean update) {
        if (startingDownloadEmulatorResources)
            return;
        startingDownloadEmulatorResources = true;
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        String deviceInfo = settings.getString(EMULATOR_Device_Info, null);
        if (deviceInfo == null) {
            deviceInfo = getEmulatorDeviceInfo(getApplicationContext());
            editor.putString(EMULATOR_Device_Info, deviceInfo);
            editor.commit();
        }
        final String info = deviceInfo;
        emulatorState = new UpdatingEmulator();
        if (progressBar == null) {
            progressBar = new DecimalProgressDialog(SpratAndroidActivity.this);
        }

        String msg = "Updating with the latest code.";
        if (!update)
            msg = "Initializing app.";
        progressBar.setCommonProps(DecimalProgressDialog.STYLE_HORIZONTAL, msg, true);
        progressBar.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                downloadEmulatorResources(url, info);
            }
        }).start();
    }

    public void saveEmulatorUrl__N(String completedUrl) {
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(EMULATOR_Scanned_URL, completedUrl);
        editor.commit();
    }

    // Adding lifecycle event listeners for Activity
    public void addActivityLifeCycleCallbacks(ActivityLifeCycleListener listener) {
        activityLifeCycleListeners.add(listener);
    }

    // Removing lifecycle event listeners for Activity
    public void removeActivityLifeCycleCallbacks(ActivityLifeCycleListener listener) {
        activityLifeCycleListeners.remove(listener);
    }

    private File emulatorZip = null, tempEmulatorZip = null;

    private File getTempEmulatorZip() {
        if (tempEmulatorZip != null) {
            return tempEmulatorZip;
        }
        return tempEmulatorZip = new File(getUnsecureDbPath__N() + "/TempSmartfaceEmulator.zip");
    }

    private File getEmulatorZip() {
        if (emulatorZip != null) {
            return emulatorZip;
        }
        return emulatorZip = new File(getUnsecureDbPath__N() + "/SmartfaceEmulator.zip");
    }

    public void EmulatorOnError__N(String err) {
        if (emulatorState instanceof IdleEmulator)
            return;
        String msg_ = null;
        if (err.equals("no update")) {
            msg_ = "No changes detected";
        } else if (err.equals("Time out")) {
            msg_ = "Connection timed out.";
        } else {
            msg_ = err;
        }

        emulatorState = new IdleEmulator();
        final String msg = msg_;
        if (msg != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (progressBar != null && progressBar.isShowing())
                            progressBar.cancel();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        return;
                    }
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                    if (cameraIsOn) {
                        if (msg.equals("No changes detected") && getIntent() != null) {
                            SpratAndroidActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    progressBar.dismiss();
                                    restartSpratActivity();
                                }
                            });

                        } else {
                            prepareAndStartCamera();
                        }
                    } else if (isNotificationHandled && !isCoreStarted) {
                        // This statement belongs to debugger keep for future debug imp.
                        //showDebuggerWaitingDialog();
                        startEmulatorFlow();
                        setUpAfterSplash();
                        isCoreStarted = true;
                        isNotificationHandled = false;
                    }
                }
            });
        }
    }

    public void SetEmulatorProjectName__N(String name) {
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(EMULATOR_PROJECT_NAME, name);
        editor.commit();
        prepareEmulatorControls();
    }

    /**
     * @todo make this types enum types: 0 none<br>
     *       1 3g<br>
     *       2 wifi<br>
     */
    public int getNetworkConnType() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnected()) {
            lastConnectionType = 0;
        } else {
            if (netInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                lastConnectionType = 2;
            } else {
                lastConnectionType = 1;
            }
        }
        return lastConnectionType;
    }

    public void showEmulatorInvalidURLScannedAlert() {
        emulatorState = new IdleEmulator();
        final AlertDialog alert_invalidUrl = constructAlert("Invalid URL", "Scanned QR Code contains an invalid URL");
        alert_invalidUrl.setButton(DialogInterface.BUTTON_NEUTRAL, "Scan Again", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert_invalidUrl.dismiss();
                prepareAndStartCamera();
            }
        });
        alert_invalidUrl.show();
    }

    public AlertDialog constructAlert(String title, String msg) {
        AlertDialog alert = new AlertDialog.Builder(SpratAndroidActivity.this).create();
        shownAlerts.add(alert);
        alert.setCanceledOnTouchOutside(false);
        alert.setCancelable(false);
        alert.setTitle(title);
        alert.setMessage(msg);
        return alert;
    }

    public void showEmulatorNetworkErrorAlert() {
        emulatorState = new IdleEmulator();
        if (networkErrorAlert == null) {
            networkErrorAlert = constructAlert("NETWORK ERROR", "No internet connection. Please check your network.");
        }
        if (!networkErrorAlert.isShowing() && !isFinishing()) {
            final AlertDialog a = networkErrorAlert;
            a.setButton(DialogInterface.BUTTON_NEUTRAL, "ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    a.cancel();
                }
            });
            a.show();
        }
    }

    /*
    Keep these statements even unused. Might be re-used in future in case of debug feature decided.
    */
    AlertDialog debuggerAlert;
    Timer debuggerAlertTimer;

    public void showDebuggerWaitingDialog() {
        debuggerAlert = constructAlert("Please Wait", "Waiting for debugger");
        debuggerAlert.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dismissDebuggerWaitingDialog();
                cancelDebugSession();
            }
        });
        debuggerAlert.show();

        // If user does not cancel process, cancel after 1 minute
        debuggerAlertTimer = new Timer();
        debuggerAlertTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                dismissDebuggerWaitingDialog();
                cancelDebugSession();
            }
        }, 60 * 1000);

        (new Thread() {
            @Override
            public void run() {
                SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
                String lastScannedUrl = settings.getString(EMULATOR_Scanned_URL, null);
                String deviceInfo = settings.getString(EMULATOR_Device_Info, null);
                startEmulatorConnection(lastScannedUrl, deviceInfo);
            }
        }).start();
    }

    public boolean dismissDebuggerWaitingDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Close timer to prevent dialog dismiss again
                if (debuggerAlertTimer != null)
                    debuggerAlertTimer.cancel();

                // In players debugger alert will be null
                if (debuggerAlert != null && debuggerAlert.isShowing()) {
                    debuggerAlert.cancel();
                    setContentViewAfterSplash();
                    cameraIsOn = false;
                    isCoreStarted = true;
                    initializeAfterSplash();
                    // we should fire onCallReceived event after core initialize
                    fireApplicationOnCallReceived();
                }
            }
        });
        return (debuggerAlert != null && debuggerAlert.isShowing());
    }

    private void setUpAfterSplash() {
        setContentViewAfterSplash();
        initializeAfterSplash();
        // we should fire onCallReceived event after core initialize
        fireApplicationOnCallReceived();
    }

    private void startEmulatorFlow(){
        if(getNetworkConnType() == 0)
            return;
        new Thread(){
            @Override
            public void run() {
                SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
                String lastScannedUrl = settings.getString(EMULATOR_Scanned_URL, null);
                String deviceInfo = settings.getString(EMULATOR_Device_Info, null);
                startEmulatorConnection(lastScannedUrl,deviceInfo);
            }
        }.start();
    }

    private void fireApplicationOnCallReceived() {
        if (splashShown && willFireOnApplicationCallReceived) {
            Handler h = new Handler();
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    fireNativeEvent(EventID.ON_APPLICATION_CALL_RECEIVED, getApplicationCallData(-1), jniRef);
                    willFireOnApplicationCallReceived = false;
                }
            }, 200);
        }
    }

    private String getApplicationCallData(int requestCode) {
        JSONObject jobj = new JSONObject();

        try {
            jobj.put("data", callAppData);
            jobj.put("url", urlKeyValue);
            jobj.put("eventType", APPLICATION_CALL_TYPE_CALLBACK);
            jobj.put("result", requestCode);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jobj.toString();
    }

    private void setContentViewAfterSplash() {
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(android.R.color.transparent));
        }
    }

    private void handleEmulatorNotification(final Intent intent) {
        if (intent == null || intent.getExtras() == null)
            return;
        String emulatorNotificationType = intent.getExtras().getString("EmulatorNotificationType");
        if (emulatorNotificationType == null)
            return;

        startingDownloadEmulatorResources = false;
        if (emulatorNotificationType.equals("scan")) {
            if (isScannerEmulator) {
                if (emulatorVersionCheckFailed) {
                    prepareAndStartCamera();
                } else {
                    startCamera();
                }
            } else {
                prepareAndStartCamera();
            }
        } else if (emulatorNotificationType.equals("update")) {
            SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
            String lastScannedUrl = settings.getString(EMULATOR_Scanned_URL, null);
            String deviceInfo = settings.getString(EMULATOR_Device_Info, null);
            if (deviceInfo == null) {
                deviceInfo = getEmulatorDeviceInfo(getApplicationContext());
                SharedPreferences.Editor editor = settings.edit();
                editor.putString(EMULATOR_Device_Info, deviceInfo);
                editor.commit();
            }

            filesToDelete = null;
            // send to core to start communication with ses and download all emulator files
            if (lastScannedUrl == null) {
                Toast.makeText(getApplicationContext(), "There is no project to update, please scan first",
                        Toast.LENGTH_LONG).show();
            } else if (getNetworkConnType() == 0) {
                showEmulatorNetworkErrorAlert();
            } else {
                if (emulatorState instanceof IdleEmulator
                        || (emulatorState instanceof UpdatingEmulator && emulatorState.isTimeOut())) {
                    startEmulatorDownload(lastScannedUrl, true);
                } else {
                    Toast.makeText(getApplicationContext(), "Emulator is already Updating ...", Toast.LENGTH_LONG)
                            .show();
                }
            }
        } else if (emulatorNotificationType.equals("clear")) {
            if (getEmulatorZip().exists()) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SpratAndroidActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (progressBar == null) {
                                    progressBar = new DecimalProgressDialog(SpratAndroidActivity.this);
                                }
                                progressBar.setCommonProps(DecimalProgressDialog.STYLE_SPINNER, "Clearing Emulator ...",
                                        false);
                                progressBar.show();
                            }
                        });
                        intent.removeExtra("EmulatorNotificationType");
                        isScannerEmulator = true;
                        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences,
                                Context.MODE_PRIVATE);
                        settings.edit().remove(EMULATOR_Scanned_URL).commit();
                        settings.edit().remove(EMULATOR_PROJECT_NAME).commit();
                        clearSfCoreData();
                        clearEmulatorIndex();
                        clearEmulatorResources__N();
                        clearEmulatorConnection();
                        statusbarVisibileBeforeScanner = false;
                        actionbarVisibileBeforeScanner = false;
                        hideBars();
                        clearAssignedLocale();
                        splashShown = false;
                        SpratAndroidActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (progressBar != null) {
                                    progressBar.dismiss();
                                }
                                restartSpratActivity();
                            }
                        });

                    }
                }).start();

            } else {
                Toast.makeText(getApplicationContext(), "Smartface Emulator app is already clear.", Toast.LENGTH_LONG)
                        .show();
            }
        }
        // prevent second handling from setSplashInUI
        intent.removeExtra("EmulatorNotificationType");
        isNotificationHandled = true;
    }

    private void clearSfCoreData() {
        // Clearing sf-core/global/data's SharedPreferences
        SharedPreferences sfCoreData = getSharedPreferences("JS", Context.MODE_PRIVATE);
        sfCoreData.edit().clear().commit();

        // Clearing sf-core/ui/webview's all data
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().removeAllCookies(null);
        } else {
            CookieManager.getInstance().removeAllCookie();
        }
        WebStorage.getInstance().deleteAllData();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Firing listeners for onStart
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onStart();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (splashShown && isemulator) {
            handleEmulatorNotification(getIntent());
            if (isScannerEmulator && emulatorState instanceof IdleEmulator && isSetSplashInUiCalled) {
                startCamera();
            }
        }
        prepareEmulatorControls();
        invalidateOptionsMenu();

        if (comesFromNotification) {
            comesFromNotification = false;
            moveTaskToBack(true);
            onPause();
            return;
        }

        isOnBackground = false;

        if (app_is_started_with_start_activity) {
            app_is_started_with_start_activity = false;

        } else if (willFireReceivedNotificationEventOn) {
            Handler h = new Handler();
            h.postDelayed(new Runnable() {
                @Override
                public void run() {

                    fireNativeEvent(EventID.ON_RECEIVED_NOTIFICATION, jniRef);
                }
            }, 200);
            willFireReceivedNotificationEventOn = false;

        } else {
            if (main_layout != null) {
                main_layout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        fireEvent(EventID.ON_MAXIMIZE, jniRef);
                    }
                }, 200);
            }
        }

        // Firing listeners for onResume
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onResume();
        }
    }

    public String getPath__N(int type) {
        /*
         * IOAPApplicationDataDirectory, IOAPApplicationCacheDirectory,
         * IOAPApplicationResources, IOAPApplicationTemporaryData,
         */
        String retval;

        switch (type) {
        case 0: // IOAPApplicationDataDirectory
            retval = getFilesDir().getAbsolutePath();
            break;

        case 1: // IOAPApplicationCacheDirectory
            retval = getCacheDir().getAbsolutePath();
            break;

        case 2: // IOAPApplicationResources
            retval = "images://";
            break;

        case 5: // IOAPApplicationAssets
            retval = "assets://";
            break;

        case 4:
            retval = ""; {
            File file = new File("/system/etc/vold.fstab");
            FileReader fr = null;
            BufferedReader br = null;

            try {
                fr = new FileReader(file);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            try {
                if (fr != null) {
                    br = new BufferedReader(fr);
                    String s = br.readLine();

                    while (s != null) {
                        if (s.startsWith("dev_mount")) {
                            String[] tokens = s.split("\\s");
                            String path = tokens[2].trim(); // mount_point

                            if (!Environment.getExternalStorageDirectory().getAbsolutePath().equals(path)) {
                                retval += path + ";";
                            }
                        }

                        s = br.readLine();
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();

            } finally {
                try {
                    if (fr != null) {
                        fr.close();
                    }

                    if (br != null) {
                        br.close();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
            retval += Environment.getExternalStorageDirectory().getAbsolutePath();
            break;

        case 3: // IOAPApplicationTemporaryData
        default:
            retval = getUnsecureDbPath__N() + "/_tmp";
            new File(retval).mkdirs();
            break;
        }
        // Log.e("______","______"+retval);
        return retval;
    }

    public int getBuildVersionSdk__N() {
        return Build.VERSION.SDK_INT;
    }

    // Saving latest emulator zip file size for checking corruptions
    public void setEmulatorZipTotalSize__N(final int size) {
        setLatestEmulatorZipFileSize(size);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (progressBar == null)
                    return;
                progressBar.setCommonProps(DecimalProgressDialog.STYLE_HORIZONTAL, "Downloading...", false);
                progressBar.setMax(bytesToMB(size));
                progressBar.show();
            }
        });
    }

    volatile Queue<EmulatorZipChunk> emulatorChunkQueue = new LinkedList<>();

    private class EmulatorZipChunk {
        byte[] chunk;
        int byteCount;
        boolean isFinal;
        int offset;

        public EmulatorZipChunk(byte[] c, int bc, boolean f, int off) {
            chunk = c;
            byteCount = bc;
            isFinal = f;
            offset = off;
        }
    }

    private static boolean newEmulatorZip = true;

    public String[] filesToDelete = null;

    public void DeleteFiles() {
        if (filesToDelete == null) { // Nothind to do
            return;
        }

        for (String fileUriStr : filesToDelete) {
            String savingDir = getUnsecureDbPath__N();

            if (fileUriStr.startsWith("assets") || fileUriStr.startsWith("asset") || fileUriStr.startsWith("font")
                    || fileUriStr.startsWith("script") || fileUriStr.startsWith("config")) {
                savingDir += "/assets";
                savingDir += "/" + fileUriStr.substring(fileUriStr.indexOf(':') + 3);
            } else if (fileUriStr.startsWith("image")) {
                Uri fileUri = Uri.parse(fileUriStr);
                savingDir += "/res/" + fileUri.getQueryParameter("density");
                savingDir += "/" + fileUriStr.substring(fileUriStr.indexOf(':') + 3, fileUriStr.indexOf("?"));
            }

            File file = new File(savingDir);
            file.delete();
        }
    }

    Thread chunkSavingThread = new Thread(new Runnable() {
        float totalDownloadByteCount = 0;

        @Override
        public void run() {
            while (true) {
                EmulatorZipChunk emuChunk = emulatorChunkQueue.poll();
                if (emuChunk == null) {
                    try {
                        Thread.currentThread().sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    continue;
                }

                try {
                    FileOutputStream fos = null;
                    if (newEmulatorZip) {
                        fos = new FileOutputStream(getTempEmulatorZip().getPath());
                    } else {
                        fos = new FileOutputStream(getTempEmulatorZip().getPath(), true);
                    }
                    newEmulatorZip = false;
                    fos.write(emuChunk.chunk);
                    fos.flush();
                    fos.close();
                    totalDownloadByteCount += emuChunk.byteCount;
                    SpratAndroidActivity.getInstance().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(bytesToMB(totalDownloadByteCount));
                        }
                    });

                } catch (java.io.IOException e) {
                    Log.e("Smartface", "------- Exception in chunkSavingRunnable", e);
                    totalDownloadByteCount = 0;
                    e.printStackTrace();
                    // todo send to core do request the zip again
                } finally {
                    if (emuChunk.isFinal) {
                        newEmulatorZip = true;
                        emulatorState = new IdleEmulator();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setMessage("Preparing...");
                                totalDownloadByteCount = 0;
                            }
                        });

                        // rename TempSmartfaceEmulator.zip to SmartfaceEmulator.zip
                        try {
                            getTempEmulatorZip().renameTo(getEmulatorZip());
                        } catch (java.lang.Exception e) {
                            Log.e("Smartface", "------- Exception in renameTo", e);
                            e.printStackTrace();
                        }

                        deleteTempSmartfaceEmulatorZipFile();

                        boolean setUpSuccess = setupEmulatorFiles();
                        if (setUpSuccess) {
                            String s = Environment.getExternalStorageDirectory().toString() + "/Android/data/"
                                    + getPackageName();

                            DeleteFiles();
                            // Moving project.json file to assets
                            File projectJsonFile = new File(s + "/cache/project.json");
                            projectJsonFile.renameTo(new File(s + "/cache/assets/project.json"));
                            File emulatorIndexTemp = new File(s + "/emulatorIndexTemp.txt");
                            boolean b = emulatorIndexTemp.renameTo(new File(s + "/emulatorIndex.txt"));

                            emulatorState = new IdleEmulator();
                            splashShown = false;
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (progressBar != null)
                                        progressBar.cancel();
                                    restartSpratActivity();
                                }
                            });
                            try {
                                chunkSavingThread.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();

                            }
                        } else {
                            emulatorState = new UpdatingEmulator();
                        }
                    }
                }
            }
        }
    });

    public float bytesToMB(float bytes) {
        return bytes / (1048576);// bytes to MB;
    }

    public void saveEmulatorZipChunk__N(byte[] chunk, int byteCount, boolean isFirst, boolean isFinal, int offset) {
        resetEmulatorTimeout__N();
        emulatorChunkQueue.add(new EmulatorZipChunk(chunk, byteCount, isFinal, offset));
        if (isFirst && chunkSavingThread.isAlive()) {
            try {
                chunkSavingThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (chunkSavingThread.getState() == Thread.State.NEW)
            chunkSavingThread.start();
    }

    public void resetEmulatorTimeout__N() {
        // resetting the timeout time
        emulatorState.reset();
    }

    // Stopping UpdateEmulator timeout while core calculating diff after getIndex.
    public void stopEmulatorTimeout__N() {
        emulatorState.cancelTimeout();
    }

    // starting UpdateEmulator timeout just after core calculated diff.
    public void startEmulatorTimeout__N() {
        emulatorState.startTimeout();
    }

    public String getDisplaySize__N() {
        if (screenDisplaySize != null) {
            return screenDisplaySize;
        }

        String screenType = "normal";// small;
        String screenDensity = "hdpi";
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        double x = Math.pow(outMetrics.widthPixels / outMetrics.xdpi, 2);
        double y = Math.pow(outMetrics.heightPixels / outMetrics.ydpi, 2);
        double screenInches = Math.sqrt(x + y);
        float density = outMetrics.densityDpi;

        if (screenInches < 3.7) {
            screenType = "small";
        } else if (screenInches < 5) {
            screenType = "normal";
        } else if (screenInches < 7) {
            screenType = "large";
        } else {
            screenType = "xlarge";
        }
        if (density < 160) {
            screenDensity = "ldpi";
        } else if (density < 240) {
            screenDensity = "mdpi";
        } else if (density < 320) {
            screenDensity = "hdpi";
        } else if (density < 480) {
            screenDensity = "xhdpi";
        } else if (density < 640) {
            screenDensity = "xxhdpi";
        } else {
            screenDensity = "xxxhdpi";
        }
        screenDisplaySize = screenType + "-" + screenDensity;
        // System.out.println(type+"typeeeeeeeeeeeeeeeee ");
        return screenDisplaySize;
    }

    @Override
    public void startActivity(Intent intent) {
        app_is_started_with_start_activity = true;
        super.startActivity(intent);
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        app_is_started_with_start_activity = true;
        super.startActivityForResult(intent, requestCode);
    }

    public boolean isOnBackground = false;

    @Override
    protected void onPause() {
        super.onPause();
        isOnBackground = true;

        if (mPreview != null) {
            mPreview.stop();
        }

        if (this.isFinishing()) {
            fireEvent(EventID.ON_EXIT, jniRef);

        } else {
            if (!app_is_started_with_start_activity) {
                fireEvent(EventID.ON_MINIMIZE, jniRef);
            }
        }

        // Firing listeners for onPause
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        if (mPreview != null) {
            mPreview.release();
        }

        splashShown = false;

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(EMULATOR_NOTIFICATION_CODE);

        dismissAllShownDialogs();
        SFHandler.clearAllTimer();
        // Firing listeners for onCreate
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onDestroy();
        }
        super.onDestroy();
    }

    private void dismissAllShownDialogs() {
        Iterator<AlertDialog> it = shownAlerts.iterator();
        while (it.hasNext()) {
            AlertDialog alert = it.next();
            if (alert != null && alert.isShowing())
                alert.dismiss();
            it.remove();
        }
    }

    public String getApplicationName__N() {
        PackageManager pm = getPackageManager();
        String name1 = "";
        String name2 = "";

        try {
            String package_name = this.getClass().getName();
            ComponentName c = new ComponentName(this, package_name);
            ActivityInfo ainfo = pm.getActivityInfo(c, 0);
            name1 = ainfo.loadLabel(pm).toString();
            package_name = package_name.substring(0, package_name.length() - 2);
            ApplicationInfo info = pm.getApplicationInfo(package_name, 0);
            name2 = pm.getApplicationLabel(info).toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (name1.equals(name2)) {
            StringBuffer buf = new StringBuffer();

            for (int i = 0; i < name1.length(); i++) {
                char c = name1.charAt(i);

                if (c >= 'A' && c <= 'Z') {
                    c = (char) (c - 'A' + 'a');
                }

                if (c >= '1' && c <= '9') {
                } else if (c < 'a' || c > 'z') {
                    c = '_';
                }

                buf.append(c);
            }

            return buf.toString();
        }

        return "";
    }

    /**
     * it s the saving path that all the files coresseponding with application.
     *
     *
     * @return saving path
     * @author adem.cayir
     */
    public String getDbPath__N() {
        if (dbPath == null) {
            String s = "" + getFilesDir();
            File f = new File(s);

            if (!f.exists()) {
                f.mkdirs();
            }

            dbPath = s;
        }

        return dbPath;
    }

    public String getExternalStorageDir__N() {
        return Environment.getExternalStorageDirectory().toString();
    }

    public String getUnsecureDbPath__N() {
        if (unsecureDbPath == null) {
            String s = Environment.getExternalStorageDirectory().toString();
            s += "/Android/data/" + getPackageName();

            if (Build.VERSION.SDK_INT >= 8) {
                String cache_dir = "" + getExternalCacheDir();

                if (!cache_dir.equals("null")) {
                    s = cache_dir;

                } else {
                    s += "/cache";
                }
            }

            File f = new File(s);

            if (!f.exists()) {
                boolean dir = f.mkdirs();
                System.out.println("dir:" + dir);

                if (!dir) {
                    f = getFilesDir();
                    s = f.getAbsolutePath();
                }
            }

            unsecureDbPath = s;
        }

        return unsecureDbPath;
        // return getExternalCacheDir().toString().replace("Demo", "Emulator");
    }

    private void initScreenSizeAndRest() {
        cameraIsOn = false;
        initRest();
    }

    public int getActionbarHeight__N() {
        final TypedArray styledAttributes = getTheme()
                .obtainStyledAttributes(new int[] { androidx.appcompat.R.attr.actionBarSize });
        int mActionBarSize = (int) styledAttributes.getDimension(0, 0);
        styledAttributes.recycle();
        return mActionBarSize;
    }

    public int getStatusBarHeight__N() {
        return getDeviceStatusBarHeight__N();
    }

    public int getDeviceStatusBarHeight__N() {
        DisplayMetrics displayMetrics = SpratAndroidActivity.getInstance().getResources().getDisplayMetrics();
        return Math.round(
                25 * (Math.max(displayMetrics.xdpi, displayMetrics.densityDpi) / DisplayMetrics.DENSITY_DEFAULT));
    }

    void initRest() {
        String apkFn = null;

        try {
            String name = getApplicationContext().getPackageName();
            PackageManager pm = getPackageManager();
            apkFn = pm.getApplicationInfo(name, 0).sourceDir;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }

        if (isemulator) {
            String emulatorZipPath = getUnsecureDbPath__N() + "/SmartfaceEmulator.zip";
            if (checkSmartfaceEmulatorZip(emulatorZipPath)) {
                apkFn = emulatorZipPath;
                isScannerEmulator = false;
            }
        }

        final String apnFnFinal = apkFn;
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setSplashScreenOnUI();
        cameraIsOn = false;

        String masterKey = initialize(apnFnFinal);
        Log.d("DESKEY", " masterKey -->" + masterKey);
    }

    // Checking if emulator zip file exists and not corrupted.
    private boolean checkSmartfaceEmulatorZip(String emulatorZipPath) {
        int fileSize = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE)
                .getInt(EMULATOR_ZIP_SIZE, 0);
        File emulatorZipFile = new File(emulatorZipPath);
        return emulatorZipFile.exists() && emulatorZipFile.length() == fileSize;
    }

    private void setSplashScreenOnUI() {
        setContentView(R.layout.splash);
        if (isemulator) {
            // for prevent Player crash find textview id
            int textView_splashVersionNameID = getResources().getIdentifier("textView_splashVersionName", "id",
                    getPackageName());
            if (textView_splashVersionNameID != 0) {
                TextView mTextView_SplashVersionName = (TextView) findViewById(textView_splashVersionNameID);
                try {
                    PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                    mTextView_SplashVersionName
                            .setText(getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            splashShown = true;
        }
    }

    public Context getApplicationContext__N() {
        return getApplicationContext();
    }

    private void removeFiles(File f) {
        File files[] = f.listFiles();

        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                removeFiles(files[i]);
            } else {
                files[i].delete();
            }
        }
        f.delete();
    }

    private HashMap<String, String> emulatorResMap = new HashMap<String, String>();

    private void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dst);

        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }

    public void restartSpratActivity() {
        isRestartingActivity = true;
        SFHandler.clearAllTimer();
        // Firing listeners for onDestroy
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onDestroy();
        }
        activityLifeCycleListeners = new ArrayList<>();

        Intent mIntent = getIntent();
        mIntent.putExtra("EmulatorRestart", true);
        // setData function used for solving this issue:
        // https://smartface.atlassian.net/browse/AND-3741
        finish();
        mIntent.setData(null);
        startActivity(mIntent);
    }

    public void restartSpratActivity__N() {
        Intent intent = getIntent();
        splashShown = false;

        freeResources();
        finish();
        startActivity(intent);
    }

    public void unzipAndUpdateRAU__N() {
        String path = getFilesDir() + "/system/rau/";
        File rauFolder = new File(path);
        String zipPath = path + "AndroidRAU.zip";
        // ******
        rauFolder.mkdirs();
        File to = new File(zipPath);
        File from = new File("/storage/emulated/0/Android/data/AndroidRAU.zip");
        try {
            copy(from, to);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (unZip(path, zipPath, true)) {
            File scriptsFolder = new File(path + "/scripts/");
            if (scriptsFolder.exists()) {
                moveAllScriptsToAssets(scriptsFolder);
            }
            Map<String, String> playerResMap = new HashMap<>();
            getAllFilesInRAU(playerResMap, rauFolder);
            File emulatorResMapFile = new File(path + "/playerRAUResMap.txt");
            try {
                emulatorResMapFile.createNewFile();
                PrintWriter pr = new PrintWriter(
                        new BufferedWriter(new FileWriter(path + "/playerRAUResMap.txt", true)));
                for (String s : playerResMap.keySet()) {
                    pr.println(s + " " + playerResMap.get(s));
                }
                pr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            SpBitmapRef.holders_bitmap.clear();
        }
    }

    private void getAllFilesInRAU(Map<String, String> playerResMap, File currFolder) {
        for (File f : currFolder.listFiles()) {

            if (f.getAbsolutePath().endsWith("AndroidRAU.zip"))
                continue;

            if (f.isDirectory()) {
                getAllFilesInRAU(playerResMap, f);
            } else {
                String fname = f.getAbsolutePath();
                int start = fname.indexOf("scripts/");
                if (start >= 0) {
                    fname = fname.substring(start + 8);
                } else {
                    start = fname.indexOf("assets/");
                    fname = fname.substring(start + 7);
                }
                playerResMap.put(fname, f.getAbsolutePath());
            }
        }
    }

    private void moveAllScriptsToAssets(File scriptsFolder) {
        for (File f : scriptsFolder.listFiles()) {
            String newPath = f.getAbsolutePath().replace("scripts/", "assets/");
            File toFile = new File(newPath);
            f.renameTo(toFile);
        }
    }

    private boolean unZip(String path, String zipPath, boolean isRauZip) {
        File f = new File(zipPath);
        InputStream is;
        ZipInputStream zis;

        try {
            is = new FileInputStream(f);
            zis = new ZipInputStream(new BufferedInputStream(is));
            ZipEntry ze;
            byte[] buffer = new byte[1024];
            int count;
            String filename;

            while ((ze = zis.getNextEntry()) != null) {
                filename = ze.getName();
                if (filename.startsWith("__MACOSX"))
                    continue;
                StringBuilder fullFilePath = new StringBuilder(path + filename);
                if (isRauZip && filename.endsWith(".js")) {
                    fullFilePath.append("e");
                }
                File fileInZip = new File(fullFilePath.toString());
                boolean fileCreated = true;
                if (ze.isDirectory()) {
                    if (fileInZip.exists() == false)
                        fileCreated = fileInZip.mkdirs();
                    continue;
                }
                if (fileInZip.exists() == false) {
                    File parent = new File(fileInZip.getParent());
                    parent.mkdirs();
                    fileCreated = fileInZip.createNewFile();
                }

                long ti_z_f = System.currentTimeMillis();

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                try {
                    FileOutputStream fout = new FileOutputStream(fileInZip);

                    while ((count = zis.read(buffer)) != -1) {
                        fout.write(buffer, 0, count);
                    }

                    fout.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
                ti_z_f = System.currentTimeMillis() - ti_z_f;

                zis.closeEntry();
            }

            zis.close();

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean setupEmulatorFiles() {
        File f = getEmulatorZip();
        String path = getUnsecureDbPath__N() + "/";
        long ti_z = System.currentTimeMillis();
        if (f.exists()) {
            if (!unZip(path, f.getAbsolutePath(), false)) {
                return false;
            }
            File descriptor = new File(path + "descriptor.txt");

            if (descriptor.exists()) {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(descriptor)));
                    String line;
                    while ((line = br.readLine()) != null && line.indexOf(" ") != -1) {
                        int split = line.indexOf(" ");
                        String fileName = line.substring(0, split);
                        String fileUriStr = line.substring(split + 1);
                        String savingDir = getUnsecureDbPath__N();

                        if (fileUriStr.startsWith("assets") || fileUriStr.startsWith("asset")
                                || fileUriStr.startsWith("font") || fileUriStr.startsWith("script")
                                || fileUriStr.startsWith("config")) {
                            savingDir += "/assets";
                            savingDir += "/" + fileUriStr.substring(fileUriStr.indexOf(':') + 3);

                        } else if (fileUriStr.startsWith("image")) {
                            Uri fileUri = Uri.parse(fileUriStr);
                            savingDir += "/res/" + fileUri.getQueryParameter("density");
                            savingDir += "/"
                                    + fileUriStr.substring(fileUriStr.indexOf(':') + 3, fileUriStr.indexOf("?"));
                        }
                        emulatorResMap.put(fileName, savingDir);
                    }
                    // Manually adding project.json because we are manually writing project.json
                    emulatorResMap.put("project.json", getUnsecureDbPath__N() + "/assets/project.json");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    return false;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            }
            File emulatorResMapFile = new File(getUnsecureDbPath__N() + "/emulatorResMap.txt");
            try {
                emulatorResMapFile.createNewFile();
                PrintWriter pr = new PrintWriter(
                        new BufferedWriter(new FileWriter(getUnsecureDbPath__N() + "/emulatorResMap.txt", true)));

                for (String fname : emulatorResMap.keySet()) {
                    String name = fname;
                    File file = new File(getUnsecureDbPath__N() + "/" + name);
                    String to = emulatorResMap.get(fname);
                    File toDir = new File(to.substring(0, to.lastIndexOf("/")));
                    if (!toDir.exists())
                        toDir.mkdirs();
                    File toFile = new File(to);
                    boolean success = file.renameTo(toFile);
                    Log.e("SMF @@ --------- ", success + " ----------- " + to);
                    pr.println(fname + " " + emulatorResMap.get(fname));
                }

                File pagesDir = new File(path + "/pages");
                pagesDir.delete();

                File i18nDir = new File(path + "/i18n");
                i18nDir.delete();
                pr.close();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }

            ti_z = System.currentTimeMillis() - ti_z;

            System.out.println("smartafce emulator: setupEmulatorFiles total time :" + ti_z);
            return true;
        }
        return false;
    }

    private int performcount = 0;

    private class PerformLock {
        int count = performcount++;
        boolean isUsing;
    }

    private Vector<PerformLock> locks = new Vector<SpratAndroidActivity.PerformLock>();

    public void performOnMainThread__N(final long selectorId, final long selectorArg, final boolean synced) {
        boolean mainThread = isMainThread__N();
        // final Semaphore semaphore;
        boolean wait = false;

        if (mainThread == false) {
            if (synced) {
                wait = true;
                // semaphore = new Semaphore(0);

            } else {
                // semaphore = null;
            }
        } else {
            if (synced == false) {
                // semaphore = null;
            } else {
                // Handled in calling native code.
                return;
            }
        }

        PerformLock lock = null;

        synchronized (locks) {
            if (wait) {
                for (int i = 0; i < locks.size(); i++) {
                    if (!locks.get(i).isUsing) {
                        lock = locks.get(i);
                        lock.isUsing = true;
                        break;
                    }
                }

                if (lock == null) {
                    lock = new PerformLock();
                    lock.isUsing = true;
                    locks.add(lock);
                }
            }
        }

        final PerformLock _lock = lock;
        Runnable action = new Runnable() {
            @Override
            public void run() {
                try {
                    performOnMainThread(selectorId, selectorArg, _lock);

                } catch (RuntimeException e) {
                    Log.e("SpratAndroidActivity", "performOnMainThread unexpected async exception", e);
                }
            }
        };
        performOnMainThread(selectorId, selectorArg, _lock);

        if (lock != null) {
            try {
                synchronized (lock) {
                    if (lock.isUsing) {
                        lock.wait();

                    } else {
                    }
                }
            } catch (InterruptedException e) {
                Log.e("SpratAndroidActivity", "performOnMainThread unexpected interruption", e);
            }
        }
    }

    public void endWaitingForMainThread__N(Object l) {
        PerformLock lock = (PerformLock) l;

        synchronized (lock) {
            lock.isUsing = false;
            lock.notifyAll();
        }
    }

    public boolean isMainThread__N() {
        return Thread.currentThread() == getMainLooper().getThread();
    }

    public void fireNativeEvent(int id, String args, long jni) {
        if (jni == 0) {
            System.out.println("Native handler is NULL for id " + id);
            debugStack();
        }

        fireEventWithOptionNatively(id, args, jni);
    }

    public void fireNativeEvent(int id, long jni) {
        if (jni == 0) {
            System.out.println("Native handler is NULL for id " + id);
            debugStack();
        }

        long ti = System.currentTimeMillis();
        fireEventNatively(id, jni);
        long ti2 = System.currentTimeMillis() - ti;

        if (ti2 - ti > 10) {
            System.out.println("event fire time: event=" + id + ", time=" + (ti2 - ti));
        }
    }

    public void fireEvent(int id, long jni) {
        // System.out.println("Firing native event: id, ref= " + id + ", " +
        // jni);
        if (jni == 0) {
            System.out.println("Native handler is NULL for id " + id);
            debugStack();
        }

        long ti = System.currentTimeMillis();
        fireEventNatively(id, jni);
        long ti2 = System.currentTimeMillis() - ti;

        if (ti2 - ti > 10) {
            System.out.println("event fire time1: event=" + id + ", time=" + (ti2 - ti));
        }
    }

    public void setAllowedOrientations__N(boolean orientationPortraitNormalAllowed,
            boolean orientationPortraitReverseAllowed, boolean orientationLandscapeNormalAllowed,
            boolean orientationLandscapeReverseAllowed) {
        orientationsAllowed[0] = orientationPortraitNormalAllowed;
        orientationsAllowed[1] = orientationPortraitReverseAllowed;
        orientationsAllowed[2] = orientationLandscapeNormalAllowed;
        orientationsAllowed[3] = orientationLandscapeReverseAllowed;
    }

    public void setSplashScreen__N() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    setSplashInUi();

                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    void setSplashInUi() {
        Runnable action = new Runnable() {
            @Override
            public void run() {
                try {
                    splashShown = true;
                    isSetSplashInUiCalled = true;
                    if (mPrefs.getBoolean("firstStart", true)) {
                        clearEmulatorResources__N();
                    }

                    if (!isScannerEmulator) {
                        if (!isemulator) { // player case
                            cameraIsOn = false;
                            setUpAfterSplash();
                        } else { // emulator case
                            // if there are no notification handle case start application.
                            if (!isNotificationHandled) {
                                // This statement belongs to debugger, keep for future debug imp.
                                //showDebuggerWaitingDialog();
                                startEmulatorFlow();
                                setUpAfterSplash();
                                cameraIsOn = false;
                                isCoreStarted = true;
                            }
                        }
                    } else {
                        if (isemulator && mPrefs.getBoolean("firstStart", true)) {
                            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
                            setContentView(R.layout.emulator_welcome_layout);
                            cameraIsOn = false;
                            SFWelcomePage.show(getInstance());
                        } else {
                            prepareAndStartCamera();
                        }
                    }
                    mPrefs.edit().putBoolean("firstStart", false).commit();
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
            }
        };

        long timeToSleep = 300;
        if (isemulator) {
            timeToSleep = 2000;
        }

        Handler h = new Handler();
        h.postDelayed(action, timeToSleep);
    }

    public void loadPlugins__N() {
        try {
            long jsContextref = getJSContextRef();
            long envmapref = getJNIVMapRef();

            for (int i = 0; pInterfaceList != null && i < pInterfaceList.size(); i++) {
                pInterfaceList.get(i).initPlugins(jsContextref, envmapref);
            }

        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }

    static void debugStack() {
        try {
            throw new RuntimeException();

        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }

    public String getAvailableFontsList__N() {
        if (availableFontNames != null) {
            return availableFontNames;
        }

        JSONArray installedFonts = new JSONArray();
        String[] fontdirs = { "/system/fonts", "/system/font", "/data/fonts" };

        for (int i = 0; i < fontdirs.length; i++) {
            JSONArray fontList = readAllFontsInstalled(fontdirs[i]);

            if (fontList.length() != 0) {
                installedFonts = fontList;
                break;
            }
        }

        try {
            String[] assetFiles = getAssets().list("");

            for (int i = 0; i < assetFiles.length; i++) {
                String fileName = assetFiles[i];

                if (fileName.endsWith(".ttf")) {
                    installedFonts.put(fileName.substring(0, fileName.indexOf(".ttf")));
                }

                if (fileName.endsWith(".otf")) {
                    installedFonts.put(fileName.substring(0, fileName.indexOf(".otf")));
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return installedFonts.toString();
    }

    private JSONArray readAllFontsInstalled(String path) {
        JSONArray fontNames = new JSONArray();
        File temp = new File(path);

        if (!temp.exists()) {
            return fontNames;
        }

        String fontSuffix1 = ".ttf";
        String fontSuffix2 = ".otf";

        for (File font : temp.listFiles()) {
            String fontName = font.getName();

            if (fontName.endsWith(fontSuffix1)) {
                fontNames.put(fontName.substring(0, fontName.indexOf(fontSuffix1)));
            }

            if (fontName.endsWith(fontSuffix2)) {
                fontNames.put(fontName.substring(0, fontName.indexOf(fontSuffix2)));
            }
        }

        return fontNames;
    }

    public void setJniRef__N(long jniRef) {
        this.jniRef = jniRef;
    }

    public void showToast__N(final String message, final int time) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(SpratAndroidActivity.this, message, time).show();
            }
        });
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(String name, Context context, AttributeSet attrs) {
        return super.onCreateView(name, context, attrs);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // TODO Auto-generated method stub
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if ((this.isFinishing()) || (isRestartingActivity == true) || SFPAGE_ANIMATION_STARTED)
            return true;
        // ToDo: Remove dispatchTouchEvent from activity life cycle and implement with
        // SMFCallback
        boolean dispatch = false;
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            dispatch = listener.dispatchTouchEvent(ev.getAction(), ev.getX(), ev.getY());
        }

        return (dispatch == true ? dispatch : super.dispatchTouchEvent(ev));
    }

    public void closeAlert__N(final long eventJniRef) {
        WeakReference<AlertDialog> weak = openAlerts.get(eventJniRef);

        if (weak != null) {
            AlertDialog a = weak.get();

            if (a != null) {
                a.dismiss();
                openAlerts.remove(eventJniRef);
            }
        }
    }

    public void closeAlert__N(Object _closer) {
        if (_closer != null) {
            AlertCloser closer = (AlertCloser) _closer;
            closer.close();
        }
    }

    static class AlertCloser {
        AlertDialog a;
        boolean closed = false;
        boolean closing = false;

        void close() {
            closed = true;

            if (a != null) {
                a.dismiss();
            }
        }
    }

    public static native void setAlertIsClosing(long eventJniRef);

    public static ArrayList<AlertDialog> shownAlerts = new ArrayList<>();

    public Object showAlert__N(final String title, final String message, final int alpha, final int numOfButton,
            final String firstButton, final String secondButton, final String thirdButton, final long eventJniRef) {
        final AlertCloser closer = new AlertCloser();
        SpratAndroidActivity.runUiOperation(new Runnable() {
            @Override
            public void run() {
                AlertDialog a = new AlertDialog.Builder(SpratAndroidActivity.this).create();
                a.setCanceledOnTouchOutside(false);
                a.setCancelable(false);
                closer.a = a;

                if (title != null) {
                    a.setTitle(title.trim());
                }

                if (message != null) {
                    a.setMessage(message);

                    if (message.equals("Waiting for debugger to connect")) {
                        ProgressBar pr = new ProgressBar(SpratAndroidActivity.this);
                        a.setView(pr);
                    }
                }

                if (numOfButton >= 1) {
                    String _firstButton = firstButton;

                    if (_firstButton == null) {
                        _firstButton = getString(android.R.string.ok);
                    }

                    a.setButton(DialogInterface.BUTTON_POSITIVE, _firstButton, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            setAlertIsClosing(eventJniRef);
                            fireNativeEvent(EventID.ON_DIALOGFIRSTBUTTON, eventJniRef);
                        }
                    });
                }

                if (numOfButton >= 2) {
                    a.setButton(DialogInterface.BUTTON_NEUTRAL, secondButton, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            setAlertIsClosing(eventJniRef);
                            fireNativeEvent(EventID.ON_DIALOGSECONDBUTTON, eventJniRef);
                        }
                    });
                }

                if (numOfButton >= 3) {
                    a.setButton(DialogInterface.BUTTON_NEGATIVE, thirdButton, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            setAlertIsClosing(eventJniRef);
                            fireNativeEvent(EventID.ON_DIALOGTHIRDBUTTON, eventJniRef);
                        }
                    });
                }

                a.show();
                if (isemulator) {
                    shownAlerts.add(a);
                }
                WeakReference<AlertDialog> w = new WeakReference<AlertDialog>(a);
                openAlerts.put(eventJniRef, w);
            }
        });
        return (Object) closer;
    }

    /**
     * this function is called after another application ends that starts with this
     * activity.
     *
     * REQUEST_CODE_TAKE_PICTURE request code for camera result
     * REQUEST_CODE_AUTHORIZE_FACEBOOK request code for logging in to facebook
     *
     * @param requestCode
     * @param resultCode
     * @param data
     * @author adem.cayir
     */
    @Override
    public void onActivityResult(final int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (Arrays.asList(getResources().getAssets().list("")).contains("PluginConfig.JSON")) {
                InputStream in = getApplicationContext().getResources().getAssets().open("PluginConfig.JSON");

                InputStreamReader is = new InputStreamReader(in);
                BufferedReader br = new BufferedReader(is);
                String read = br.readLine();
                StringBuilder sbuilder = new StringBuilder();

                while (read != null) {
                    sbuilder.append(read);
                    read = br.readLine();
                }
                JSONObject jsonObj = new JSONObject(sbuilder.toString());
                JSONArray jsonArray = jsonObj.getJSONArray("classes");
                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        Class<?> pluginClass = Class.forName(jsonArray.getString(i));
                        try {
                            Method onActivityResultMethod = pluginClass.getMethod("onActivityResult", int.class,
                                    int.class, Intent.class);
                            if (onActivityResultMethod != null) {
                                try {
                                    onActivityResultMethod.invoke(null, requestCode, resultCode, data);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        } catch (NoSuchMethodException e) {
                            e.printStackTrace();
                        }
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        switch (requestCode) {
        case REQUEST_CODE_CALL_APPLICATION:
            callAppData = null;
            String urlKeyValue = null;
            if (data == null)
                break;
            setAppData(data.getExtras());

            if (data.getData() != null) {
                urlKeyValue = data.getData().toString();
            }

            if (callAppData != null || urlKeyValue != null) {
                fireNativeEvent(EventID.ON_APPLICATION_CALL_RECEIVED, getApplicationCallData(requestCode), jniRef);
            }
            break;
        default:
            for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
                listener.onActivityResult(requestCode, resultCode, data);
            }
            break;
        }
    }

    public void setAppData(Bundle extras) {
        callAppData = new JSONObject();
        for (String key : extras.keySet()) {
            try {
                callAppData.put(key, extras.get(key).toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    Bitmap getBitmap(String path) {
        return SpBitmapRef.getBitmap(this, path, 0, 0, false);
    }

    public String getDeviceId__N() {
        String imei = "";
        try {
            imei = getIMEI();
        } catch (Exception e) {
        }
        return imei;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Firing listeners for onConfigurationChanged
        for (ActivityLifeCycleListener listener : activityLifeCycleListeners) {
            listener.onConfigurationChanged(newConfig);
        }

        processConfigurationChange(newConfig);
    }

    private void processConfigurationChange(Configuration newConfig) {
        if (applicationConfiguration.getLayoutDirection() != newConfig.getLayoutDirection()) {
            restartSpratActivity__N();
        }
    }

    public static SpratAndroidActivity getInstance() {
        return (SpratAndroidActivity) instance;
    }

    public static AppCompatActivity getActivity() {
        return instance;
    }

    public String getDeviceIp__N() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = en.nextElement();

                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();

                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        return inetAddress.getHostAddress();
                    }
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return "";
    }

    public void callApplication__N(String appName, Vector<String> keys, Vector<String> values) {
        try {
            String packageName = appName.substring(0, appName.indexOf('|'));
            String className = appName.substring(appName.indexOf('|') + 1, appName.length());
            Intent intent = new Intent();
            intent.setClassName(packageName, className);

            for (int i = 0; i < keys.size() && i < values.size(); i++) {
                intent.putExtra(keys.get(i), values.get(i));
            }

            startActivityForResult(intent, REQUEST_CODE_CALL_APPLICATION);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteRAUFilesIfNeeded__N(String appVersion) {
        if (isemulator || (appVersion == null))
            return;
        SharedPreferences sharedPreferences = getSharedPreferences("JS", 0);
        if (sharedPreferences == null)
            return;
        String rauVersion = sharedPreferences.getString("rauNewVersion", null);
        if (rauVersion != null) {
            if (appVersion.compareTo(rauVersion) > 0) {
                File rauProjectJson = new File(getDbPath__N() + "/project.json");
                if (rauProjectJson.exists())
                    rauProjectJson.delete();

                String path = getFilesDir() + "/system/rau/";
                File rauFolder = new File(path);
                if (rauFolder.exists()) {
                    removeFiles(rauFolder);
                }
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("rauNewVersion");
                editor.commit();
            }
        }
    }

    public void addPluginInterface(SpPluginInterface pInterface) {
        if (this.pInterfaceList == null) {
            this.pInterfaceList = new Vector<SpPluginInterface>();
        }

        this.pInterfaceList.add(pInterface);
    }

    private List<String> cropedAndResizedImages = new ArrayList<String>();

    private long cropEventJni;
    private static Uri CropImagePath;
    private boolean cropPng;

    private String removeURIExtension(String s) {
        if (s.contains("://")) {
            int indx = s.lastIndexOf("://") + 3;
            if (indx < s.length()) {
                s = s.substring(indx);
            }
        }
        return s;
    }

    public byte[] readFileInAssetsOrResources__N(int existsIn, String fileName) {
        byte[] fContent = {};

        if (fileName != null && fileName.length() > 0) {
            fileName = removeURIExtension(fileName);
            try {
                if (existsIn == 1) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    if (isemulator) {
                        File resMap = new File(getUnsecureDbPath__N() + "/emulatorResMap.txt");
                        if (resMap.exists()) {
                            FileReader fileReader = new FileReader(resMap);
                            BufferedReader bufferedReader = new BufferedReader(fileReader);
                            String s = null;
                            while ((s = bufferedReader.readLine()) != null) {
                                if (s.startsWith(fileName)) {
                                    s = s.substring(s.indexOf(" ") + 1);
                                    Bitmap bitmap = BitmapFactory.decodeFile(s);
                                    bitmap.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
                                    fContent = byteArrayOutputStream.toByteArray();
                                }
                            }
                        }
                    } else {
                        int dotIndx = fileName.lastIndexOf('.');
                        fileName = fileName.substring(0, dotIndx);
                        int id = getResources().getIdentifier(fileName, "drawable", getPackageName());
                        if (id != 0) {
                            Drawable drawable = getResources().getDrawable(id);
                            BitmapDrawable bitmapDrawable = ((BitmapDrawable) drawable);
                            Bitmap bitmap = bitmapDrawable.getBitmap();
                            bitmap.compress(CompressFormat.PNG, 100, byteArrayOutputStream); // use the compression
                                                                                             // format of your need
                            fContent = byteArrayOutputStream.toByteArray();
                        }
                    }
                    byteArrayOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return fContent;
    }

    public boolean doesFileExist__N(int existsIn, String fileName) {// 0 -> in Assets , 1 -> in Resources
        if (fileName != null && fileName.length() > 0) {
            fileName = removeURIExtension(fileName);
            if (existsIn == 0) {
                try {
                    if (Arrays.asList(getResources().getAssets().list("")).contains(fileName))
                        return true;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (existsIn == 1) {
                int dotIndx = fileName.lastIndexOf('.');
                if (dotIndx == -1)
                    return false;
                fileName = fileName.substring(0, dotIndx);

                int id = getResources().getIdentifier(fileName, "drawable", getPackageName());
                if (id != 0)
                    return true;
                id = getResources().getIdentifier(fileName, "raw", getPackageName());
                if (id != 0)
                    return true;
                id = getResources().getIdentifier(fileName, "anim", getPackageName());
                if (id != 0)
                    return true;
                id = getResources().getIdentifier(fileName, "layout", getPackageName());
                if (id != 0)
                    return true;
                id = getResources().getIdentifier(fileName, "menu", getPackageName());
                if (id != 0)
                    return true;
            }
        }
        return false;
    }

    private class SpDrawerLayout extends DrawerLayout {
        public SpDrawerLayout(Context context) {
            super(context);
        }

        private boolean mIsDisallowIntercept = false;

        @Override
        public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
            // keep the info about if the innerViews do requestDisallowInterceptTouchEvent
            mIsDisallowIntercept = disallowIntercept;
            super.requestDisallowInterceptTouchEvent(disallowIntercept);
        }

        // fix for multi-touch behavior and doing requestDisallowInterceptTouchEvent in
        // innerViews of the DrawerLayout
        // https://code.google.com/p/android/issues/detail?can=2&start=0&num=100&q=&colspec=ID%20Type%20Status%20Owner%20Summary%20Stars&groupby=&sort=&id=60464
        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            // the incorrect array size will only happen in the multi-touch scenario.
            if (ev.getPointerCount() > 1 && mIsDisallowIntercept) {
                requestDisallowInterceptTouchEvent(false);
                boolean handled = super.dispatchTouchEvent(ev);
                requestDisallowInterceptTouchEvent(true);
                return handled;

            } else {
                return super.dispatchTouchEvent(ev);
            }
        }
    }

    public void setLatestEmulatorZipFileSize(int fileSize) {
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt(EMULATOR_ZIP_SIZE, fileSize);
        editor.commit();
    }

    static String getEmulatorDeviceInfo(Context context) {
        try {
            JSONObject info = new JSONObject();
            Build buildInfo = new Build();
            String deviceId = "82df0f5d-8fa8-410b-8625-a2cc18035308";
            if (readPhoneStateGranted)
                deviceId = DeviceUtil.getDeviceId(getActivity());
            if (deviceId == null) {
                SharedPreferences settings = SpratAndroidActivity.getInstance()
                        .getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                deviceId = settings.getString(EMULATOR_Device_Id, null);
                if (deviceId == null) {
                    deviceId = UUID.randomUUID().toString();
                    editor.putString(EMULATOR_Device_Id, deviceId);
                    editor.commit();
                }
            }
            String cpu = Build.CPU_ABI.contains("x86") ? "x86"
                    : Build.CPU_ABI.contains("armeabi") ? "ARM" : Build.CPU_ABI;
            Log.d("SMF Emulator", "SMF Device ID : " + deviceId);
            info.put("deviceID", deviceId).put("deviceName", buildInfo.HOST).put("brandModel", buildInfo.MODEL)
                    .put("brandName", buildInfo.BRAND).put("os", "Android").put("osVersion", Build.VERSION.RELEASE)
                    .put("smartfaceVersion", "5.0.0"). // TODO(ewanas)
                    put("screen", screenInfo(context))
                    .put("resourceFolderOrder", ResourceOrdering.resourceOrder(context)).put("cpu", cpu);

            return info.toString();
        } catch (JSONException e) {
            return new JSONObject().toString();
        }
    }

    //ToDo: This is NATIVE method called from framework-core. Rename to _N
    public void setEmulatorAppAndBuildVersions(String appVersion, int buildVersion) {
        SharedPreferences settings = getSharedPreferences(EMULATOR_Private_Perferences, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(EMULATOR_APP_VERSION, appVersion);
        editor.putString(EMULATOR_BUILD_VERSION, String.valueOf(buildVersion));
        editor.commit();
    }

    static JSONObject screenInfo(Context context) {
        try {
            JSONObject info = new JSONObject();

            DisplayManager dm = (DisplayManager) (context.getSystemService(Context.DISPLAY_SERVICE));

            Display d = dm.getDisplays()[0];

            DisplayMetrics metrics = new DisplayMetrics();
            d.getMetrics(metrics);

            JSONObject pixelSize = new JSONObject();
            pixelSize.put("width", metrics.widthPixels);
            pixelSize.put("height", metrics.heightPixels);

            JSONObject dpSize = new JSONObject();
            dpSize.put("width", metrics.xdpi);
            dpSize.put("height", metrics.ydpi);

            info.put("px", pixelSize);
            info.put("dp", dpSize);

            return info;
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    static class ResourceOrdering implements Comparator<Integer> {
        static final int LDPI = 120;
        static final int MDPI = 160;
        static final int HDPI = 240;
        static final int XHDPI = 320;
        static final int XXHDPI = 480;
        static final int XXXHDPI = 640;

        static Integer[] allDensities = new Integer[] { LDPI, MDPI, HDPI, XHDPI, XXHDPI, XXXHDPI };

        final int deviceDensity;

        public ResourceOrdering(int deviceDensity) {
            this.deviceDensity = deviceDensity;
        }

        public int compare(Integer a, Integer b) {
            return Math.abs(a - deviceDensity) - Math.abs(b - deviceDensity);
        }

        public boolean equals(Object other) {
            return other instanceof ResourceOrdering;
        }

        static JSONArray resourceOrder(Context context) {
            JSONArray arr = new JSONArray();

            DisplayManager dm = (DisplayManager) (context.getSystemService(Context.DISPLAY_SERVICE));

            Display d = dm.getDisplays()[0];

            DisplayMetrics metrics = new DisplayMetrics();
            d.getMetrics(metrics);

            int dpi = metrics.densityDpi;

            Arrays.sort(allDensities, new ResourceOrdering(metrics.densityDpi));

            for (int i : allDensities) {
                arr.put(densityString(i));
            }

            return arr;
        }

        static String densityString(int dpi) {
            switch (dpi) {
            case LDPI:
                return "drawable-ldpi";
            case HDPI:
                return "drawable-hdpi";
            case XHDPI:
                return "drawable-xhdpi";
            case XXHDPI:
                return "drawable-xxhdpi";
            case XXXHDPI:
                return "drawable-xxxhdpi";
            default:
                return "drawable-mdpi";
            }
        }
    }
}