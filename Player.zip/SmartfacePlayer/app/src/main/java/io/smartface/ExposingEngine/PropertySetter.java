package io.smartface.ExposingEngine;

public abstract class PropertySetter {
    protected Object propertyObject = null;

    public PropertySetter(Object object) {
        propertyObject = object;
    }

    public abstract boolean set(Object holder, Object value);
}
