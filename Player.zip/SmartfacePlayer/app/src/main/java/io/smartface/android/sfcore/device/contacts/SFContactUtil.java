package io.smartface.android.sfcore.device.contacts;

import android.content.ContentProviderOperation;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.android.sfcore.SFPage;


import java.util.ArrayList;
import java.util.List;


class SFContactUtil {

    private SFContactUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static String[] getStructuredName(String id) {
        String[] selectionArgs = new String[]{ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE, id};

        Cursor cursor = SpratAndroidActivity.getActivity().getContentResolver().query(ContactsContract.Data.CONTENT_URI, null,
                ContactsContract.Data.MIMETYPE + " = ? AND " + ContactsContract.CommonDataKinds.StructuredName.CONTACT_ID + " = ?", selectionArgs, null);

        String[] nameStructure = new String[0];
        if (cursor != null && cursor.moveToFirst()) {
            int firstNameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME);
            int familyIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME);
            int nPrefixIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.PREFIX);
            int mNameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME);
            int nSuffixIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.SUFFIX);

            //Unfortunately, Native Api Access doesn't accept the null as element of String array
            String firstName = getString(cursor, firstNameIndex);
            String familyName = getString(cursor, familyIndex);
            String nPrefix = getString(cursor, nPrefixIndex);
            String mName = getString(cursor, mNameIndex);
            String nSuffix = getString(cursor, nSuffixIndex);

            nameStructure = new String[]{firstName, familyName, nPrefix, mName, nSuffix};
            cursor.close();
        }
        return nameStructure;
    }


    public static String[] getUrlAddresses(String id) {
        final String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Website.URL
        };
        String selection = ContactsContract.Data.CONTACT_ID + " = " + id + " AND " + ContactsContract.Contacts.Data.MIMETYPE + " = '" + ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE + "'";

        final Cursor contactData = SpratAndroidActivity.getActivity().getContentResolver().query(ContactsContract.Data.CONTENT_URI, projection, selection, null, null);

        List<String> urlAddresses = new ArrayList<>();
        if (contactData.moveToFirst()) {
            int count = 0;
            do {
                int urlAddressesIndex = contactData.getColumnIndex(ContactsContract.CommonDataKinds.Website.URL);

                if (urlAddressesIndex != -1 && !contactData.isNull(urlAddressesIndex))
                    urlAddresses.add(contactData.getString(urlAddressesIndex));

            } while (contactData.moveToNext());
        }
        contactData.close();

        String[] result = urlAddresses.toArray(new String[urlAddresses.size()]);

        return result;
    }

    public static String[] getContactDataById(Uri contactUri, String[] projection, String id) {
        Cursor contentCursor = SpratAndroidActivity.getActivity().getContentResolver().query(contactUri, projection, ContactsContract.Data.CONTACT_ID + " = ?", new String[]{id}, null);

        List<String> data = new ArrayList<>();
        if (contentCursor != null && contentCursor.getCount() > 0) {
            int count = 0;
            if (contentCursor.moveToFirst()) {
                do {
                    int columnIndex = contentCursor.getColumnIndex("data1");
                    if (columnIndex != -1 && !contentCursor.isNull(columnIndex))
                        data.add(contentCursor.getString(columnIndex));

                } while (contentCursor.moveToNext());
            }
            contentCursor.close();
        }

        String[] result = data.toArray(new String[data.size()]);

        return result;
    }

    public static String getContactId(Uri contactUri) {
        Cursor idCursor = SpratAndroidActivity.getActivity().getContentResolver().query(contactUri, new String[]{ContactsContract.Contacts._ID},
                null, null, null);
        if (!idCursor.moveToFirst()) {
            idCursor.close();
            return null;
        }
        String id = idCursor.getString(idCursor.getColumnIndex(ContactsContract.Contacts._ID));
        idCursor.close();
        return id;
    }

    public static void pickContact(SFPage fragment, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        fragment.startActivityForResult(intent, requestCode);
    }


    public static String[] getPhoneNumbers(String id) {

        final String[] projection = {ContactsContract.CommonDataKinds.Phone.NUMBER};
        String selection = ContactsContract.Data.CONTACT_ID + " = " + id;
        final Cursor phoneNumberCursor = SpratAndroidActivity.getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, selection, null, null);

        List<String> phoneNumbers = new ArrayList<>();
        if (phoneNumberCursor.moveToFirst()) {
            int count = 0;
            do {
                int phoneNumerIndex = phoneNumberCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

                if (phoneNumerIndex != -1 && !phoneNumberCursor.isNull(phoneNumerIndex)) {
                    String phoneNumber = phoneNumberCursor.getString(phoneNumerIndex);
                    phoneNumbers.add(phoneNumber);
                }

            } while (phoneNumberCursor.moveToNext());
        }
        phoneNumberCursor.close();

        String[] result = phoneNumbers.toArray(new String[phoneNumbers.size()]);

        return result;
    }

    public static String[] getAddresses(String id) {

        final String[] projection = {ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS};
        String selection = ContactsContract.Data.CONTACT_ID + " = " + id;

        final Cursor addressesCursor = SpratAndroidActivity.getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_URI, projection, selection, null, null);

        List<String> addresses = new ArrayList<>();
        if (addressesCursor.moveToFirst()) {
            do {
                int addressesIndex = addressesCursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS);

                if (addressesIndex != -1 && !addressesCursor.isNull(addressesIndex)) {
                    String address = addressesCursor.getString(addressesIndex);
                    addresses.add(address);
                }

            } while (addressesCursor.moveToNext());
        }
        addressesCursor.close();

        String[] result = addresses.toArray(new String[addresses.size()]);

        return result;
    }

    public static String[] getEmailAddresses(String id) {
        final String[] projection = {ContactsContract.CommonDataKinds.Website.URL};
        String selection = ContactsContract.Data.CONTACT_ID + " = " + id + " AND " + ContactsContract.Contacts.Data.MIMETYPE + " = '" + ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE + "'";


        final Cursor eAddressesCursor = SpratAndroidActivity.getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, projection, selection, null, null);

        List<String> eAddresses = new ArrayList<>();
        if (eAddressesCursor.moveToFirst()) {
            int count = 0;
            do {
                int eAddressesIndex = eAddressesCursor.getColumnIndex(ContactsContract.CommonDataKinds.Website.URL);

                if (eAddressesIndex != -1 && !eAddressesCursor.isNull(eAddressesIndex)) {
                    String address = eAddressesCursor.getString(eAddressesIndex);
                    eAddresses.add(address);
                }

            } while (eAddressesCursor.moveToNext());
        }
        eAddressesCursor.close();

        String[] result = eAddresses.toArray(new String[eAddresses.size()]);

        return result;
    }

    public static ContentProviderOperation addContactStructureName(Uri uri, String nPrefix, String fName, String lName, String mName, String nSuffix) {
        ContentProviderOperation.Builder builder = ContentProviderOperation.newInsert(uri);
        builder.withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0);
        builder.withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
        builder.withValue(ContactsContract.CommonDataKinds.StructuredName.PREFIX, nPrefix);
        builder.withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, fName);
        builder.withValue(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME, lName);
        builder.withValue(ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME, mName);
        builder.withValue(ContactsContract.CommonDataKinds.StructuredName.SUFFIX, nSuffix);

        return builder.build();
    }

    private static String getString(Cursor cursor, int index) {
        if (index != -1) {
            return !cursor.isNull(index) ? cursor.getString(index) : "";
        }
        return "";
    }
}
