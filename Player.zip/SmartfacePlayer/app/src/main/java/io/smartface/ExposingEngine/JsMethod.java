package io.smartface.ExposingEngine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

class JsMethod extends JsAbstractObject {
    private Method actualMethod = null;
    private JsAbstractObject holder = null;

    public JsMethod(Method method) {
        super(method);
        actualMethod = method;
    }

    public JsAbstractObject getProperty(String name) {
        return null;
    }

    public boolean setProperty(String name, Object value) {
        return false;
    }

    public JsAbstractObject invokeMethod(String name, Object[] parameters) throws IllegalAccessException, InvocationTargetException {
        return null;
    }

    public void setHolder(JsAbstractObject holder) {
        this.holder = holder;
    }

    public JsAbstractObject getHolder() {
        return this.holder;
    }
}