package io.smartface.android.sfcore;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.android.utils.LocaleConfigurationUtil;
import io.smartface.plugin.SMFJSObject;


import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import androidx.fragment.app.Fragment;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import java.lang.Exception;

public class SFPage extends Fragment {
    SMFJSObject callbacks;

    public void setCallbacks(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            SMFJSObject successCallback = this.callbacks.getProperty("onCreate");
            successCallback.callAsNativeFunctionNew(successCallback.jsValueRef, null);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onCreateView");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,null);
            return ((View)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onViewCreated");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onCreateOptionsMenu");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{menu});
        } catch(Exception e) {
            e.printStackTrace();
        }
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onConfigurationChanged");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onCreateContextMenu");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{menu});
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onContextItemSelected");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[] {item.getItemId()});
            return ((boolean)result);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onPause() {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onPause");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
        } catch(Exception e) {
            e.printStackTrace();
        }
        super.onPause();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onActivityResult");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{requestCode,resultCode,data});

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /*
    While the Page is attaching its context, we might be need to re-consider the layout direction.
    In some cases, UI Context such as getContext, activity's own instance  & view context directions or any
    settings might be changed by Android's hidden context logic. Encountered by WebView component.
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(LocaleConfigurationUtil.changeConfigurationLocale(context));
    }


    /*
    ToDo: Intercepts the touch events when  page transition animation is on going. Animation End is not correct exactly.
     */
    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {

        try{
            Animation customAnimation = AnimationUtils.loadAnimation(this.getContext(),nextAnim);
            customAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = true;
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = false;
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

            return customAnimation;

        }catch (Resources.NotFoundException e){
            SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = false;

            return null;
        }
    }

    /*
    ToDo: Intercepts the touch events when  page transition animation is on going. Animation End is not correct exactly.
     */
    @Override
    public Animator onCreateAnimator(int transit, boolean enter, int nextAnim) {
        try {

            Animator customAnimation = AnimatorInflater.loadAnimator(this.getContext(), nextAnim);

            customAnimation.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {
                    SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = true;
                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = false;
                }

                @Override
                public void onAnimationCancel(Animator animator) {
                    SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = false;
                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });

            return customAnimation;

        }
        catch (Resources.NotFoundException e){
            SpratAndroidActivity.SFPAGE_ANIMATION_STARTED = false;

            return  null;
        }
    }

}