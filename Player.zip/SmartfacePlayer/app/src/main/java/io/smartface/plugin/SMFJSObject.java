package io.smartface.plugin;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONObject;

import io.smartface.ExposingEngine.ExchangeValue;
import io.smartface.ExposingEngine.JavaJsInterface;

public class SMFJSObject implements Parcelable {
    public ExchangeValue[] params = null;
    public long jsValueRef = 0;

    protected SMFJSObject(Parcel in) {
        jsValueRef = in.readLong();
    }

    public static final Creator<SMFJSObject> CREATOR = new Creator<SMFJSObject>() {
        @Override
        public SMFJSObject createFromParcel(Parcel in) {
            return new SMFJSObject(in);
        }

        @Override
        public SMFJSObject[] newArray(int size) {
            return new SMFJSObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(jsValueRef);
    }

    public enum SMFType {
        Undefined,
        Null,
        Boolean,
        Number,
        String,
        Object
    }

    //create null object
    public SMFJSObject() {
    }

    public SMFJSObject (int val) {
        jsValueRef = makeNumber ( (double) val);
    }

    public SMFJSObject (double val) {
        jsValueRef = makeNumber (val);
    }

    public SMFJSObject (String val) {
        jsValueRef = makeString (val);
    }

    public SMFJSObject (JSONObject val) {
        jsValueRef = makeFromJSONString(val.toString());
    }
    public SMFJSObject (JSONArray val) {
        jsValueRef = makeFromJSONString(val.toString());
    }

    public SMFJSObject (boolean val) {
        jsValueRef = makeBoolean (val);
    }

    public SMFType getType() {
        if (jsValueRef != 0) {
            String val = getType (jsValueRef);
            switch (val) {
                case "Undefined" :
                    return SMFType.Undefined;
                case "Null":
                    return SMFType.Null;
                case "Boolean":
                    return SMFType.Boolean;
                case "Number":
                    return SMFType.Number;
                case "String":
                    return SMFType.String;
                case "Object":
                    return SMFType.Object;
            }
        }

        return SMFType.Null;
    }

    public boolean hasProperty (String propertyName) {
        if (jsValueRef != 0) {
            return hasProperty (jsValueRef, propertyName);
        }

        return false;
    }

    public SMFJSObject getProperty (String propertyName) throws Exception {
        if (jsValueRef != 0) {
            long ajsValueRef = getProperty (jsValueRef, propertyName);
            SMFJSObject ret = new SMFJSObject();
            ret.jsValueRef = ajsValueRef;
            return ret;
        }

        return null;
    }

    public void setProperty (String propertyName, SMFJSObject value) throws Exception {
        if (jsValueRef != 0) {
            setProperty (jsValueRef, propertyName, value.jsValueRef);
        }
    }

    public boolean deleteProperty (String propertyName) throws Exception {
        if (jsValueRef != 0) {
            return deleteProperty (jsValueRef, propertyName);
        }

        return false;
    }

    public SMFJSObject getPropertyAtIndex (int propertyIndex) throws Exception {
        if (jsValueRef != 0) {
            long ajsValueRef = getPropertyAtIndex (jsValueRef, propertyIndex);
            SMFJSObject ret = new SMFJSObject();
            ret.jsValueRef = ajsValueRef;
            return ret;
        }

        return null;
    }

    public void setPropertyAtIndex (int propertyIndex, SMFJSObject value) throws Exception {
        if (jsValueRef != 0) {
            setPropertyAtIndex (jsValueRef, propertyIndex, value.jsValueRef);
        }
    }

    public Object callAsNativeFunctionNew(long jsValueRef, Object[] args) {
        ExchangeValue[] parameters = null;
        if(args != null) {
            int parameterCount = args.length;
            parameters = new ExchangeValue[parameterCount];
            for(int i = 0; i < parameterCount; i++){
                parameters[i] = JavaJsInterface.wrapValue(args[i]);
            }
        }
        ExchangeValue retValue = this.callAsFunctionNew(jsValueRef, parameters);
        if(retValue == null) return null;

        return JavaJsInterface.unwrapValue(retValue);
    }

    //Do we need these and can even support them
    //void* JSObjectGetPrivate(JSObjectRef object);
    //bool JSObjectSetPrivate(JSObjectRef object, void* data);

    public boolean isFunction() {
        if (jsValueRef != 0) {
            return isFunction (jsValueRef);
        }

        return false;
    }

    public boolean isUndefined() {
        if (jsValueRef != 0) {
            return isUndefined (jsValueRef);
        }

        return false;
    }

    public boolean isNull() {
        if (jsValueRef != 0) {
            return isNull (jsValueRef);
        }

        return false;
    }

    public boolean isBoolean() {
        if (jsValueRef != 0) {
            return isBoolean (jsValueRef);
        }

        return false;
    }

    public boolean isNumber() {
        if (jsValueRef != 0) {
            return isNumber (jsValueRef);
        }

        return false;
    }

    public boolean isString() {
        if (jsValueRef != 0) {
            return isString (jsValueRef);
        }

        return false;
    }

    public boolean isObject() {
        if (jsValueRef != 0) {
            return isObject (jsValueRef);
        }

        return false;
    }

    //is this ok? Can we wrap class to an object too..
    public boolean isObjectOfClass (SMFJSObject aClass) {
        if (jsValueRef != 0 && aClass != null && aClass.jsValueRef != 0) {
            return isObjectOfClass (jsValueRef, aClass.jsValueRef);
        }

        return false;
    }

    public boolean isEqual (SMFJSObject value) throws Exception {
        if (jsValueRef != 0 && value != null && value.jsValueRef != 0) {
            return isEqual (jsValueRef, value.jsValueRef);
        }

        return false;
    }

    public boolean isStrictEqual (SMFJSObject value) {
        if (jsValueRef != 0 && value != null && value.jsValueRef != 0) {
            return isStrictEqual (jsValueRef, value.jsValueRef);
        }

        return false;
    }

    //Do we need this and can even support it
    //bool JSValueIsInstanceOfConstructor(JSContextRef ctx, JSValueRef value, JSObjectRef constructor, JSValueRef* exception);


    public SMFJSObject callAsFunction (SMFJSObject thisObject,
                                       SMFJSObject[] arguments) throws Exception {
        if (jsValueRef != 0) {
            SMFJSObject ret = new SMFJSObject();
            long thisValueRef = 0;

            if (thisObject != null) {
                thisValueRef = thisObject.jsValueRef;
            }

            long[] argArr = null;

            if (arguments != null && arguments.length > 0) {
                argArr = new long[arguments.length];

                for (int i = 0; i < arguments.length; i++) {
                    argArr[i] = arguments[i].jsValueRef;
                }
            }

            ret.jsValueRef = callAsFunction (jsValueRef, thisValueRef, argArr);
            return ret;
        }

        return null;
    }

    public SMFJSObject callAsFunction(SMFJSObject thisObject, long[] args) throws Exception {
        if(jsValueRef != 0) {
            SMFJSObject ret = new SMFJSObject();
            long thisValueRef = 0;

            if (thisObject != null) {
                thisValueRef = thisObject.jsValueRef;
            }
            ret.jsValueRef = callAsFunction (jsValueRef, thisValueRef, args);
            return ret;
        }
        return null;
    }

    //Do we need these and can even support them
    //bool JSObjectIsConstructor(JSContextRef ctx, JSObjectRef object);
    //JSObjectRef JSObjectCallAsConstructor(JSContextRef ctx, JSObjectRef object, size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

    public String[] copyPropertyNames() {
        if (jsValueRef != 0) {
            return copyPropertyNames (jsValueRef);
        }

        return null;
    }

    int getPropertyNameArrayLength() {
        if (jsValueRef != 0) {
            return getPropertyNameArrayLength (jsValueRef);
        }

        return 0;
    }

    //Do we need these and can even support them
    //void JSPropertyNameAccumulatorAddName(JSPropertyNameAccumulatorRef accumulator, JSStringRef propertyName);

    public boolean toBoolean() {
        if (jsValueRef != 0) {
            return toBoolean (jsValueRef);
        }

        return false;
    }

    public double toDouble() {
        if (jsValueRef != 0) {
            return toDouble (jsValueRef);
        }

        return 0.0;
    }

    public int toInt() {
        if (jsValueRef != 0) {
            return toInt (jsValueRef);
        }

        return 0;
    }

    public String toString() {
        if (jsValueRef != 0) {
            return toString (jsValueRef);
        }

        return null;
    }

    /*public void protect()
    {
        if(jsValueRef != 0)
        {
            protect(jsValueRef);
        }
    }*/

    /*public void unprotect()
    {
        if(jsValueRef != 0)
        {
            unprotect(jsValueRef);
        }
    }*/

    @Override
    protected void finalize() throws Throwable {
        try {
            if (jsValueRef != 0) {
//                unprotect (jsValueRef);
                jsValueRef = 0;
            }

        } catch (Throwable t) {
            throw t;

        } finally {
            super.finalize();
        }
    }

    static native void protect (long value);
    static native void unprotect (long value);

    static native long makeNumber (double number);
    static native long makeBoolean (boolean abool);
    static native long makeString (String astring);
    static native long makeFromJSONString (String astring);
    static native String getType (long jsValueRef);
    static native boolean hasProperty (long jsValueRef, String propertyName);
    static native long getProperty (long jsValueRef, String propertyName);
    static native void setProperty (long jsValueRef, String propertyName, long value);
    static native boolean deleteProperty (long jsValueRef, String propertyName);
    static native long getPropertyAtIndex (long jsValueRef, int propertyIndex);
    static native void setPropertyAtIndex (long jsValueRef, int propertyIndex, long value);
    static native boolean isFunction (long jsValueRef);
    static native boolean isUndefined (long jsValueRef);
    static native boolean isNull (long jsValueRef);
    static native boolean isBoolean (long jsValueRef);
    static native boolean isNumber (long jsValueRef);
    static native boolean isString (long jsValueRef);
    static native boolean isObject (long jsValueRef);
    static native boolean isObjectOfClass (long jsValueRef, long classValueRef);
    static native boolean isEqual (long jsValueRef, long value);
    static native boolean isStrictEqual (long jsValueRef, long value);
    static native long callAsFunction (long jsValueRef, long thisObject, long[] arguments);
    // TODO: This function should be private later. 
    // Use callAsNativeFunctionNew instead of callAsFunctionNew
    public native ExchangeValue callAsFunctionNew(long jsValueRef, ExchangeValue[] parameters);
    static native String[] copyPropertyNames (long jsValueRef);
    static native int getPropertyNameArrayLength (long jsValueRef);
    static native boolean toBoolean (long jsValueRef);
    static native double toDouble (long jsValueRef);
    static native int toInt (long jsValueRef);
    static native String toString (long jsValueRef);

    public static native Object getJavaObject(long jsValueRef);
}