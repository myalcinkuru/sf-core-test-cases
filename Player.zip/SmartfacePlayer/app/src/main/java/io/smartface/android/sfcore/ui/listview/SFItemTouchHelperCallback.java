package io.smartface.android.sfcore.ui.listview;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import io.smartface.android.utils.AndroidUnitConverterUtil;
import io.smartface.plugin.SMFJSObject;


@SuppressWarnings("unused")
public class SFItemTouchHelperCallback extends ItemTouchHelper.Callback {

    private boolean enableDragAndDrop = false;
    private boolean enableSwipe = false;
    private boolean longPressDragEnabled = true;
    private SMFJSObject smfOnRowCanMove, smfOnRowCanSwipe,
            smfOnRowSwipe, smfOnRowMove, smfOnRowMoved;
    private boolean isLeftSwiped = false;
    private boolean isRightSwiped = false;
    private SFSwipeItem sfSwipeItem;
    private float rightSpace = AndroidUnitConverterUtil.dpToPixel(16);
    private int dragTo = -1, dragFrom = -1;


    public SFItemTouchHelperCallback(SMFJSObject callbacks) {
        if (callbacks != null) {
            try {
                smfOnRowCanMove = callbacks.getProperty("onRowCanMove");
                smfOnRowCanSwipe = callbacks.getProperty("onRowCanSwipe");
                smfOnRowSwipe = callbacks.getProperty("onRowSwipe");
                smfOnRowMove = callbacks.getProperty("onRowMove");
                smfOnRowMoved = callbacks.getProperty("onRowMoved");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
        int dropFlags = enableDragAndDrop ? ItemTouchHelper.DOWN | ItemTouchHelper.UP : 0,
                swipeFlags = enableSwipe ? swipeDirections(viewHolder) : 0;

        return canItemMove(viewHolder) ? makeMovementFlags(dropFlags, swipeFlags) : 0;
    }

    @Override
    public boolean isLongPressDragEnabled() {
        return longPressDragEnabled;
    }

    public void setLongPressDragEnabled(boolean enabledLongPress) {
        this.longPressDragEnabled = enabledLongPress;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        if (sfSwipeItem != null && sfSwipeItem.smfOnRowSwiped != null)
            sfSwipeItem.smfOnRowSwiped.callAsNativeFunctionNew(sfSwipeItem.smfOnRowSwiped.jsValueRef, new Integer[]{viewHolder.getAdapterPosition()});
    }

    @Override
    public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
        super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);

        if (actionState == ItemTouchHelper.ACTION_STATE_DRAG)
            return;

        // We assume that if the dX is lower than 0 then it is swiping to RIGHT_TO_LEFT else reverse one.
        if (dX < 0) {
            if ((sfSwipeItem = onRowSwipeLeft(viewHolder)) == null)
                return;
            if (sfSwipeItem.image != null)
                drawIconWithText(c, viewHolder.itemView, ItemTouchHelper.LEFT);
            else
                drawWithText(c, viewHolder.itemView, ItemTouchHelper.LEFT);
        } else if (dX > 0) {
            if ((sfSwipeItem = onRowSwipeRight(viewHolder)) == null)
                return;

            if (sfSwipeItem.image != null)
                drawIconWithText(c, viewHolder.itemView, ItemTouchHelper.RIGHT);
            else
                drawWithText(c, viewHolder.itemView, ItemTouchHelper.RIGHT);
        } else if (isRightSwiped || isLeftSwiped) {
            restart();
        }
    }

    public SFSwipeItem onRowSwipeLeft(RecyclerView.ViewHolder viewHolder) {
        if (isLeftSwiped || !isRightSwiped) {
            sfSwipeItem = onRowMove(ItemTouchHelper.LEFT, viewHolder.getAdapterPosition());
            isLeftSwiped = false;
            isRightSwiped = true;
        }
        return sfSwipeItem;
    }

    public SFSwipeItem onRowSwipeRight(RecyclerView.ViewHolder viewHolder) {
        if (isRightSwiped || !isLeftSwiped) {
            sfSwipeItem = onRowMove(ItemTouchHelper.RIGHT, viewHolder.getAdapterPosition());
            isRightSwiped = false;
            isLeftSwiped = true;
        }
        return sfSwipeItem;
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
        boolean result = true;

        if (smfOnRowMove != null) {
            Object resultObj = smfOnRowMove.callAsNativeFunctionNew(smfOnRowMove.jsValueRef, new Integer[]{viewHolder.getAdapterPosition(), target.getAdapterPosition()});
            result = (boolean) resultObj;
        }

        if (result)
            recyclerView.getAdapter().notifyItemMoved(viewHolder.getAdapterPosition(), target.getAdapterPosition());

        return result;
    }

    @Override
    public void onMoved(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, int fromPos, @NonNull RecyclerView.ViewHolder target, int toPos, int x, int y) {
        super.onMoved(recyclerView, viewHolder, fromPos, target, toPos, x, y);
        if(dragFrom == -1)
            dragFrom = fromPos;
        dragTo = toPos;
    }

    @Override
    public void clearView(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
        super.clearView(recyclerView, viewHolder);

        if (smfOnRowMoved != null && dragTo != -1 && dragFrom != -1)
            smfOnRowMoved.callAsNativeFunctionNew(smfOnRowMoved.jsValueRef, new Integer[]{dragFrom, dragTo});
        //To make sure it triggered just after onMoved.
        dragTo = -1;
        dragFrom = -1;
    }

    @Override
    public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder viewHolder) {
        if (sfSwipeItem != null)
            return sfSwipeItem.threshold;
        return super.getSwipeThreshold(viewHolder);
    }

    public void setEnableDragAndDrop(boolean enable) {
        this.enableDragAndDrop = enable;
    }

    public void setEnableSwipe(boolean enable) {
        this.enableSwipe = enable;
    }

    private boolean canItemMove(@NonNull RecyclerView.ViewHolder viewHolder) {
        boolean canItemMove = true;

        if (smfOnRowCanMove != null) {
            Object returnValue = smfOnRowCanMove.callAsNativeFunctionNew(smfOnRowCanMove.jsValueRef, new Integer[]{viewHolder.getAdapterPosition()});
            canItemMove = ((boolean) returnValue);
        }
        return canItemMove;
    }

    private int swipeDirections(@NonNull RecyclerView.ViewHolder viewHolder) {
        int swipeDirection = ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
        if (smfOnRowCanSwipe != null) {
            Object returnValue = smfOnRowCanSwipe.callAsNativeFunctionNew(smfOnRowCanSwipe.jsValueRef, new Integer[]{viewHolder.getAdapterPosition()});
            swipeDirection = ((int) returnValue);
        }
        return swipeDirection;
    }

    private SFSwipeItem onRowMove(int direction, int index) {
        if (smfOnRowSwipe != null) {
            Object result = smfOnRowSwipe.callAsNativeFunctionNew(smfOnRowSwipe.jsValueRef, new Integer[]{direction, index});
            return (SFSwipeItem) result;
        }
        return null;
    }

    public void drawIconWithText(Canvas c, View view, int direction) {
        Bitmap bitmap = sfSwipeItem.image;
        int textSize = sfSwipeItem.fontSize;
        Typeface typeface = sfSwipeItem.font;
        int bgColor = sfSwipeItem.bgColor;
        int textColor = sfSwipeItem.textColor;
        String text = sfSwipeItem.text;
        float[] borderRadius = sfSwipeItem.borderRadius;
        float paddingLeft = sfSwipeItem.padding[0];
        float paddingRight = sfSwipeItem.padding[1];
        float paddingTop = sfSwipeItem.padding[2];
        float paddingBottom = sfSwipeItem.padding[3];

        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setColor(bgColor);

        RectF rectF = new RectF(view.getLeft() + paddingLeft, view.getTop() + paddingTop, view.getRight() - paddingRight, view.getBottom() - paddingBottom);
        Path path = new Path();
        path.addRoundRect(rectF, borderRadius, Path.Direction.CW);
        c.drawPath(path, p);

        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(textColor);
        textPaint.setTextSize(!text.isEmpty() ? AndroidUnitConverterUtil.dpToPixel(textSize) : 0); //Convert to dp AND be sure text is given
        textPaint.setTypeface(typeface);

        int height = bitmap.getHeight();
        int width = bitmap.getWidth();

        float vRight = rectF.right;
        float vTop = rectF.top;
        float vLeft = rectF.left;

        float totalHeight = height + textPaint.getTextSize();
        float halfTotalHeight = totalHeight / 2;
        float halfViewHeight = rectF.height() / 2;
        float wText = textPaint.measureText(text);  //Width of the given text
        float halfWidthText = wText / 2;
        int centerToText = wText > 0 ? width / 2 : 0; //if there no text given then ignore the half of width. The purpose is to give exact center position

        float bitmapStart = direction == ItemTouchHelper.LEFT ?
                vRight - width - rightSpace - halfWidthText + centerToText :
                vLeft + width + rightSpace + halfWidthText - centerToText;
        float bitmapEnd = direction == ItemTouchHelper.LEFT ?
                vRight - rightSpace - halfWidthText + centerToText :
                vLeft + rightSpace + halfWidthText - centerToText;
        float textStart = direction == ItemTouchHelper.LEFT ? vRight - wText - rightSpace : vLeft + rightSpace;

        // To centralize the item equally, top & bottom values are calculated.
        float mTop = vTop + halfViewHeight - halfTotalHeight; // Top calculation of text and bitmap when combined
        float mBottom = vTop + halfViewHeight - halfTotalHeight + totalHeight; // Bottom calculation of text and bitmap when combined

        RectF bitmapRectF = new RectF(
                bitmapStart,
                mTop,
                bitmapEnd,
                mTop + height);

        c.drawText(text,
                textStart,
                mBottom, textPaint);

        c.drawBitmap(bitmap, null, bitmapRectF, textPaint);
    }

    public void drawWithText(Canvas c, View view, int direction) {
        int textSize = sfSwipeItem.fontSize;
        Typeface typeface = sfSwipeItem.font;
        int bgColor = sfSwipeItem.bgColor;
        int textColor = sfSwipeItem.textColor;
        String text = sfSwipeItem.text;
        float[] borderRadius = sfSwipeItem.borderRadius;
        float paddingLeft = sfSwipeItem.padding[0];
        float paddingRight = sfSwipeItem.padding[1];
        float paddingTop = sfSwipeItem.padding[2];
        float paddingBottom = sfSwipeItem.padding[3];

        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setColor(bgColor);

        RectF rectF = new RectF(view.getLeft() + paddingLeft, view.getTop() + paddingTop, view.getRight() - paddingRight, view.getBottom() - paddingBottom);
        Path path = new Path();
        path.addRoundRect(rectF, borderRadius, Path.Direction.CW);
        c.drawPath(path, p);


        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(textColor);
        textPaint.setTextSize(AndroidUnitConverterUtil.dpToPixel(textSize));
        textPaint.setTypeface(typeface);

        float vRight = rectF.right;
        float vLeft = rectF.left;
        float halfViewHeight = rectF.height() / 2;
        float wText = textPaint.measureText(text);  //Width of the given text
        float halfHeightText = textPaint.getTextSize() / 2;
        float textStart = direction == ItemTouchHelper.LEFT ? vRight - wText - rightSpace : vLeft + rightSpace;

        c.drawText(text,
                textStart,
                rectF.top + halfViewHeight + halfHeightText,
                textPaint);
    }

    public void restart() {
        isLeftSwiped = false;
        isRightSwiped = false;
        sfSwipeItem = null;
    }

    public static class SFSwipeItem {
        public Typeface font;
        public Integer fontSize;
        public Integer bgColor;
        public String text;
        public Integer textColor;
        public Bitmap image;
        public SMFJSObject callbacks;
        public float threshold;
        public SMFJSObject smfOnRowSwiped;
        public float[] padding = new float[]{0, 0, 0, 0}; //left, right, top, bottom
        public float[] borderRadius = new float[]{0, 0, 0, 0, 0, 0, 0, 0};

        public void setSwipeItemProps(Typeface font, int fontSize, int bgColor, String text, int textColor, Bitmap image, float threshold, SMFJSObject callbacks) {
            this.font = font;
            this.fontSize = fontSize;
            this.bgColor = bgColor;
            this.text = text;
            this.textColor = textColor;
            this.image = image;
            this.threshold = threshold;
            this.callbacks = callbacks;
            try {
                smfOnRowSwiped = callbacks.getProperty("onPress");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void setSwipeItemDimensions(float[] padding, float[] borderRadius) {
            this.borderRadius = borderRadius;
            this.padding = padding;
        }


        public void resetVariables() {
            this.font = null;
            this.fontSize = null;
            this.bgColor = null;
            this.text = null;
            this.textColor = null;
            this.image = null;
            this.callbacks = null;
            this.smfOnRowSwiped = null;
            this.threshold = 0.5f;
            this.borderRadius = new float[]{0, 0, 0, 0, 0, 0, 0, 0};
            this.padding = new float[]{0, 0, 0, 0};
        }
    }
}
