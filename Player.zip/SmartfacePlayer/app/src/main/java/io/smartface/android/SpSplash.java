package io.smartface.android;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.View;

public class SpSplash extends View {

    private SpratAndroidActivity sprat;
    private Bitmap bitmap;
    private int color;
    private Paint p;
    public SpSplash (SpratAndroidActivity sprat) {
        super (sprat);
        p = new Paint();
        p.setStyle (Style.FILL);
        color = Color.WHITE;
        this.sprat = sprat;
    }
    public void setSplash (String source, int color) {
        color = ( (color >> 16) & 0xff) | (color & 0xff00) | ( (color << 16) & 0xff0000) ;
        this.color = 0xff000000 | color;
        bitmap = sprat.getBitmap (source);

        try {
            invalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onDraw (Canvas canvas) {
        p.setColor (this.color);
        canvas.drawRect (0, 0, 400, 400, p);
        canvas.drawRect (canvas.getClipBounds(), p);

        if (bitmap != null) {
            canvas.drawBitmap (bitmap, getWidth() / 2 - bitmap.getWidth() / 2,
                               getHeight() / 2 - bitmap.getHeight() / 2, p);
        }
    }
}
