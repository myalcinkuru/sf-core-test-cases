package io.smartface.android.utils;

import androidx.appcompat.app.AppCompatActivity;
import io.smartface.android.SpratAndroidActivity;

public class AndroidUnitConverterUtil {
    final static float density = SpratAndroidActivity.getActivity().getResources().getDisplayMetrics().density;


    public static int pixelToDp(float pixel){
        return Math.round(pixel / density);
    }

    public static int dpToPixel(float dp){
        return Math.round(dp * density);
    }
}
