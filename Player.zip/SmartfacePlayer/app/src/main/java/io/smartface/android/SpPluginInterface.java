package io.smartface.android;

import android.content.Intent;

public interface SpPluginInterface {
    public void initPlugins (long jsContext, long envMap);
    public void onActivityResult (int requestCode, int resultCode, Intent data);
}
