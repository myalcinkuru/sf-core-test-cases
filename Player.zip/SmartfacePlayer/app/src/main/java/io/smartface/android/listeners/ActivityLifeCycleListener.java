package io.smartface.android.listeners;

import android.content.res.Configuration;
import android.content.Intent;

/**
 * ActivityLifeCycleListener is an interface for understand Smartface Activity's life cycle.
 * This class implemented for supporting lifecycle events on Smartface Native Framework and giving lifecycle
 * to the Smartface Native Framework Plugin Developer
 *
 * Created by metehantoksoy on 3/28/17.
 *
 * @see <a href="https://developer.android.com/guide/components/activities/activity-lifecycle.html">The Activity Lifecycle on Android Developer</a>
 * @see <a href="https://developer.android.com/training/permissions/requesting.html">Requesting Permissions at Run Time</a>
 * @see <a href="http://ref.smartface.io/#!/api/Application">Nativeface API Docs - Application</a>
 * @see
 */
public interface ActivityLifeCycleListener {
    void onCreate();
    void onStart();
    void onResume();
    void onPause();
    void onStop();
    void onDestroy();
    void onConfigurationChanged(Configuration newConfig);
    void onRequestPermissionsResult(int requestCode, String permissions, int grantResults);
    void onActivityResult(int requestCode, int resultCode, Intent data);
    boolean dispatchTouchEvent(int actionType, float x, float y);
}
