package io.smartface.android.sfcore.ui.listview;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;


public class SFLinearLayoutManager extends LinearLayoutManager {
    public boolean isScrollHorizontally = true;
    public boolean isScrollVerically = true;

    public SFLinearLayoutManager(Context context) {
        super(context);
    }

    public void setCanScrollHorizontally(boolean scrollHorizontally){
        isScrollHorizontally = scrollHorizontally;
    }
    public void setCanScrollVerically(boolean scrollVerically){
        isScrollVerically = scrollVerically;
    }

    @Override
    public boolean canScrollHorizontally() {
        if(isScrollHorizontally)
            return super.canScrollHorizontally();
        else
            return isScrollHorizontally;
    }

    @Override
    public boolean canScrollVertically() {
        if(isScrollVerically)
        return super.canScrollVertically();
        else
            return  isScrollVerically;
    }
}
