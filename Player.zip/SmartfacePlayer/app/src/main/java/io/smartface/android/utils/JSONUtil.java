package io.smartface.android.utils;

import android.os.Bundle;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by metehantoksoy on 7/4/17.
 */
public class JSONUtil {
    public static String bundleToJson(Bundle extras) {
        JSONObject object = new JSONObject();
        for (String key : extras.keySet()) {
            try {
                object.put(key, extras.get(key));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return object.toString();
    }
}
