package io.smartface.android.sfcore.global;

import android.os.Handler;

public class SFHandler {
    public static Handler handler = null;

    public static Handler getHandler() {
        if(handler == null) {
            handler = new Handler();
        }
        return handler;
    }

    public static void clearAllTimer() {
        if(handler == null) 
            return;
        handler.removeCallbacksAndMessages(null);
    }
}
