package io.smartface.android.sfcore.ui.webview;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;

import io.smartface.plugin.SMFJSObject;

/*
ToDo: These wrapper class is intended to prevent  exceptions related to JS layer. Consider when getDeclatedMethods exceptions are handled.
 */
public class SFWebView extends WebView {
    SMFJSObject callbacks = null;
    WebViewClient mWebViewClient;

    public SFWebView(Context context, SMFJSObject callbacks, SMFJSObject chromeCallbacks) {
        super(context);
        this.callbacks = callbacks;
        this.setWebViewClient(mWebViewClient = new SFWebViewClient());

        WebSettings settings = this.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setLoadsImagesAutomatically(true);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        this.setWebChromeClient(new SFWebChromeClient(chromeCallbacks));
    }

    public WebViewClient getInstance(){
        return mWebViewClient;
    }

    public void setUserAgent(String agent) {
        this.getSettings().setUserAgentString(agent);
    }

    public String getUserAgent() {
        return this.getSettings().getUserAgentString();
    }

    public void setScrollBarEnabled (boolean enabled) {
        this.setHorizontalScrollBarEnabled(enabled);
        this.setVerticalScrollBarEnabled(enabled);
    }

    public void setZoomEnabled (boolean enabled) {
        this.getSettings().setBuiltInZoomControls(enabled);
    }

    public boolean getZoomEnabled (boolean enabled) {
        return this.getSettings().getBuiltInZoomControls();
    }

    private class SFWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("onPageStarted");
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{url});
            } catch(Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("onPageFinished");
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{url});
            } catch(Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("shouldOverrideUrlLoading");
                Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{url});
                return ((boolean)result);
            } catch(Exception e) {
                e.printStackTrace();
            }
            return true;
        }

        @Override
        @TargetApi(21)
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("shouldOverrideUrlLoading");
                Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{request.getUrl().toString()});
                return ((boolean)result);
            } catch(Exception e) {
                e.printStackTrace();
            }
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode,
                                    String description, String failingUrl) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("onReceivedError");
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{errorCode,description,failingUrl});

            } catch(Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        @TargetApi(23)
        public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
            try {
                SMFJSObject jsCallback = callbacks.getProperty("onReceivedError");

                String failingUrl = String.valueOf(request.getUrl());
                int errorCode = error.getErrorCode();
                String description = error.getDescription().toString();
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{errorCode,description,failingUrl});
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
}
