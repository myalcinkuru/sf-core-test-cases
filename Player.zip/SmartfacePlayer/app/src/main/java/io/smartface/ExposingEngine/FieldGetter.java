/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.smartface.ExposingEngine;

import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author halit
 */
public class FieldGetter extends PropertyGetter {

    public FieldGetter(Field field) {
        super(field);
    }

    public Object get(Object holder) {
        try {
            return ((Field)propertyObject).get(holder);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(FieldGetter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(FieldGetter.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
