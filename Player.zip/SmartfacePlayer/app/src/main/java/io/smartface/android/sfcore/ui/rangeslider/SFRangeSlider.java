package io.smartface.android.sfcore.ui.rangeslider;

import android.content.Context;
import android.graphics.Color;


import com.smartface.materialrangebar.RangeBar;

import io.smartface.plugin.SMFJSObject;

@SuppressWarnings("unused")
public class SFRangeSlider extends RangeBar {
    private SMFJSObject onValueChangeCallback, smfOnValueChanged;

    public SFRangeSlider(Context context) {
        super(context, null);

        //Defaults: makes transparent unintended behavior
        this.setDrawTicks(false);
        this.setPinColor(Color.TRANSPARENT);
        this.setPinTextColor(Color.TRANSPARENT);
        this.setDrawTicks(false);
        this.setBarRounded(true);
        this.setSelectorSize(47);
    }

    public void setOnValueChange(SMFJSObject callbacks) {
        onValueChangeCallback = callbacks;
        try {
            smfOnValueChanged = onValueChangeCallback.getProperty("onValueChange");
            this.setOnRangeBarChangeListener(new OnRangeBarChangeListener() {
                @Override
                public void onRangeChangeListener(RangeBar rangeBar, int leftPinIndex, int rightPinIndex, String leftPinValue, String rightPinValue) {
                    smfOnValueChanged.callAsNativeFunctionNew(smfOnValueChanged.jsValueRef, new Integer[] {Integer.valueOf(leftPinValue), Integer.valueOf(rightPinValue)});
                }
                @Override
                public void onTouchStarted(RangeBar rangeBar) {
                }
                @Override
                public void onTouchEnded(RangeBar rangeBar) {
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}