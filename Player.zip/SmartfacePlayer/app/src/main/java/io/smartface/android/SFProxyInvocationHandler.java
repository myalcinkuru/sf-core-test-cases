package io.smartface.android;

import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import io.smartface.ExposingEngine.ExchangeValue;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.JsObjectCollection;
import io.smartface.ExposingEngine.JsObject;
import io.smartface.plugin.SMFJSObject;

public class SFProxyInvocationHandler implements InvocationHandler {

    private SMFJSObject jscallbacksImpl;

    public SFProxyInvocationHandler(SMFJSObject jscallbacksImpl) {
        this.jscallbacksImpl = jscallbacksImpl;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("toString")) {
            return handleMethodInJava(method, args);
        }

        SMFJSObject callback = jscallbacksImpl.getProperty(method.getName());
        if (callback.jsValueRef != 0) { // has the method in javascript side
            return handleMethodInJS(method, args, callback);
        } else {
            return handleMethodInJava(method, args);
        }
    }

    private Object handleMethodInJS(Method method, Object[] args, SMFJSObject callback) throws Exception {
        ExchangeValue[] callbackArgs = new ExchangeValue[args != null? args.length:0];
        if(args != null) {
            for (int i = 0; i < args.length; i++) {
                callbackArgs[i] = JavaJsInterface.wrapValue(args[i]);
            }
        }

        ExchangeValue ret = callback.callAsFunctionNew(callback.jsValueRef, callbackArgs);

        Object result = JavaJsInterface.unwrapValue(ret);
        return result;
    }

    private Object handleMethodInJava(Method method, Object[] args) throws InvocationTargetException, IllegalAccessException {
        if (method.getName().equals("equals")) {
            return args[0].hashCode() == this.hashCode();
        } else {
            Method[] classMethods = this.getClass().getMethods();
            for(Method classMethod : classMethods){
                if(classMethod.getName().equals(method.getName())){
                    return method.invoke(this, args);
                }
            }
            return null;
        }
    }

}
