package io.smartface.ExposingEngine;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *  This class is representation of Java class with caching mechanism. It has methods for
 *  getting/setting property and creating new instance of represented class.
 */
class JsClass extends JsAbstractObject {
    private Class<?> actualClass;
    private JsClass superClass = null;

    private HashMap<String, HashMap<Integer, Method>> staticMethodCache = new HashMap<>();
    private HashMap<String, HashMap<Integer, Method>> methodCache = new HashMap<>();

    private HashMap<String, FastArray> staticNamedMethodCache = new HashMap<>();
    private HashMap<String, FastArray> namedMethodCache = new HashMap<>();

    private HashMap<Integer, Constructor<?>> constructorCache = new HashMap<>();

    private HashMap<String, PropertyGetter> staticPropertyGetterCache = new HashMap<>();
    private HashMap<String, PropertySetter> staticPropertySetterCache = new HashMap<>();
    private HashMap<String, PropertyGetter> propertyGetterCache = new HashMap<>();
    private HashMap<String, PropertySetter> propertySetterCache = new HashMap<>();

    /**
     *  Constructor
     *
     *  @param toRepresent  Actual class to be represented as JavaScript object
     */
    public JsClass(Class<?> toRepresent) {
        super(toRepresent);
        actualClass = toRepresent;
        if (actualClass.getSuperclass() != null) {
            superClass = JsClassManager.GetClass(actualClass.getSuperclass().getName());
        }
    }

    /**
     *  This method makes a number of queries to get
     */
    public JsAbstractObject getProperty(String name) {
        waitUntilReady();

        PropertyGetter fromPropertyCache = staticPropertyGetterCache.get(name);
        if (fromPropertyCache != null) {
            return wrapObjectIntoJsAbstractObject(fromPropertyCache.get(null));
        }

        JsClass jsClass = JsClassManager.GetClass("java.lang.Class");
        JsAbstractObject result = jsClass.getInstanceProperty(this, name);

        if (result != null)
            return result;
        else if (superClass != null)
            return superClass.getProperty(name);
        else
            return null;
    }

    public JsAbstractObject getInstanceProperty(JsAbstractObject instance, String name) {
        waitUntilReady();

        PropertyGetter propertyGetter = propertyGetterCache.get(name);

        if (propertyGetter != null) {
            return wrapObjectIntoJsAbstractObject(propertyGetter.get(instance.getJavaObject()), instance);
        }

        if (superClass != null) {
            return superClass.getInstanceProperty(instance, name);
        }

        return null;
    }

    public boolean setProperty(String name, Object value) {
        return staticPropertySetterCache.containsKey(name) ?
                staticPropertySetterCache.get(name).set(null, value) : false;
    }

    public boolean setInstanceProperty(JsAbstractObject instance, String name, Object value) {
        if (propertySetterCache.containsKey(name))
            return propertySetterCache.get(name).set(instance.getJavaObject(), value);
        else if (superClass != null)
            return superClass.setInstanceProperty(instance, name, value);
        else
            return false;

    }

    public JsAbstractObject invokeMethod(String name, Object[] parametersAsArray) throws Throwable {
        waitUntilReady();

        Method method = getStaticMethod(name, parametersAsArray);
        if (method != null) {
            Object result = method.invoke(getJavaObject(), parametersAsArray);
            return wrapObjectIntoJsAbstractObject(result);
        }

        JsClass jsClass = JsClassManager.GetClass("java.lang.Class");
        method = jsClass.getMethod(name, parametersAsArray);
        if (method != null) {
            try {
                Object result = method.invoke(getJavaObject(), parametersAsArray);
                return wrapObjectIntoJsAbstractObject(result);
            } catch (InvocationTargetException exception) {
                throw exception.getTargetException();
            }
        } else {
            throw new NoSuchMethodException("Method " + name + " with " + parametersAsArray.length + " parameters couldn't found in class: " + this.toString());
        }
    }

    public JsAbstractObject createInstance(Object[] parametersAsArray) throws Throwable {
        waitUntilReady();

        Constructor<?> constructor = getConstructor(parametersAsArray);
        if (constructor != null) {
            try {
                Object object = constructor.newInstance(parametersAsArray);
                if (object != null) {
                    return wrapObjectIntoJsAbstractObject(object);
                }
            } catch (InvocationTargetException exception) {
                throw exception.getTargetException();
            }
        }

        return null;
    }

    public Method getMethod(String name, Object[] parameters) {
        waitUntilReady();

        Integer cacheString = createParameterTypesCacheInteger(parameters);

        HashMap<Integer, Method> methodsCachedByParameters = methodCache.get(name);
        if (methodsCachedByParameters != null) {
            Method method = methodsCachedByParameters.get(cacheString);
            if (method != null) {
                return method;
            }
        }

        FastArray methodsArray = namedMethodCache.get(name);
        if (methodsArray != null) {
            Method matchedMethod = null;
            for (int i = 0; i < methodsArray.size(); ++i) {
                Method method = (Method) methodsArray.get(i);
                Class[] parameterClasses = method.getParameterTypes();
                if (parameters.length != parameterClasses.length) continue;

                if(ObjectsExactlyMatch(parameterClasses, parameters)) {
                    HashMap<Integer, Method> map = methodCache.get(name);
                    if (map == null) {
                        map = new HashMap<>();
                        methodCache.put(name, map);
                    }
                    map.put(cacheString, method);
                    return method;
                }

                if (AreObjectsAssignable(parameterClasses, parameters)) {
                    HashMap<Integer, Method> map = methodCache.get(name);
                    if (map == null) {
                        map = new HashMap<>();
                        methodCache.put(name, map);
                    }
                    map.put(cacheString, method);
                    matchedMethod = method;
                }
            }
            if(matchedMethod != null) {
                return matchedMethod;
            }
        }

        return superClass != null ? superClass.getMethod(name, parameters) : null;
    }

    public Method getStaticMethod(String name, Object[] parameters) {
        waitUntilReady();

        Integer cacheString = createParameterTypesCacheInteger(parameters);

        HashMap<Integer, Method> methodsCachedByParameters = staticMethodCache.get(name);
        if (methodsCachedByParameters != null) {
            Method method = methodsCachedByParameters.get(cacheString);
            if (method != null) return method;
        }

        FastArray methodsArray = staticNamedMethodCache.get(name);
        if (methodsArray != null) {
            Method matchedMethod = null;
            for (int i = 0; i < methodsArray.size(); ++i) {
                Method method = (Method) methodsArray.get(i);
                Class[] parameterClasses = method.getParameterTypes();
                if (parameters.length != parameterClasses.length) continue;

                if(ObjectsExactlyMatch(parameterClasses, parameters)) {
                    HashMap<Integer, Method> map = staticMethodCache.get(name);
                    if (map == null) {
                        map = new HashMap<>();
                        staticMethodCache.put(name, map);
                    }
                    map.put(cacheString, method);
                    return method;
                }
                if (AreObjectsAssignable(parameterClasses, parameters)) {
                    HashMap<Integer, Method> map = staticMethodCache.get(name);
                    if (map == null) {
                        map = new HashMap<>();
                        staticMethodCache.put(name, map);
                    }
                    map.put(cacheString, method);
                    matchedMethod = method;
                }
            }
            if(matchedMethod != null) {
                return matchedMethod;
            }
        }

        if (superClass != null) {
            return superClass.getStaticMethod(name, parameters);
        }

        return null;
    }

    private Constructor<?>[] constructors = null;
    public Constructor<?> getConstructor(Object[] parameters) {
        waitUntilReady();

        Integer cacheString = createParameterTypesCacheInteger(parameters);

        Constructor constructorFromCache = constructorCache.get(cacheString);
        if (constructorFromCache != null) {
            return constructorFromCache;
        }

        if (constructors == null) {
            constructors = actualClass.getConstructors();
        }

        Constructor matchedConstructor = null;
        for (Constructor<?> constructor : constructors) {
            Class[] parameterClasses = constructor.getParameterTypes();
            if (parameters.length != parameterClasses.length) continue;
            if(ObjectsExactlyMatch(parameterClasses, parameters)) {
                constructorCache.put(cacheString, constructor);
                return constructor;
            }
            if (AreObjectsAssignable(parameterClasses, parameters)) {
                constructorCache.put(cacheString, constructor);
                matchedConstructor = constructor;
            }
        }
        if(matchedConstructor != null) {
            return matchedConstructor;
        }

        return null;
    }

    private static boolean ObjectsExactlyMatch(Class[] classes, Object[] objects) {
        for (int i = 0; i < classes.length; ++i) {
            if (objects[i] == null) {
                if (classes[i].isPrimitive()) {
                    return false;
                }
                continue;
            }

            if (classes[i].isArray() && objects[i].getClass().isArray()
                    && checkExactlyMatch(classes[i].getComponentType(), objects[i].getClass().getComponentType())) {
                continue;
            }

            if (!checkExactlyMatch(classes[i], objects[i].getClass())) {
                return false;
            }
        }

        return true;
    }

    private static boolean AreObjectsAssignable(Class[] classes, Object[] objects) {
        for (int i = 0; i < classes.length; ++i) {
            if (objects[i] == null) {
                if (classes[i].isPrimitive()) {
                    return false;
                }
                continue;
            }

            if (checkPrimitiveTypesAssignable(classes[i], objects[i].getClass())) {
                continue;
            }

            if (classes[i].isArray() && objects[i].getClass().isArray()
                    && checkPrimitiveTypesAssignable(classes[i].getComponentType(), objects[i].getClass().getComponentType())) {
                continue;
            }

            if (!classes[i].isAssignableFrom(objects[i].getClass())) {
                return false;
            }
        }

        return true;
    }

    private static HashMap<Class<?>, ArrayList<Class<?>>> compatibilityList;
    static {
        compatibilityList = new HashMap<>();

        ArrayList<Class<?>> classes = new ArrayList();
        classes.add(Integer.class);
        classes.add(Short.class);
        classes.add(Byte.class);
        compatibilityList.put(int.class, classes);

        classes = new ArrayList();
        classes.add(Integer.class);
        classes.add(Short.class);
        classes.add(Byte.class);
        classes.add(Float.class);
        classes.add(Double.class);
        classes.add(Long.class);
        compatibilityList.put(double.class, classes);

        classes = new ArrayList();
        classes.add(Integer.class);
        classes.add(Short.class);
        classes.add(Byte.class);
        classes.add(Float.class);
        classes.add(Long.class);
        compatibilityList.put(float.class, classes);

        classes = new ArrayList();
        classes.add(Integer.class);
        classes.add(Short.class);
        classes.add(Byte.class);
        classes.add(Long.class);
        compatibilityList.put(long.class, classes);

        classes = new ArrayList();
        classes.add(Short.class);
        classes.add(Byte.class);
        compatibilityList.put(short.class, classes);

        classes = new ArrayList();
        classes.add(Boolean.class);
        compatibilityList.put(boolean.class, classes);

        classes = new ArrayList();
        classes.add(Byte.class);
        compatibilityList.put(byte.class, classes);

        classes = new ArrayList();
        classes.add(Character.class);
        compatibilityList.put(char.class, classes);
    }

    private static boolean checkExactlyMatch(Class clazz, Class objectClass) {
        return (clazz.equals(objectClass));
    }

    private static boolean checkPrimitiveTypesAssignable(Class clazz, Class objectClass) {
        ArrayList compatibleList = compatibilityList.get(clazz);
        if (compatibleList != null) {
            return compatibleList.contains(objectClass);
        }

        return false;
    }

    private String createParameterTypesCacheString(Object[] parameters) {
        String cacheString = "C_";
        for (Object parameter : parameters) {
            cacheString += parameter == null ? "null" : parameter.getClass().getName();
        }
        return cacheString;
    }

    private Integer createParameterTypesCacheInteger(Object[] parameters) {
        int result = 0;
        for (Object parameter : parameters) {
            result += parameter == null ? 0 : parameter.getClass().hashCode();
        }
        return result;
    }

    public void crawlClass() throws Exception {
        for (Method method : actualClass.getDeclaredMethods()) {
            if (!Modifier.isPublic(method.getModifiers())) {
                continue;
            }

            if (Modifier.isStatic(method.getModifiers())) {
                if (!staticNamedMethodCache.containsKey(method.getName())) {
                    staticNamedMethodCache.put(method.getName(), new FastArray(25));
                    staticPropertyGetterCache.put(method.getName(), new PropertyGetter(method));
                }
                staticNamedMethodCache.get(method.getName()).add(method);
            } else {
                if (!namedMethodCache.containsKey(method.getName())) {
                    FastArray cache = new FastArray(25);
                    cache.add(method);
                    namedMethodCache.put(method.getName(), cache);
                    propertyGetterCache.put(method.getName(), new PropertyGetter(method));
                } else {
                    namedMethodCache.get(method.getName()).add(method);
                }
            }
        }

        for (Class<?> innerClass : actualClass.getDeclaredClasses()) {
            JsClass jsInnerClass = JsClassManager.GetClass(innerClass);
            staticPropertyGetterCache.put(innerClass.getSimpleName(), new PropertyGetter(jsInnerClass));
        }

        for (Field field : actualClass.getDeclaredFields()) {
            if (!Modifier.isPublic(field.getModifiers())) {
                continue;
            }

            if (Modifier.isStatic(field.getModifiers())) {
                staticPropertyGetterCache.put(field.getName(), new FieldGetter(field));
                staticPropertySetterCache.put(field.getName(), new FieldSetter(field));
            } else {
                propertyGetterCache.put(field.getName(), new FieldGetter(field));
                propertySetterCache.put(field.getName(), new FieldSetter(field));
            }
        }
    }
}