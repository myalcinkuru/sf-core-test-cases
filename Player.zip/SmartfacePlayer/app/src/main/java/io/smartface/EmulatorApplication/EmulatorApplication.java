package io.smartface.EmulatorApplication;

import androidx.multidex.MultiDexApplication;

/**
 * Created by nosaiba on 03/09/16.
 */
public class EmulatorApplication extends MultiDexApplication {
    @Override public void onCreate() {
        super.onCreate();
    }
}