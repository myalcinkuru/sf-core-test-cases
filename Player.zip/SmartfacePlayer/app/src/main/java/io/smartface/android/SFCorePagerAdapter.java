package io.smartface.android;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import io.smartface.plugin.SMFJSObject;

public class SFCorePagerAdapter extends FragmentStatePagerAdapter {
    SMFJSObject callbacks;

    public SFCorePagerAdapter(FragmentManager fragmentManager, SMFJSObject callbacks) {
        super(fragmentManager);
        this.callbacks = callbacks;
    }

    @Override
    public Fragment getItem(int position) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getItem");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{position});
            return ((Fragment)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // This method causes duplicate exception in javassist
    // therefore, this class could not be generated on sf-core.
    @Override
    public int getCount() {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("getCount");
            Object result = jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, null);
            return ((int)result);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}