package io.smartface.android.sfcore.device.documentpicker;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.android.utils.FileUtil;

public class SFDocumentPicker {

    public static void pick(Fragment page, String[] types, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        if(types.length > 0)
            intent.putExtra(Intent.EXTRA_MIME_TYPES, types);
        intent = intent.createChooser(intent, null);

        page.startActivityForResult(intent, requestCode, Bundle.EMPTY);
    }

    public static String getFilePathFromUri(Uri uri) throws IOException {
        String fileName = getFileName(uri);
        File file = new File(SpratAndroidActivity.getActivity().getExternalCacheDir(), fileName);
        file.createNewFile();
        try (OutputStream outputStream = new FileOutputStream(file);
             InputStream inputStream = SpratAndroidActivity.getActivity().getContentResolver().openInputStream(uri)) {
            FileUtil.copyStream(inputStream, outputStream);
            outputStream.flush();
        }
        return file.getAbsolutePath();
    }

    public static String getFileName(Uri uri) {
        String fileName = getFileNameFromCursor(uri);
        if (fileName == null) {
            String fileExtension = getFileExtension(uri);
            fileName = "temp_file" + (fileExtension != null ? "." + fileExtension : "");
        } else if (!fileName.contains(".")) {
            String fileExtension = getFileExtension(uri);
            fileName = fileName + "." + fileExtension;
        }
        return fileName;
    }

    public static String getFileNameFromCursor(Uri uri) {
        Cursor fileCursor = SpratAndroidActivity.getActivity().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
        String fileName = null;
        if (fileCursor != null && fileCursor.moveToFirst()) {
            int cIndex = fileCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (cIndex != -1) {
                fileName = fileCursor.getString(cIndex);
            }
        }
        return fileName;
    }

    public static String getFileExtension(Uri uri) {
        String fileType = SpratAndroidActivity.getActivity().getContentResolver().getType(uri);
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(fileType);
    }
}
