package io.smartface.android.utils;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;

import java.util.UUID;

import io.smartface.android.SpratAndroidActivity;

/**
 * Created by metehantoksoy on 3/13/17. DeviceUtil developed for making device
 * operations.
 */
public class DeviceUtil {
    public static String getDeviceId(Context context) {
        try {
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                return getSecureAndroidID(context);
            }

            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            boolean permissionGranted = SpratAndroidActivity.getInstance().checkPermission__N("READ_PHONE_STATE");
            if ((telephonyManager != null) && permissionGranted)
                return telephonyManager.getDeviceId();

        } catch (SecurityException e) {
            return "";
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    public static String getSecureAndroidID(Context context) {
        // TODO: Secure.getString is not recommended
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }
}
