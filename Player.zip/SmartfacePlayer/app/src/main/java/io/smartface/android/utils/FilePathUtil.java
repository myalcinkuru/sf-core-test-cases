package io.smartface.android.utils;

import io.smartface.android.SpratAndroidActivity;

/**
 * Created by metehantoksoy on 10/21/16.
 */

public class FilePathUtil {
    /** Processes assets folder on emulator. Assets folder's full path is:
     *  /storage/emulated/0/Android/data/io.smartface.SmartfaceDemo/cache/assets/
     * @return emulator assets folder path.
     */
    public static String getEmulatorAssetsPath(){
        return SpratAndroidActivity.getInstance().getUnsecureDbPath__N() + "/assets/";
    }

    /** Getter for application saving folder.
     * @TODO Discuss this tmp folder. It deleted every launch
     * /storage/emulated/0/Android/data/io.smartface.SmartfaceDemo/cache/_tmp/
     * @return application saving path.
     */
    public static String getFileSavingPath(){
        return SpratAndroidActivity.getInstance().getUnsecureDbPath__N()+"/_tmp/";
    }

    /**
     * Getter for application RAU folder
     * /data/data/$PACKAGE_NAME$/files/
     * @return application RAU path
     */
    public static String getRAUAssetsPath(){
        return SpratAndroidActivity.getInstance().getFilesDir().getAbsolutePath()+"/system/rau/assets/";
    }
}
