package io.smartface.android.sfcore.ui.textview;

import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.View;

import io.smartface.plugin.SMFJSObject;
import io.smartface.ExposingEngine.JavaJsInterface;
import io.smartface.ExposingEngine.ExchangeValue;

public class SFClickableSpan extends ClickableSpan {
    SMFJSObject callbacks = null;
    public SFClickableSpan(SMFJSObject callbacks) {
        super();
        this.callbacks = callbacks;
    }

    @Override
    public void onClick(View v) {
        try {
            SMFJSObject successCallback = this.callbacks.getProperty("onClick");
            successCallback.callAsNativeFunctionNew(successCallback.jsValueRef, null);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateDrawState(TextPaint textPaint) {
        try {
            SMFJSObject successCallback = this.callbacks.getProperty("updateDrawState");
            successCallback.callAsNativeFunctionNew(successCallback.jsValueRef,new Object[]{textPaint});
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}