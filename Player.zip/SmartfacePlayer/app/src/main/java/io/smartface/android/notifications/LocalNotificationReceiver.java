package io.smartface.android.notifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;

import io.smartface.android.listeners.NotificationListener;
import io.smartface.android.utils.JSONUtil;

/**
 * LocalNotificationReceiver is a class that present all notifications
 * (remote or local).
 *
 * Remote notifications created by
 * {@link FCMListenerService}
 *
 * Local notifications created by nf-core/global/notifications#present or
 * nf-core/global/notifications#schedule
 */
public class LocalNotificationReceiver extends BroadcastReceiver {
    // @TODO Notification_ID must be integer key - value but due to AND-2702 we are using string
    public static String NOTIFICATION_ID = "id";
    public static String NOTIFICATION_ISREMOTE= "isRemote";
    public static String NOTIFICATION_OBJECT = "notification";
    public static String NOTIFICATION_JSON= "NOTIFICATION_JSON";
    public static String NOTIFICATION_CLICKED = "SF_NOTIFICATION_CLICKED";
    private static ArrayList<NotificationListener> listeners = new ArrayList<>();

    @Override
    public void onReceive (Context context, Intent intent) {
        if (intent != null && intent.getExtras() != null) {
            boolean notificationIsRemote = intent.getBooleanExtra(NOTIFICATION_ISREMOTE, false);
            int notificationID = Integer.parseInt(intent.getStringExtra(NOTIFICATION_ID));
            Notification notification = intent.getParcelableExtra(NOTIFICATION_OBJECT);
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(notificationID , notification);

            if(!notificationIsRemote){
                for (NotificationListener listener : listeners) {
                    listener.onLocalNotificationReceived(JSONUtil.bundleToJson(intent.getExtras()));
                }
            }
        }
    }

    public static void registerRemoteNotificationListener(NotificationListener listener){
        listeners.add(listener);
    }
    public static void unregisterRemoteNotificationListener(NotificationListener listener){
        if(listeners.contains(listener)){
            listeners.remove(listener);
        }
    }
}