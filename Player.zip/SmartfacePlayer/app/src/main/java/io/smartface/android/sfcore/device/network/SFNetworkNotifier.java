package io.smartface.android.sfcore.device.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;

public class SFNetworkNotifier extends BroadcastReceiver {
    SMFJSObject callbacks;
    ConnectivityManager mConnectionManager;
    IntentFilter mIntentFilter;
    Context mContext;
    final int NO_CONNECTIVITY = -1;

    public SFNetworkNotifier(SMFJSObject callbacks) {
        this.callbacks = callbacks;
        mConnectionManager = (ConnectivityManager) SpratAndroidActivity.getInstance().getSystemService(Context.CONNECTIVITY_SERVICE);
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        mContext = SpratAndroidActivity.getInstance();
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
            NetworkInfo networkInfo = mConnectionManager.getActiveNetworkInfo();
            int connectionType = networkInfo != null ? networkInfo.getType() : NO_CONNECTIVITY;
            try {
                SMFJSObject jsCallback = this.callbacks.getProperty("onConnectionTypeChanged");
                jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef, new Object[]{connectionType});
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void registerReceiver(){
        mContext.registerReceiver(this, mIntentFilter);
    }

    public void  unregisterReceiver(){
        mContext.unregisterReceiver(this);
    }
}