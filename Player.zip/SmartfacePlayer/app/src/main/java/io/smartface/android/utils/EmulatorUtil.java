package io.smartface.android.utils;

import android.app.Activity;
import android.view.WindowManager;

/**
 * Created by metehantoksoy on 3/13/17.
 * EmulatorUtil is a class for doing emulator stuffs like showing/hiding statusbar, actionbar etc.
 * @TODO in refactoring, do not forget to do emulator operations inside of this.
 */
public class EmulatorUtil {

    /**
     * <p>Change statusbar visibility of activity. You can check
     * <li>For add flags from activity            : {@link android.view.Window#addFlags(int)}</li>
     * <li>For clear flags from activity          : {@link android.view.Window#clearFlags(int)}</li>
     * <li>For flag that makes activity fullscreen: flags from activity:{@link android.view.WindowManager.LayoutParams#FLAG_FULLSCREEN}</li>
     *
     * @param activity for make status bar changes on it.
     * @param isVisible make status bar visible or invisible.
     */
    public static void changeStatusBarVisibility(Activity activity, boolean isVisible){
        if(isVisible){
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        else{
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }
}
