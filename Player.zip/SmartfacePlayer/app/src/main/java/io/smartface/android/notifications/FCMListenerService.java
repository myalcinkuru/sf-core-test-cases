/*
 * Copyright 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.smartface.android.notifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import io.smartface.android.SpratAndroidActivity;
import io.smartface.android.listeners.NotificationListener;
import io.smartface.android.utils.JSONUtil;
import io.smartface.android.utils.FilePathUtil;

import java.util.Random;
import android.content.res.Resources;


import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.io.FileInputStream;

/**
 * ListenerService responsible for handling GCM messages.
 * GcmListenerService uses {@link io.smartface.android.notifications.LocalNotificationReceiver}
 * for present remote notifications.
 *
 * In current implementation this service supports #alertTitle, #alertBody and #icon attributes
 * from remote.
 */
public class FCMListenerService extends FirebaseMessagingService {
    private final String ALERT_TITLE = "alertTitle";
    private final String ALERT_BODY = "alertBody";
    private final String ALERT_ICON = "icon";
    private final String ALERT_CHANNELID = "channelId";
    private final String ALERT_CHANNELID_TITLE = "channelIdTitle";
    private final String ALERT_CHANNELID_IMPORTANCE = "channelIdImportance";
    private final String ALERT_SHOW_BADGE = "showBadge";
    private final String ALERT_DELETE_CHANNEL = "deleteChannelId";
    private static ArrayList<NotificationListener> listeners = new ArrayList<>();
    private Context cntx;
    private Resources resources;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage.getData().size() > 0) {
            cntx = this;
            resources = getResources();

            Bundle extras = new Bundle();
            for (Map.Entry<String, String> entry : remoteMessage.getData().entrySet()) {
                    extras.putString(entry.getKey(), entry.getValue());
            }

            Random rnd = new Random();
            int notificationId = rnd.nextInt() % 10000;
            Notification notification = buildRemoteNotification(extras,notificationId);
            Intent notificationIntent = new Intent (getApplicationContext(), LocalNotificationReceiver.class);
            // @TODO Notification_ID must be integer but due to AND-2702 we using string
            notificationIntent.putExtra(LocalNotificationReceiver.NOTIFICATION_ID,notificationId+"");
            notificationIntent.putExtra(LocalNotificationReceiver.NOTIFICATION_OBJECT,notification);
            notificationIntent.putExtra(LocalNotificationReceiver.NOTIFICATION_ISREMOTE,true);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), notificationId, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

            AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService (
                    Context.ALARM_SERVICE);
            alarmManager.set (AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), pendingIntent);

            onRemoteNotificationReceived(JSONUtil.bundleToJson(extras),false);
        }
    }

    private Notification buildRemoteNotification(Bundle extras, int notificationId){
        String alertTitle = extras.getString(ALERT_TITLE, getApplicationContext().getApplicationInfo().loadLabel(getApplicationContext().getPackageManager()).toString());
        String alertBody = extras.getString(ALERT_BODY, "");
        String alertIconName = extras.getString(ALERT_ICON, "icon");
        String alertChannelId = extras.getString(ALERT_CHANNELID, "10");
        String alertChannelIdTitle = extras.getString(ALERT_CHANNELID_TITLE,getApplicationName());
        String alertChannelIdImportance = extras.getString(ALERT_CHANNELID_IMPORTANCE, "4");
        String alertShowBadge = extras.getString(ALERT_SHOW_BADGE, "true");
        String alertDeleteChannel = extras.getString(ALERT_DELETE_CHANNEL);

        try{
            JSONObject json = new JSONObject(loadJSONFromAsset());
            JSONObject extrasJSON = new JSONObject(JSONUtil.bundleToJson(extras));

            alertTitle = getJsonValue(json, extrasJSON, alertTitle, "title");
            alertBody = getJsonValue(json, extrasJSON, alertBody, "body");
            alertIconName = getJsonValue(json, extrasJSON, alertIconName, "icon");
            alertChannelId = getJsonValue(json, extrasJSON, alertChannelId, "channelId");
            alertChannelIdTitle = getJsonValue(json, extrasJSON, alertChannelIdTitle, "channelIdTitle");
            alertChannelIdImportance = getJsonValue(json, extrasJSON, alertChannelIdImportance, "channelIdImportance");
            alertShowBadge = getJsonValue(json, extrasJSON, alertShowBadge, "showBadge");
            alertDeleteChannel = getJsonValue(json, extrasJSON, alertDeleteChannel, "deleteChannelId");
        }
        catch(Exception e){
            e.printStackTrace();
        }

        alertIconName = alertIconName != "" ? alertIconName : "icon";
        int iconResId = getApplicationContext().getResources().getIdentifier(alertIconName,"drawable",getApplicationContext().getPackageName());
        if(iconResId == 0){
            iconResId = getApplicationContext().getResources().getIdentifier("icon","drawable",getApplicationContext().getPackageName());
        }

        Intent intentPush = new Intent(getApplicationContext(), io.smartface.SmartfaceDemo.A.class);
        intentPush.putExtra(LocalNotificationReceiver.NOTIFICATION_JSON, JSONUtil.bundleToJson(extras).toString());
        intentPush.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intentPush.putExtra(LocalNotificationReceiver.NOTIFICATION_CLICKED, true);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), notificationId, intentPush,
                PendingIntent.FLAG_ONE_SHOT);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService (Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            int importance  = Integer.parseInt(alertChannelIdImportance);
            if(alertDeleteChannel != null)
                mNotificationManager.deleteNotificationChannel(alertDeleteChannel);
            NotificationChannel notificationChannel = new NotificationChannel(alertChannelId,alertChannelIdTitle,importance);
            notificationChannel.setShowBadge(Boolean.valueOf(alertShowBadge));
            mNotificationManager.createNotificationChannel(notificationChannel);
        }

        //TODO must be implemented with channelId
        return new NotificationCompat.Builder(getApplicationContext(),alertChannelId)
                .setSmallIcon(iconResId)
                .setContentTitle(alertTitle).setContentText(alertBody)
                .setWhen(System.currentTimeMillis()).setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(pendingIntent)
                .setPriority(Notification.PRIORITY_HIGH).build();

    }

    public static void registerRemoteNotificationListener(NotificationListener listener){
        if(!listeners.contains(listener))
            listeners.add(listener);
    }
    public static void unregisterRemoteNotificationListener(NotificationListener listener){
        if(listeners.contains(listener)){
            listeners.remove(listener);
        }
    }

    public static void onRemoteNotificationReceived(String nJson, Boolean isReceivedByOnClick){
        if(SpratAndroidActivity.getInstance() != null) {
            for (NotificationListener listener : listeners) {
                listener.onRemoteNotificationReceived(nJson, isReceivedByOnClick);
            }
       }
    }

    private String getJsonValue(JSONObject json, JSONObject extrasJSON, String extrasValue, String keyName){
        if(json.has("configuration_version")){
            try{
                String key = json.getJSONObject("notification").getString(keyName);
                extrasValue = extrasJSON.getString(key);
            }catch(Exception e){
                e.printStackTrace();
            }
        }else {
            try{
                JSONObject titleJSON = json.getJSONObject(keyName).getJSONObject("data");
                String titlePath = getKeyPath(titleJSON);
                extrasValue = getTextFromData(titlePath, extrasJSON,extrasValue);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return extrasValue;
    }

    private String getTextFromData(String parser, JSONObject data , String defaultValue){
        String result = defaultValue;
        try {
            String[] bodyArr = parser.split(":");
            if(bodyArr.length > 1){
                JSONObject titleJsonObject = new JSONObject(data.getString(bodyArr[0]));
                for(int i = 1; i < bodyArr.length-1; i++){
                    titleJsonObject = titleJsonObject.getJSONObject(bodyArr[i]);
                }
                result = titleJsonObject.getString(bodyArr[bodyArr.length-1]);

            }else {
                result = data.getString(parser);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    String getKeyPath(JSONObject pathObj){
        Iterator<String> iterator = pathObj.keys();
        String result = "";
        while(iterator.hasNext()){
            String key = iterator.next();
            result += key + ":";
            try {
                pathObj = pathObj.getJSONObject(key);
                iterator = pathObj.keys();
            }catch (Exception e) {

            }
        }
        return result.substring(0,result.length()-1);
    }

    public String loadJSONFromAsset() {
        String json = null;
        String pushJsonPath = "Android/pushnotification.json";
        try {
            InputStream is = null;
            if ( SpratAndroidActivity.getInstance() != null && SpratAndroidActivity.getInstance().isemulator){

                is = new FileInputStream(FilePathUtil.getEmulatorAssetsPath() + pushJsonPath);

            }
            else{
                try {
                    is = new FileInputStream(FilePathUtil.getRAUAssetsPath() + pushJsonPath);
                } catch (Exception ex) {
                    // is = new FileInputStream(FilePathUtil.getRAUAssetsPath() + pushJsonPath);
                    is = resources.getAssets().open(pushJsonPath); // look up for assets folder
                }
            }

            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");

        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public String getApplicationName(){
        return this.getApplicationInfo().loadLabel(this.getPackageManager()).toString();
    }
}
