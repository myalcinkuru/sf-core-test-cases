package io.smartface.ExposingEngine;

import java.util.List;

/**
 *  This class is designed as protocol for ExposingEngine. All the inputs
 *  and outputs to/from {@link JavaJsInterface} supposed to use ExchangeValue
 *  class as type.
 *
 *  ExchangeValue is a wrapper for Java objects and primitives. It has type
 *  field to help understanding what is actually wrapped inside.
 */
public class ExchangeValue {

    public static class Type {
        public static final int BYTE = 0;
        public static final int SHORT = 1;
        public static final int INT = 2;
        public static final int FLOAT = 3;
        public static final int DOUBLE = 4;
        public static final int LONG = 5;
        public static final int BOOLEAN = 6;
        public static final int OBJECT = 7;
        public static final int BYTEARRAY = 8;
        public static final int SHORTARRAY = 9;
        public static final int INTARRAY = 10;
        public static final int FLOATARRAY = 11;
        public static final int DOUBLEARRAY = 12;
        public static final int LONGARRAY = 13;
        public static final int BOOLEANARRAY = 14;
        public static final int OBJECTARRAY = 15;
        public static final int STRING = 16;
        public static final int STRINGARRAY = 17;
    }
    
    public int arrayLength = -1;

    public byte byteValue;
    public short shortValue;
    public int intValue;
    public float floatValue;
    public double doubleValue;
    public long longValue;
    public boolean booleanValue;
    public int objectId = -1;

    public byte[] byteArray;
    public short[] shortArray;
    public int[] intArray;
    public float[] floatArray;
    public double[] doubleArray;
    public long[] longArray;
    public boolean[] booleanArray;
    public Object[] objectArray;
    public List<Integer> objectArrayId = null;

    public String stringValue;
    public String[] stringArray;

    public int type = ExchangeValue.Type.OBJECT;

    public ExchangeValue() {}

    public ExchangeValue(int type) {
        this.type = type;
    }

    public int GetElementIdByIndex(int index) {
        return objectArrayId.get(index);
    }
}
