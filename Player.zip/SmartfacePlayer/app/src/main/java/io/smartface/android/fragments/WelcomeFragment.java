package io.smartface.android.fragments;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import io.smartface.SmartfaceDemo.R;
import io.smartface.android.SpratAndroidActivity;

/**
 * Created by nosaiba on 31/03/16.
 */
public class WelcomeFragment extends Fragment{

    int position = 0;
    int[] welcomeLayouts = {R.layout.welcome1_layout, R.layout.welcome2_layout, R.layout.welcome3_layout};
    int[] welcomeHeaders = {R.string.welcome1_header, R.string.welcome2_header, R.string.welcome3_header};
    int[] welcomeBottomTvs = {R.string.welcome1_bottom_text, R.string.welcome2_bottom_text};
    int[] welcomeImageSrcs = {R.drawable.layer_0, R.drawable.smartface_notification};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt("position");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View welcome_layout = inflater.inflate(welcomeLayouts[position], null);
        TextView welcomeHeader = (TextView) welcome_layout.findViewById(R.id.welcome_header_tv);
        welcomeHeader.setText(welcomeHeaders[position]);
        if(position == 2) {
            Button btn = (Button) welcome_layout.findViewById(R.id.welcome_start_btn);
            btn.setVisibility(View.VISIBLE);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SpratAndroidActivity.getInstance().setContentView(SpratAndroidActivity.getInstance().parent_layout);
                    SpratAndroidActivity.getInstance().getWindow().setFlags(0, WindowManager.LayoutParams.FLAG_FULLSCREEN);
                    SpratAndroidActivity.getInstance().prepareAndStartCamera();
                }
            });
            TextView tv1 = (TextView) welcome_layout.findViewById(R.id.welcome3_middle_tv1);
            tv1.setText(Html.fromHtml(getString(R.string.welcome3_middle_text1)));
            TextView tv2 = (TextView) welcome_layout.findViewById(R.id.welcome3_middle_tv2);
            tv2.setText(Html.fromHtml(getString(R.string.welcome3_middle_text2)));
            TextView tv3 = (TextView) welcome_layout.findViewById(R.id.welcome3_middle_tv3);
            tv3.setText(Html.fromHtml(getString(R.string.welcome3_middle_text3)));
        } else {
            TextView bottomTv = (TextView) welcome_layout.findViewById(R.id.welcome_bottom_tv);
            bottomTv.setText(Html.fromHtml(getString(welcomeBottomTvs[position])));
            bottomTv.setVisibility(View.VISIBLE);
            ImageView img = (ImageView) welcome_layout.findViewById(R.id.welcome_middle_img);
            img.setBackgroundResource(welcomeImageSrcs[position]);
        }
        return welcome_layout;
    }
}
