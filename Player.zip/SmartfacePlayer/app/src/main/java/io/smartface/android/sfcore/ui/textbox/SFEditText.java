package io.smartface.android.sfcore.ui.textbox;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Field;

import io.smartface.plugin.SMFJSObject;

public class SFEditText extends EditText {
    SMFJSObject callbacks = null;
    public SFEditText(Context context, SMFJSObject callbacks) {
        super(context);
        this.callbacks = callbacks;
    }
    
    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        try {
            SMFJSObject successCallback = this.callbacks.getProperty("onKeyPreIme");
            successCallback.callAsNativeFunctionNew(successCallback.jsValueRef,new Object[]{keyCode,event.getAction()});
        } catch(Exception e) {
            e.printStackTrace();
        }
        return false; 
        // return super.dispatchKeyEvent(event);
    }

    public static void setCursorColor(EditText editText, int color) {
        // starting with P, Android locking down on certain uses of reflection,
        // and mDrawableForCursor is in black list.

        // Based on
        // https://github.com/facebook/react-native/blob/769d51824e212ed36098a61548470e45eb247f42/ReactAndroid/src/main/java/com/facebook/react/views/textinput/ReactTextInputManager.java#L361

        // Evil method that uses reflection because there is no public API to changes
        // the cursor color programmatically.
        // Based on
        // http://stackoverflow.com/questions/25996032/how-to-change-programatically-edittext-cursor-color-in-android.
        try {
            // Get the original cursor drawable resource.
            Field cursorDrawableResField = TextView.class.getDeclaredField("mCursorDrawableRes");
            cursorDrawableResField.setAccessible(true);
            int drawableResId = cursorDrawableResField.getInt(editText);

            // The view has no cursor drawable.
            if (drawableResId == 0) {
                return;
            }

            Drawable drawable = ContextCompat.getDrawable(editText.getContext(), drawableResId);
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_IN);
            Drawable[] drawables = {drawable, drawable};

            // Update the current cursor drawable with the new one.
            Field editorField = TextView.class.getDeclaredField("mEditor");
            editorField.setAccessible(true);
            Object editor = editorField.get(editText);
            Field cursorDrawableField = editor.getClass().getDeclaredField("mCursorDrawable");
            cursorDrawableField.setAccessible(true);
            cursorDrawableField.set(editor, drawables);
        } catch (NoSuchFieldException ex) {
            // Ignore errors to avoid crashing if these private fields don't exist on modified
            // or future android versions.
        } catch (IllegalAccessException ex) {
        }
    }
}