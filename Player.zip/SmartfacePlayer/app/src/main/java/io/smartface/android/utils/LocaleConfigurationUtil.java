package io.smartface.android.utils;


import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.util.Locale;
import io.smartface.android.SpratAndroidActivity;
/*
The intend of creating this class is to provide easy way to change configurations.
 */
public class LocaleConfigurationUtil {
    static String DEFAULT = "auto";

    public static Context changeConfigurationLocale(Context context){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

        final String restrictedDirection = getRestrictedDirection();
        Context currentContext = context;
        if(!restrictedDirection.isEmpty() && !restrictedDirection.contains(DEFAULT)){
            currentContext = createContextWithDirection(context,restrictedDirection);
        }
        else if(sharedPreferences.getString("AppLocale", "NoneChanges") != "NoneChanges") {
            currentContext = createContextWithDirection(context, sharedPreferences.getString("AppLocale",DEFAULT));
        } else {
            currentContext = adjustFontSize(context);
        }
        return currentContext;
    }

    public static String getDeviceLanguage() {
       Configuration config = SpratAndroidActivity.getActivity().getResources().getConfiguration();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            return  config.getLocales().get(0).getLanguage();
        }
        return config.locale.getLanguage();
    }

    private static String getRestrictedDirection(){
        Bundle applicationMetaData = SpratAndroidActivity.getActivity().getApplicationInfo().metaData;

        return (applicationMetaData != null ? applicationMetaData.getString("locale", "") : "" );
    }

    private static Context createContextWithDirection(Context context, String lang){
        Configuration config = context.getResources().getConfiguration();

        String defaulLang = lang.contains(DEFAULT) ?  Locale.getDefault().getLanguage() : lang;

        Locale locale = new Locale(defaulLang);
        locale.setDefault(locale);
        config.setLocale(locale);
        config.setLayoutDirection(locale);
        config.fontScale = 1.0f;
        Context newContext = context.createConfigurationContext(config);

        return newContext;
    }

    public static Context adjustFontSize(Context context){
        Configuration configuration = context.getResources().getConfiguration();
        configuration.fontScale = 1.0f;

        return context.createConfigurationContext(configuration);
    }

}
