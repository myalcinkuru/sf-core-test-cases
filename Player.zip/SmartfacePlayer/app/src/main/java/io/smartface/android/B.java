package io.smartface.android;


import java.lang.reflect.Constructor;
import java.util.Vector;

import android.os.Bundle;

public class B extends SpratAndroidActivity {
    
}
