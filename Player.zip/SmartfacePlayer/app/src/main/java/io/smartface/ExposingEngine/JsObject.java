package io.smartface.ExposingEngine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class JsObject extends JsAbstractObject {
    private JsClass parentClass = null;

    public JsObject(Object object) {
        super(object);
        setParentClass();
        setReady(true);
    }

    @Override
    public void setJavaObject(Object object) {
        super.setJavaObject(object);
        setParentClass();
        setReady(true);
    }

    @Override
    public JsAbstractObject getProperty(String name) throws Exception {
        return parentClass.getInstanceProperty(this, name);
    }

    @Override
    public boolean setProperty(String name, Object value) {
        try {
            return parentClass.setInstanceProperty(this, name, value);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public JsAbstractObject invokeMethod(String name, Object[] parametersAsArray) throws Throwable {
        Method method = parentClass.getMethod(name, parametersAsArray);

        if (method == null) {
            throw new NoSuchMethodException("Method " + name + " with " + parametersAsArray.length + " parameters couldn't found");
        }

        try {
            Object result = method.invoke(getJavaObject(), parametersAsArray);
            return wrapObjectIntoJsAbstractObject(result);
        } catch (InvocationTargetException exception) {
            throw exception.getTargetException();
        }
    }

    private void setParentClass() {
        if (parentClass != null) return;

        if (this.javaObject != null) {
            parentClass = JsClassManager.GetClass(this.javaObject.getClass().getName());
            if (parentClass == null) {
                parentClass = JsClassManager.GetClass(this.javaObject.getClass());
            }
        }
    }
}