package io.smartface.android.sfcore.ui.alertview;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;

import io.smartface.android.SpratAndroidActivity;

public class SFAlertView extends AlertDialog {
    private LinearLayout alertCustomLayout;

    public SFAlertView(Context context) {
        super(context);
    }

    public void addTextBox(EditText editText, int width, int height, int left, int top, int right, int bottom){
        if(alertCustomLayout == null) {
            alertCustomLayout = new LinearLayout(getContext());
            alertCustomLayout.setFocusableInTouchMode(true);
            alertCustomLayout.setFocusable(true);
            alertCustomLayout.setOrientation(LinearLayout.VERTICAL);
            this.setView(alertCustomLayout);
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width, height);
        layoutParams.setMargins(left, top, right, bottom);
        editText.setLayoutParams(layoutParams);
        editText.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        alertCustomLayout.addView(editText);
    }
}
