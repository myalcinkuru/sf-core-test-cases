package io.smartface.android.sfcore.ui.listview;

import androidx.recyclerview.widget.RecyclerView;

import io.smartface.plugin.SMFJSObject;

public class SFOnScrollListener extends RecyclerView.OnScrollListener {
    SMFJSObject callbacks = null;
    public SFOnScrollListener(SMFJSObject callbacks) {
        this.callbacks = callbacks;
    }

    @Override
    public void onScrolled(RecyclerView recyclerView, int dx, int dy){
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onScrolled");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{dx,dy});
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
        try {
            SMFJSObject jsCallback = this.callbacks.getProperty("onScrollStateChanged");
            jsCallback.callAsNativeFunctionNew(jsCallback.jsValueRef,new Object[]{newState});
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}