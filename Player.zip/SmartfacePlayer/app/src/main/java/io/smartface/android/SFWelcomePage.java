package io.smartface.android;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import android.widget.Button;

import io.smartface.SmartfaceDemo.R;
import io.smartface.android.fragments.WelcomeFragment;

public class SFWelcomePage {
    public static void show(SpratAndroidActivity activity) {
        ViewPager mViewPager = activity.findViewById(R.id.pager);
        final Button indicator1 = activity.findViewById(R.id.welcome_indicator1);
        final Button indicator2 = activity.findViewById(R.id.welcome_indicator2);
        final Button indicator3 = activity.findViewById(R.id.welcome_indicator3);

        indicator1.setSelected(true);
        indicator2.setSelected(false);
        indicator2.setSelected(false);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset,
                                       int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        indicator1.setSelected(true);
                        indicator2.setSelected(false);
                        indicator3.setSelected(false);
                        break;
                    case 1:
                        indicator1.setSelected(false);
                        indicator2.setSelected(true);
                        indicator3.setSelected(false);
                        break;
                    case 2:
                        indicator1.setSelected(false);
                        indicator2.setSelected(false);
                        indicator3.setSelected(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        mViewPager.setAdapter(new FragmentStatePagerAdapter(activity.getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                WelcomeFragment welcomeFragment = new WelcomeFragment();
                Bundle args = new Bundle();
                args.putInt("position", position);
                welcomeFragment.setArguments(args);
                return welcomeFragment;
            }

            @Override
            public int getCount() {
                return 3;
            }
        });
    }
}
