package io.smartface.android.sfcore.device.location;

import android.app.Activity;
import android.content.IntentSender;
import android.location.Location;
import androidx.annotation.NonNull;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;

public class SFLocationCallback extends LocationCallback {
    public static final int REQUEST_CHECK_SETTINGS = 205;

    private Activity activity = null;
    private FusedLocationProviderClient locationProviderClient = null;
    private SMFJSObject onLocationCallback = null;
    private SMFJSObject checkSettingsCallback = null;
    private SettingsClient settingsClient = null;
    private LocationRequest locationRequest = null;
    private LocationSettingsRequest.Builder settingsRequestBuilder = null;

    public SFLocationCallback(SMFJSObject callbacks) {
        this.onLocationCallback = callbacks;
        this.activity = SpratAndroidActivity.getInstance();
        this.locationProviderClient = LocationServices.getFusedLocationProviderClient(activity);
        this.settingsClient = LocationServices.getSettingsClient(activity);

        this.locationRequest = new LocationRequest();

        this.settingsRequestBuilder = new LocationSettingsRequest.Builder();
        this.settingsRequestBuilder.addLocationRequest(locationRequest);
    }

    public void start(int priority,long longMill) {
        this.locationRequest.setInterval(longMill);
        this.locationRequest.setPriority(priority);
        // TODO: https://smartface.atlassian.net/browse/AND-3549
        // Update this code after AND-3549 implementation.
        try {
            locationProviderClient.requestLocationUpdates(locationRequest, this, null);
        } catch (SecurityException exception) {}
    }

    public void stop() {
        this.locationProviderClient.removeLocationUpdates(this);
    }

    public void getLastKnownLocation(final SMFJSObject callbacks){
        // TODO: https://smartface.atlassian.net/browse/AND-3549
        try {
            Task<Location> lastKnownLocation = locationProviderClient.getLastLocation()
                    .addOnSuccessListener(
                            activity, new OnSuccessListener<Location>() {
                                @Override
                                public void onSuccess(Location location) {
                                    if (location == null) {
                                        setLastKnownLocationCallback(callbacks, "onFailure", null);
                                        return;
                                    }
                                    setLastKnownLocationCallback(callbacks, "onSuccess",new Object[]{location.getLatitude(),location.getLongitude()});
                                }
                            }
                    )
                    .addOnFailureListener(activity, new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    setLastKnownLocationCallback(callbacks, "onFailure",null);
                                }
                            }
                    );
        }catch (SecurityException e){}
    }

    private void setLastKnownLocationCallback(SMFJSObject callback,String prop,Object[] params){
        try {
            SMFJSObject jsOnSuccessCallback = callback.getProperty(prop);
            jsOnSuccessCallback.callAsNativeFunctionNew(jsOnSuccessCallback.jsValueRef, params);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void checkSettings(SMFJSObject callbacks) {
        this.checkSettingsCallback = callbacks;
        this.settingsClient.checkLocationSettings(settingsRequestBuilder.build())
                .addOnSuccessListener(activity, new OnSuccessListener<LocationSettingsResponse>() {
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        try {
                            SMFJSObject jsOnSuccessCallback = checkSettingsCallback.getProperty("onSuccess");
                            jsOnSuccessCallback.callAsNativeFunctionNew(jsOnSuccessCallback.jsValueRef, null);
                        } catch (Exception e) {}
                    }
                })
                .addOnFailureListener(activity, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        int statusCode = ((ApiException) exception).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                try {
                                    // Show the dialog by calling startResolutionForResult(), and check the
                                    // result in onActivityResult().
                                    ResolvableApiException rae = (ResolvableApiException) exception;
                                    rae.startResolutionForResult(activity, REQUEST_CHECK_SETTINGS);
                                } catch (IntentSender.SendIntentException sie) {}
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                try {
                                    SMFJSObject jsOnSuccessCallback = checkSettingsCallback.getProperty("onFailure");
                                    jsOnSuccessCallback.callAsNativeFunctionNew(jsOnSuccessCallback.jsValueRef, new Object[]{"SETTINGS_CHANGE_UNAVAILABLE"});
                                } catch (Exception e) {}
                        }
                    }
                });

    }

    @Override
    public void onLocationResult(LocationResult locationResult) {
        try {
            if (locationResult == null)
                return;
            Location location = locationResult.getLastLocation();
            Object[] params = {location.getLatitude(), location.getLongitude()};
            onLocationCallback.callAsNativeFunctionNew(onLocationCallback.jsValueRef, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationAvailability(LocationAvailability locationAvailability) {
    }
}