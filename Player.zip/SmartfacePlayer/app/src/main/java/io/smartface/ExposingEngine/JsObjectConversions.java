package io.smartface.ExposingEngine;


import java.lang.reflect.Array;

public class JsObjectConversions {

  private static Object unwrapObject(int objectId) {
    Object object = JsObjectCollection.get(objectId);
    if (object instanceof JsObject) {
      object = ((JsObject)object).getJavaObject();
    }
    return object;
  }

  public static String ToPrimitiveString(int objectId) {
    return ((CharSequence)unwrapObject(objectId)).toString();
  }

  public static int ToInteger(int value) {
    return JsObjectCollection.add(value);
  }

  public static int ToDouble(double value) {
    return JsObjectCollection.add(value);
  }

  public static int ToFloat(float value) {
    return JsObjectCollection.add(value);
  }

  public static int ToLong(long value) {
    return JsObjectCollection.add(value);
  }

  public static int ToShort(short value) {
    return JsObjectCollection.add(value);
  }

  public static int ToBoolean(boolean value) {
    return JsObjectCollection.add(value);
  }

  public static int ToCharacter(char value) {
    return JsObjectCollection.add(value);
  }

  public static int ToString(String value) {
    return JsObjectCollection.add(value);
  }

  public static int ToArray(int[] elements, String className) throws ClassNotFoundException {
    Class toClass;
    if (className != null) {
      toClass = (Class) JsClassManager.GetClass(className).getJavaObject();
    } else {
      toClass = unwrapObject(elements[0]).getClass();
    }
//    toClass = toPrimitiveClass(toClass);
    Object actualArray = Array.newInstance(toClass, elements.length);
    for (int i = 0; i < elements.length; ++i) {
      Array.set(actualArray, i, elements[i] == -1 ? null : unwrapObject(elements[i]));
    }
    return JsObjectCollection.add(new JsObject(actualArray));
  }

  public static int ToByteArray(byte[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToShortArray(short[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToIntArray(int[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToFloatArray(float[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToDoubleArray(double[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToLongArray(long[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToBooleanArray(boolean[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static int ToStringArray(String[] elements) {
    return JsObjectCollection.add(elements);
  }

  public static Class toPrimitiveClass(Class clazz) {
    if(clazz == Integer.class) return int.class;
    if(clazz == Double.class) return double.class;
    if(clazz == Float.class) return float.class;
    if(clazz == Long.class) return long.class;
    if(clazz == Short.class) return short.class;
    if(clazz == Boolean.class) return boolean.class;
    if(clazz == Character.class) return char.class;
    if(clazz == Byte.class) return byte.class;

    return clazz;
  }
}