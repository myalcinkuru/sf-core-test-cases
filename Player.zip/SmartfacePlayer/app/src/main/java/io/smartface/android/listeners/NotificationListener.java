package io.smartface.android.listeners;

/**
 * Created by metehantoksoy on 3/12/17.
 * NotificationListener created for handling remote notification received
 * event without old structure.
 */
public interface NotificationListener {
    void onRemoteNotificationReceived(String notificationData, Boolean isReceivedByOnClick);
    void onLocalNotificationReceived(String notificationData);
}
