package io.smartface.android.sfcore.ui.listview;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

public class SFRecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
    private SFRecyclerViewAdapter recyclerViewAdapter = null;
    public SFRecyclerViewHolder(View itemView) {
        super(itemView);
        itemView.setOnClickListener(this);
        itemView.setOnLongClickListener(this);
    }

    public void setRecyclerViewAdapter(SFRecyclerViewAdapter recyclerViewAdapter) {
        this.recyclerViewAdapter = recyclerViewAdapter;
    }

    @Override
    public void onClick(View v) {
        if(this.recyclerViewAdapter == null)
            return;
        int position = this.getAdapterPosition();
        int itemViewHashCode = this.itemView.hashCode();
        this.recyclerViewAdapter.onItemSelected(position, itemViewHashCode);
    }

    @Override
    public boolean onLongClick(View view) {

        if(this.recyclerViewAdapter == null)
            return false;

        int position = this.getAdapterPosition();
        int itemViewHashCode = this.itemView.hashCode();
        return this.recyclerViewAdapter.onItemLongSelected(position, itemViewHashCode);
    }
}