package io.smartface.android;

public class EventID {

    public static final int ON_PRESS = 0;
    public static final int ON_ITEM_SELECTED = 1;
    public static final int ON_SUCCES = 3;
    public static final int ON_FAILURE = 4;
    public static final int ON_DOWNLOAD_FINISH = 5;
    public static final int ON_PLAYBACK_COMPLETED = 6;
    /**
     * 7. event ne olduğu belli değil
     *
     * @RET diye görünüyor.
     */

    public static final int ON_ERROR = 8;
    public static final int ON_TIMER = 9;
    public static final int ON_SHOW = 10;
    public static final int ON_HIDE = 11;
    public static final int ON_ACTIVATED_ = 12;
    public static final int ON_DEACTIVATED_ = 13;
    public static final int ON_CHANGE = 14;
    public static final int ON_SELECT = 15;
    public static final int ON_DROP_DOWN = 16;
    public static final int ON_CLOSE = 17;
    public static final int ON_START = 18;
    public static final int ON_FIRST_START = 19;
    public static final int ON_SUCCESS = 20;
    public static final int ON_SERVER_ERROR = 21;
    public static final int ON_SERVER_CONNECTED = 22;
    public static final int ON_PARAMETER_SENT = 23;
    /**
     * @todo: 24 yok, parameter received 34 geliyor hata mı bu ?
     */
    public static final int ON_SYNDICATION_SUCCESS = 25;
    public static final int ON_UPDATE_READY = 26;
    public static final int ON_UPDATE_NONE = 27;
    /**
     * saçma sapan olaylar zinciri. bu ve ON_OPEN_COMPLETED karışıyor. hangi
     * akıllı böyle iki isim vermiş çok merak ettim
     *
     * @author adem
     */
    // public static final int ON_OPEN_COMPLETE = 28;
    /**
     * üstteki ile aynı denyo olay
     *
     * @author adem
     */
    // public static final int ON_INIT_COMPLETE = 29;

    public static final int ON_KEY_PRESSED = 30;
    public static final int ON_INITIALIZED = 32;
    public static final int ON_ERROR2 = 33;
    public static final int ON_PARAMETER_RECEIVED = 34; // ???

    public static final int ON_HTTP_RETURN = 36;
    public static final int ON_PLAYBACK_STARTED = 37;

    public static final int MAX_VALUE_OVERFLOW = 38;

    /**
     * TODO check update'de dol dur u la cak.
     *
     */
    public static final int ON_ERROR_CHECKUPDATE = 39;

    public static final int ON_KAMERA_START_SUCCESS = 40;
    public static final int ON_KAMERA_START_FAIL = 41;
    public static final int ON_CAPTURE_SUCCESS = 42;
    public static final int ON_CAPTURE_FAIL = 43;

    public static final int ON_EDIT_ENTER = 44;
    public static final int ON_EDIT_CHANGE = 45;

    /**
     * Ekleme... UD100128
     */
    public static final int ON_SIM_CARD_CHANGE = 46;
    public static final int ON_CONTROL_TRUE = 47;
    public static final int ON_CONTROL_FALSE = 48;
    public static final int ON_CONTROL_LOOP = 49;
    public static final int ON_DP_WEAK_PIN_ERROR = 50;
    public static final int ON_DP_GENERIC_ERROR = 51;
    public static final int ON_DP_INVALID_PIN_ERROR = 52;
    public static final int ON_DP_ACTIVATION_REQUIRED = 53;
    public static final int ON_DP_REACTIVATION_REQUIRED = 54;

    public static final int ON_KOBIL_SUCCESS = ON_SUCCES;
    public static final int ON_KOBIL_WEAK_PIN_ERROR = 50;
    public static final int ON_KOBIL_GENERIC_ERROR = 51;
    public static final int ON_KOBIL_INVALID_PIN_ERROR = 52;
    public static final int ON_KOBIL_ACTIVATION_REQUIRED = 53;
    public static final int ON_KOBIL_REACTIVATION_REQUIRED = 54;
    public static final int ON_KOBIL_INVALID_ACTIVATION_CODE = 55;

    public static final int ON_VALIDATION_FAILED = 56;
    /**
     * when you touch any component , it will be fired
     */
    public static final int ON_TOUCH_BEGIN = 57;
    public static final int ON_WEBPAGE_LOAD = 58;
    public static final int ON_LONG_TOUCH = 59;
    public static final int ON_DYNAMIC_DOUBLE_TAP = 60;
    public static final int ON_DRAG_INSIDE = 61;
    public static final int ON_DRAG_OUTSIDE = 62;
    public static final int ON_DRAG_ENTER = 63;
    public static final int ON_DRAG_EXIT = 64;
    public static final int ON_LINK_CLICKED = 65;
    public static final int ON_CAMERA_CAPTURE = 66;

    public static final int ON_CANCEL_SELECTION = 67;

    public static final int ON_DIALOGFIRSTBUTTON = 68;
    public static final int ON_DIALOGSECONDBUTTON = 69;
    public static final int ON_DIALOGTHIRDBUTTON = 70;
    public static final int ON_SHAKE = 71;
    public static final int ON_ORIENTATION_CHANGED = 72;
    public static final int ON_ACCELERATION_CHANGED = 73;
    public static final int ON_LOCATION_CHANGED = 74;
    public static final int ON_EXIT = 75;
    public static final int ON_RETURN_KEY = 76;
    public static final int ON_MAXIMIZE = 77;
    public static final int ON_MINIMIZE = 78;
    public static final int ON_REPEATBOX_RENDER = 79;
    public static final int ON_PICKER_SELECTED = 80;
    public static final int ON_SCROLL_PAGE_CHANGED = 81;
    public static final int ON_CONNECTION_CHANGED = 82;
    public static final int ON_ANIMATION_FINISH = 83;
    public static final int ON_PULL_DOWN = 84;
    public static final int ON_PULL_UP = 85;
    public static final int ON_GLOBAL_ERROR = 87;
    public static final int ON_SWIPE = 88;
    public static final int ON_PIN_SELECTED = 89;
    public static final int ON_TOUCH_END = 90;
    public static final int ON_RECEIVED_NOTIFICATION = 93;
    public static final int ON_PINCH = 94;

    /**
     * TODO implement this.
     */
    public static final int ON_ROW_DELETED = 95;
    public static final int ON_URL_CHANGED = 96;

    private static final int KEY_ATTR = 8;
    private static final int A_BACK = 106;
    private static final int A_MENU = 107;

    public static final int ON_APPLICATION_CALL_RECEIVED = 110;


    public static final int ON_PIN_DRAG_START = 124;
    public static final int ON_PIN_DRAG_END = 125;
    public static final int ON_MAP_REGION_CHANGED = 126;
    public static final int ON_TOUCH_MOVE = 127;
    public static final int ON_DRAW = 128;

    public static final int ON_DATASET_BEFORE_COMMIT = 130;
    public static final int ON_DATASET_BEFORE_ROW_DELETE = 131;
    public static final int ON_DATASET_BEFORE_SELECTED = 132;
    public static final int ON_DATASET_NEW_ROW = 134;
    public static final int ON_DATASET_ROW_COMMIT = 135;
    public static final int ON_DATASET_ROW_INDEX_CHANGED = 136;
    public static final int ON_DATASET_SELECTED = 137;
    public static final int ON_DATASET_COMMIT = 138;

    //UNKNOWN EVENT ID's
    public static final int ON_DATASET_ROW_DELETED = 521;
    public static final int ON_DATASET_SELECT_ERROR = 524;

    public static final int ON_EDIT_KEY_DOWN = 139;
    public static final int ON_REPEATBOX_ONSCROLL = 140;
    public static final int ON_REPEATBOX_ROW_DELETING = 150;
    public static final int ON_REQUEST_PERMISSION_RESULT = 153;

    // Dynamic events must be added to end
    public static final int ON_JS_RUN_SUCCESS = 500;
    public static final int ON_DYNAMIC_SWIPE_UP = 501;
    public static final int ON_DYNAMIC_SWIPE_RIGHT = 502;
    public static final int ON_DYNAMIC_SWIPE_DOWN = 503;
    public static final int ON_DYNAMIC_SWIPE_LEFT = 504;
    public static final int ON_CONTACT_PICKED_SUCCESS = 505;
    public static final int ON_GET_ALL_CONTACTS_SUCCESS = 506;
    public static final int ON_GALLERY_PICK_SUCCESS = 507;
    public static final int ON_GET_ALL_GALLERY_ITEMS_SUCCESS = 508;
    public static final int ON_SAVE_GALLERY_SUCCESS = 509;
    public static final int ON_INAPP_BUY_PRODUCT_SUCCESS = 510;
    public static final int ON_RETRIEVE_PURCHASES_SUCCESS = 511;
    public static final int ON_INAPP_REQUEST_PRODUCTS_SUCCESS = 512;
    public static final int ON_INAPP_CONSUME_PURCHASE_SUCCESS = 513;
    public static final int ON_ERROR_WITH_MESSAGE = 514;
    public static final int ON_DYNAMIC_PINCH = 515;


    public static final int ON_CROP_SUCCESS = 516;
    public static final int ON_CROP_FAIL = 517;
    public static final int ON_CROP_CANCEL = 518;


    public static final int ON_KEY_BACK = ( (A_BACK + 1) << KEY_ATTR)
                                          | ON_KEY_PRESSED;
    public static final int ON_KEY_MENU = ( (A_MENU + 1) << KEY_ATTR)
                                          | ON_KEY_PRESSED;

    public static final int ON_SEARCH_START = 141;
    public static final int ON_SEARCH_SUBMIT = 142;
    public static final int ON_TEXT_CHANGE = 143;

    public static final int ON_AD_LOADED = 144;
    public static final int ON_AD_FAILED_TO_LOAD = 145;
    public static final int ON_AD_OPENED = 146;
    public static final int ON_AD_CLOSED = 147;
    public static final int ON_AD_LEFT_APPLICATION = 148;

    public static final int ON_IMAGE_LOAD = 58;//same as ON_WEBPAGE_LOAD
    public static final int ON_IMAGE_LOAD_FAILURE = 149;
}
