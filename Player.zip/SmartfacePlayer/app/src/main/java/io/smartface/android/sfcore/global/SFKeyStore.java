package io.smartface.android.sfcore.global;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.security.KeyPairGeneratorSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;
import java.math.BigInteger;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Calendar;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.security.auth.x500.X500Principal;

import io.smartface.android.SpratAndroidActivity;
import io.smartface.plugin.SMFJSObject;

public class SFKeyStore implements LifecycleObserver {
    private String alias;
    private KeyStore keyStore;
    private final String AndroidKeyStore = "AndroidKeyStore";
    private final String RSA_MODE = "RSA/ECB/PKCS1Padding";
    private Context activityContext = SpratAndroidActivity.getActivity();
    private byte[] toDecrypt = null;
    WeakReference < AsyncTask < String, String, String >> encryptTaskWeakReference;
    WeakReference < AsyncTask < Void, String, String >> decryptTaskWeakReference;
    private final SharedPreferences preferences;
    private final String DECRYPTED_BASE64_KEY;

    public SFKeyStore(String key) throws Exception {
       this.alias = key;
       keyStore = initializeKeyStore();
       generateKeyPair();
       preferences = PreferenceManager.getDefaultSharedPreferences(SpratAndroidActivity.getActivity());
       DECRYPTED_BASE64_KEY = "SF_PRIVATEDATA_"+key;
    }

    public void generateKeyPair() throws Exception {
        if (!keyStore.containsAlias(alias)) {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, AndroidKeyStore);
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.M) {
                Calendar end = Calendar.getInstance();
                end.add(Calendar.YEAR, 30);
                KeyPairGeneratorSpec specs = new KeyPairGeneratorSpec.Builder(activityContext)
                    .setAlias(alias)
                    .setSubject(new X500Principal("CN=" + alias))
                    .setStartDate(Calendar.getInstance().getTime())
                    .setEndDate(end.getTime())
                    .setSerialNumber(BigInteger.TEN)
                    .build();

                keyPairGenerator.initialize(specs);
                keyPairGenerator.generateKeyPair();
            } else {
                KeyGenParameterSpec specs = new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_DECRYPT |
                        KeyProperties.PURPOSE_ENCRYPT)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
                    .setRandomizedEncryptionRequired(false)
                    .build();

                keyPairGenerator.initialize(specs);
                keyPairGenerator.generateKeyPair();
            }
        }
    }

    public void encryptData(String plainText, final SMFJSObject callbacks) {

        encryptTaskWeakReference = new WeakReference < AsyncTask < String, String, String >> (
            new AsyncTask < String, String, String > () {
                @Override
                protected String doInBackground(String...strings) {
                    try {
                        generateKeyPair();
                        KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) keyStore.getEntry(alias, null);
                        Cipher chiperText = Cipher.getInstance(RSA_MODE);
                        chiperText.init(Cipher.ENCRYPT_MODE, privateKeyEntry.getCertificate().getPublicKey());

                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        CipherOutputStream cipherOutputStream = new CipherOutputStream(byteArrayOutputStream, chiperText);
                        cipherOutputStream.write(strings[0].getBytes());
                        cipherOutputStream.close();
                        toDecrypt = byteArrayOutputStream.toByteArray();
                        String base64 = Base64.encodeToString(toDecrypt, Base64.DEFAULT);
                        preferences.edit().putString(DECRYPTED_BASE64_KEY, base64).commit();
                    } catch (Exception e) {
                        String errorMessage = e.getMessage() + "\n" + getStackTraceInText(e);
                        cancel(true);
                        return errorMessage;
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(String s) {
                    throwResult(s, callbacks, false);
                }

                @Override
                protected void onCancelled(String errorMessage) {
                    throwResult(errorMessage, callbacks, true);
                }
            });

        encryptTaskWeakReference.get().execute(plainText);
    }

    public void decryptData(final SMFJSObject callbacks) {

        decryptTaskWeakReference = new WeakReference < AsyncTask < Void, String, String >> (
            new AsyncTask < Void, String, String > () {
                @Override
                protected String doInBackground(Void...strings) {
                    try {
                        String decryptedBase64 = preferences.getString(DECRYPTED_BASE64_KEY,"");
                        if(!decryptedBase64.isEmpty()) toDecrypt = Base64.decode(decryptedBase64, Base64.DEFAULT);
                        if (toDecrypt == null)
                            throw new Exception("Secure value is not found");
                        KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) keyStore.getEntry(alias, null);

                        Cipher cipherText = Cipher.getInstance(RSA_MODE);
                        cipherText.init(Cipher.DECRYPT_MODE, privateKeyEntry.getPrivateKey());

                        CipherInputStream cipherInputStream = new CipherInputStream(new ByteArrayInputStream(toDecrypt), cipherText);

                        ArrayList < Byte > byteArrayList = new ArrayList < > ();

                        int nextByte;
                        while ((nextByte = cipherInputStream.read()) != -1) {
                            byteArrayList.add((byte) nextByte);
                        }

                        byte[] bytes = new byte[byteArrayList.size()];
                        for (int i = 0; i < bytes.length; i++) {
                            bytes[i] = byteArrayList.get(i).byteValue();
                        }
                        return new String(bytes, "UTF-8");
                    } catch (Exception e) {
                        String errorMessage = e.getMessage() + "\n" + getStackTraceInText(e);
                        cancel(true);
                        return errorMessage;
                    }
                }

                @Override
                protected void onPostExecute(String encryptedText) {
                    throwResult(encryptedText, callbacks, false);
                }

                @Override
                protected void onCancelled(String errorMessage) {
                    throwResult(errorMessage, callbacks, true);
                }
            });
        decryptTaskWeakReference.get().execute();
    }

    public KeyStore initializeKeyStore() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(AndroidKeyStore);
        keyStore.load(null);

        return keyStore;
    }

    public void deleteEntry(final SMFJSObject callbacks) {
        try {
            keyStore.deleteEntry(alias);
            preferences.edit().remove(DECRYPTED_BASE64_KEY).commit();
            throwResult("", callbacks, false);
        } catch (Exception e) {
            String errorMessage = e.getMessage() + "\n" + getStackTraceInText(e);
            throwResult(errorMessage, callbacks, true);
        }
    }

    public void throwResult(String errorMessage, SMFJSObject callbacks, boolean isError) {
        try {
            callbacks.callAsNativeFunctionNew(callbacks.jsValueRef, new Object[]{errorMessage, isError});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getStackTraceInText(Exception e) {
        String errorStack = "";
        for (int i = 0; i < e.getStackTrace().length; i++) {
            StackTraceElement[] elements = e.getStackTrace();
            errorStack += elements[i] + "\n";
        }
        return errorStack;
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void releaseTasks() {
        if (encryptTaskWeakReference != null && encryptTaskWeakReference.get() != null &&
                (encryptTaskWeakReference.get().getStatus() != AsyncTask.Status.FINISHED))
            encryptTaskWeakReference.get().cancel(true);
        if (decryptTaskWeakReference != null && decryptTaskWeakReference.get() != null &&
                (decryptTaskWeakReference.get().getStatus() != AsyncTask.Status.FINISHED))
            decryptTaskWeakReference.get().cancel(true);
    }
}