package io.smartface.android.sfcore.ui.touch;

import android.view.MotionEvent;
import android.view.View;

import io.smartface.android.utils.AndroidUnitConverterUtil;
import io.smartface.plugin.SMFJSObject;

public class SFOnTouchViewManager implements View.OnTouchListener {
    private SMFJSObject touchCallback;
    private boolean touchEnabled = true;

    @Override
    public boolean onTouch(View view, MotionEvent event) {
        if (!touchEnabled) {
            return false;
        }
        float x = event.getX(), y = event.getY();
        int w = view.getWidth(), h = view.getHeight();
        boolean isInside = !(x > w || x < 0 || y > h || y < 0);

        int xInDp = AndroidUnitConverterUtil.pixelToDp(x), yInDp = AndroidUnitConverterUtil.pixelToDp(y);
        switch (event.getAction()) {
        case MotionEvent.ACTION_UP:
            return fireJSCallback("onTouchEnded", new Object[] { isInside, xInDp, yInDp });
        case MotionEvent.ACTION_DOWN:
            return fireJSCallback("onTouch", new Object[] { xInDp, yInDp });
        case MotionEvent.ACTION_MOVE:
            return fireJSCallback("onTouchMoved", new Object[] { isInside, xInDp, yInDp });
        case MotionEvent.ACTION_CANCEL:
            return fireJSCallback("onTouchCancelled", new Object[] { xInDp, yInDp });
        default:
            return false;
        }
    }

    public void setTouchCallbacks(SMFJSObject callbacks){
        this.touchCallback = callbacks;
    }

    public void setTouchEnabled(boolean enabled) {
        this.touchEnabled = enabled;
    }

    private boolean fireJSCallback(String callbackName, Object[] params) {
        if(touchCallback != null) {
            try {
                SMFJSObject touchCallbackProperty = touchCallback.getProperty(callbackName);
                Object result = touchCallbackProperty.callAsNativeFunctionNew(touchCallbackProperty.jsValueRef, params);
                return (boolean) result;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
