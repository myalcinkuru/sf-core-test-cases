#include "Core/SpApplication.h"
#include "ExposingEngine/SpJSFunctionsPlugins.h"
#include "NfProfiler.hpp"
#include "SpClass/SharedJSObject.h"
#include "SpJsEngine/Core/SpJsEngine.h"
#include "SpJsEngine/Android/SpJsV8Specific.h"
#include "ExposingEngine/SpDynamicObjectRef.h"


using namespace v8;

#define V8Begin() \
    lock_guard<recursive_mutex> lock (smf_v8_isolate_lock); \
    SpJsEngineReady (); \
    Locker __isolatelock__ (smf_v8_isolate); \
    Isolate::Scope __isolate__ (smf_v8_isolate); \
    HandleScope __handles__ (smf_v8_isolate); \
    Context::Scope __context__ (smf_v8_global_context.Get (smf_v8_isolate))

extern recursive_mutex smf_v8_isolate_lock;
extern Isolate* smf_v8_isolate;
extern Persistent<Context> smf_v8_global_context;

bool jsNumberToJava(SpJsValue& value, const char* expectedType, jvalue* dest) {
    if (strlen(expectedType) != 1 && strcmp(expectedType,"Ljava/lang/Object;") != 0) {
        return false;
    }

    if(expectedType[0] == 'D' || 
            strcmp(expectedType,"Ljava/lang/Object;") == 0) {
        dest->d = SpJsDoubleValue(value);
        return true;
    } else if(expectedType[0] == 'F') {
        dest->f  = (float) value->Get(smf_v8_isolate)->ToNumber()->Value();
        return true;
    } else if(expectedType[0] == 'J') {
        dest->j = (long long) value->Get(smf_v8_isolate)->ToNumber()->Value();
        return true;
    } else if(expectedType[0] == 'I') {
        dest->i = (int) value->Get(smf_v8_isolate)->ToNumber()->Value();
        return true;
    } else if(expectedType[0] == 'S') {
        dest->s = (short) value->Get(smf_v8_isolate)->ToNumber()->Value();
        return true;
    } else if(expectedType[0] == 'B') {
        dest->b = (char) value->Get(smf_v8_isolate)->ToNumber()->Value();
        return true;
    }

    return false;
}

template<typename T>
T* createJArrayFromJsNumberArray(Array* jsArray) {
    int count = jsArray->Length();
    T* jsObjectArray = new T[count];
    for(int i = 0; i < count; i++)
    {
        auto elementValue = jsArray->Get(i);
        jsObjectArray[i] = (T) elementValue->ToNumber()->Value();
    }
    return jsObjectArray;
}

bool SpDynamicObjectBase::jsValueToJava(SpJsValue& value, const char* expectedType, jvalue* dest)
{
    auto actualValue = value->Get(smf_v8_isolate);
    bool isNullCache = actualValue->IsNull();
    bool isObjectCache = actualValue->IsObject();
    bool success = false;
    if(strcmp(expectedType, "Lio/smartface/plugin/SMFJSObject;") == 0)
    {
        if(isNullCache) {
            dest->l = NULL;
            success = true;
        } else if(actualValue->IsObject()) {
            SpContext* context = SpContext::GetInstance();
            JNIEnv* env =  context->GetJniEnvironment();
            static jclass cls = context->getClass("SMFJSObject");
            static jmethodID constructor = env->GetMethodID(cls, "<init>", "()V");
            jobject smfJsObjectRef = env->NewObject(cls, constructor);
            static jfieldID smfFid = env->GetFieldID(cls, "jsValueRef", "J");
            env->SetLongField (smfJsObjectRef, smfFid, (jlong)(new SharedJSValue (value)));
            dest->l = smfJsObjectRef;
            success = true;
        }
    }
    return success;
}
