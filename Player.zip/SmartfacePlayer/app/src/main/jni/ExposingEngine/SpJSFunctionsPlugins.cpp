//
// Created by nosaiba on 22/11/16.
//

#include <iostream>
#include <string>
#include <Poco/JSON/Parser.h>
#include <Poco/JSON/JSON.h>
#include <SpJsEngine/Core/SpJsEngine.h>

#include "Core/SpBrResourceManager.h"
#include "Core/SpBrString.h"
#include "Core/SpLog.h"
#include "ExposingEngine/JsJavaInterface.h"
#include "ExposingEngine/JsObjectConverter.h"
#include "ExposingEngine/SpDynamicObjectRef.h"
#include "ExposingEngine/SpJSFunctionsPlugins.h"
#include "SPJavaScript/SpJSCommon.h"
#include "../headers/NfProfiler.hpp"

using namespace v8;

#define V8Begin() \
    lock_guard<recursive_mutex> lock (smf_v8_isolate_lock); \
    SpJsEngineReady (); \
    Locker __isolatelock__ (smf_v8_isolate); \
    Isolate::Scope __isolate__ (smf_v8_isolate); \
    HandleScope __handles__ (smf_v8_isolate); \
    Context::Scope __context__ (smf_v8_global_context.Get (smf_v8_isolate))

extern recursive_mutex smf_v8_isolate_lock;
extern Isolate* smf_v8_isolate;
extern Persistent<Context> smf_v8_global_context;

std::map<std::string,SpJsObject> dynamicJSClassObjects;

void cb_implement(const v8::FunctionCallbackInfo<v8::Value>& __smf_info__) {
	v8::Local<v8::Context> v8Context = smf_v8_global_context.Get(__smf_info__.GetIsolate());
	v8::Local<v8::Object> thisObject = __smf_info__.This();
	jobject id = JsJavaInterface::ConvertToJavaType(thisObject, v8Context, __smf_info__.GetIsolate());
	if(id != NULL) {
		if (__smf_info__.Length() >= 1 && __smf_info__[0]->IsObject()) {
			JNIEnv *env = SpContext::GetInstance()->GetJniEnvironment();
			if (env->PushLocalFrame(3) != 0) {
				__smf_info__.GetReturnValue().SetNull();
				return;
			}

			jvalue params[2];
			params[0].l = id;
			std::string callbackType = "Lio/smartface/plugin/SMFJSObject;";
			SpDynamicObjectRef::jsValueToJava(SpJsFunctionArguments[0], callbackType.c_str(), &params[1]);

			jclass clazz = env->FindClass("io/smartface/ExposingEngine/JsClassProxyOperations");
			jmethodID methodId = env->GetStaticMethodID(clazz, "generateInterfaceProxyInstance",
														"(Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/plugin/SMFJSObject;)Lio/smartface/ExposingEngine/ExchangeValue;");
			if (methodId != 0) {
				jobject result = env->CallStaticObjectMethodA(clazz, methodId, params);
				env->ExceptionDescribe();
				env->ExceptionClear();
				if (result == NULL) {
					__smf_info__.GetReturnValue().SetNull();
				} else {
					__smf_info__.GetReturnValue().Set(JsJavaInterface::ConvertToJSType(result, v8Context, __smf_info__.GetIsolate()));
				}
				env->PopLocalFrame(NULL);
				return;
			}

			jboolean exceptionThrown = env->ExceptionCheck();

			if (exceptionThrown) {
				jthrowable e = env->ExceptionOccurred();
				env->ExceptionDescribe();
				env->ExceptionClear();

				env->DeleteLocalRef(clazz);
				env->DeleteLocalRef(e);
			}
			env->PopLocalFrame(NULL);
		}
	}
	
	__smf_info__.GetReturnValue().SetNull();
}

void cb_extend(const v8::FunctionCallbackInfo<v8::Value>& __smf_info__) {
	v8::Local<v8::Context> v8Context = smf_v8_global_context.Get(__smf_info__.GetIsolate());
	v8::Local<v8::Object> thisObject = __smf_info__.This();
	jobject id = JsJavaInterface::ConvertToJavaType(thisObject, v8Context, __smf_info__.GetIsolate());

	if(id != NULL) {
		SpContext *context = SpContext::GetInstance();
		JNIEnv *env;
		context->GetJVM()->AttachCurrentThread(&env, NULL);
		if (env->PushLocalFrame(10) != 0) {
			__smf_info__.GetReturnValue().SetNull();
			return;
		}

		if (__smf_info__.Length() == 1) {
			jvalue params[2];

			params[0].l = JsJavaInterface::ConvertToJavaType(__smf_info__[0], v8Context, __smf_info__.GetIsolate());
			params[1].l = id;

			jclass clazz = env->FindClass("io/smartface/ExposingEngine/JsClassProxyOperations");
			if (clazz) {
				jmethodID methodId = env->GetStaticMethodID(clazz, "generateExtendingProxyInstance", "(Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/ExposingEngine/ExchangeValue;)Lio/smartface/ExposingEngine/ExchangeValue;");
				if (methodId != 0) {
					jobject result = env->CallStaticObjectMethodA(clazz, methodId, params);
					env->ExceptionDescribe();
					env->ExceptionClear();
					if (result == NULL) {
						__smf_info__.GetReturnValue().SetNull();
					} else {
						__smf_info__.GetReturnValue().Set(JsJavaInterface::ConvertToJSType(result, v8Context, __smf_info__.GetIsolate()));
					}
					env->PopLocalFrame(NULL);
					return;
				}
			}

			jboolean exceptionThrown = env->ExceptionCheck();

			if (exceptionThrown) {
				jthrowable e = env->ExceptionOccurred();
				env->ExceptionDescribe();
				env->ExceptionClear();

				env->DeleteLocalRef(clazz);
				env->DeleteLocalRef(e);
			}
			env->PopLocalFrame(NULL);
		} else if (__smf_info__.Length() == 3) {
			jvalue params[4];
			std::string smfObjType("Lio/smartface/plugin/SMFJSObject;");
			jclass ExchangeValue = env->FindClass("io/smartface/ExposingEngine/ExchangeValue");

			params[0].l = JsJavaInterface::ConvertToJavaType(__smf_info__[0], v8Context, __smf_info__.GetIsolate());
			params[1].l = id;
			SpDynamicObjectRef::jsValueToJava(SpJsFunctionArguments[1], smfObjType.c_str(), &params[2]);
			jobjectArray parameterArray = env->NewObjectArray(0, ExchangeValue, NULL);
			if (__smf_info__[2]->IsArray()) {
				v8::Array* array = v8::Array::Cast(*__smf_info__[2]);
				parameterArray = env->NewObjectArray(array->Length(), ExchangeValue, NULL);
				for (int i = 0; i < array->Length(); ++i) {
					v8::Local<v8::Value> value = array->Get(v8Context, i).ToLocalChecked();
					if (!value->IsNull() && !value->IsUndefined()) {
						env->SetObjectArrayElement (parameterArray, i, JsJavaInterface::ConvertToJavaType(value, v8Context, __smf_info__.GetIsolate()));
					}
				}

			}
			params[3].l = parameterArray;

			jclass clazz = env->FindClass("io/smartface/ExposingEngine/JsClassProxyOperations");
			if (clazz) {
				jmethodID methodId = env->GetStaticMethodID(clazz,
															"generateExtendingProxyInstance",
															"(Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/plugin/SMFJSObject;[Lio/smartface/ExposingEngine/ExchangeValue;)Lio/smartface/ExposingEngine/ExchangeValue;");
				if (methodId != 0) {
					jobject result = env->CallStaticObjectMethodA(clazz, methodId, params);
					env->ExceptionDescribe();
					env->ExceptionClear();
					if (result == NULL) {
						__smf_info__.GetReturnValue().SetNull();
					} else {
						__smf_info__.GetReturnValue().Set(JsJavaInterface::ConvertToJSType(result, v8Context, __smf_info__.GetIsolate()));
					}
					env->PopLocalFrame(NULL);
					return;
				}
			}
			jboolean exceptionThrown = env->ExceptionCheck();

			if (exceptionThrown) {
				jthrowable e = env->ExceptionOccurred();
				env->ExceptionDescribe();
				env->ExceptionClear();

				env->DeleteLocalRef(clazz);
				env->DeleteLocalRef(e);
			}
			env->PopLocalFrame(NULL);
		} else if (SpJsFunctionArgumentCount == 4) {
			jvalue params[5];
			std::string smfObjType("Lio/smartface/plugin/SMFJSObject;");
			jclass ExchangeValue = env->FindClass("io/smartface/ExposingEngine/ExchangeValue");

			params[0].l = JsJavaInterface::ConvertToJavaType(__smf_info__[0], v8Context, __smf_info__.GetIsolate());
			params[1].l = id;
			SpDynamicObjectRef::jsValueToJava(SpJsFunctionArguments[1], smfObjType.c_str(), &params[2]);
			SpDynamicObjectRef::jsValueToJava(SpJsFunctionArguments[2], smfObjType.c_str(), &params[3]);
			jobjectArray parameterArray = nullptr;
			if (__smf_info__[3]->IsArray()) {
				v8::Array* array = v8::Array::Cast(*__smf_info__[3]);
				parameterArray = env->NewObjectArray(array->Length(), ExchangeValue, NULL);
				for (int i = 0; i < array->Length(); ++i) {
					v8::Local<v8::Value> value = array->Get(v8Context, i).ToLocalChecked();
					if (!value->IsNull() && !value->IsUndefined()) {
						env->SetObjectArrayElement (parameterArray, i, JsJavaInterface::ConvertToJavaType(value, v8Context, __smf_info__.GetIsolate()));
					}
				}

			}
			params[4].l = parameterArray;

			jclass clazz = env->FindClass("io/smartface/ExposingEngine/JsClassProxyOperations");
			if (clazz) {
				jmethodID methodId = env->GetStaticMethodID(clazz,
															"generateExtendingProxyInstance",
															"(Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/ExposingEngine/ExchangeValue;Lio/smartface/plugin/SMFJSObject;Lio/smartface/plugin/SMFJSObject;[Lio/smartface/ExposingEngine/ExchangeValue;)Lio/smartface/ExposingEngine/ExchangeValue;");
				if (methodId != 0) {
					jobject result = env->CallStaticObjectMethodA(clazz, methodId, params);
					if (result == NULL) {
						__smf_info__.GetReturnValue().SetNull();
					} else {
						__smf_info__.GetReturnValue().Set(JsJavaInterface::ConvertToJSType(result, v8Context, __smf_info__.GetIsolate()));
					}
					env->PopLocalFrame(NULL);
					return;
				}
			}
			jboolean exceptionThrown = env->ExceptionCheck();

			if (exceptionThrown) {
				jthrowable e = env->ExceptionOccurred();
				env->ExceptionDescribe();
				env->ExceptionClear();

				env->DeleteLocalRef(clazz);
				env->DeleteLocalRef(e);
			}
			env->PopLocalFrame(NULL);
		} else {
			env->PopLocalFrame(NULL);
		}
	}
	
	__smf_info__.GetReturnValue().SetNull();
}

/**
 * V8 callback for requireClass function that is exposed to global scope. Asks JsClassManagerBridge
 * to give a JavaScript represantation of required Java class. Returns undefined if class not found
 * or arguments are incompatible.
 */
void cb_requireClass(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() < 1 || !info[0]->IsString()) {
		info.GetReturnValue().SetUndefined();
		return;
	}
	
	v8::String::Utf8Value utf8Parameter(info[0]);
	std::string requiredClass(*utf8Parameter);
	v8::Local<v8::Value> result = JsJavaInterface::RequireClass(requiredClass);
	info.GetReturnValue().Set(result);
}

template<typename T>
void cb_numberConverter(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}

	v8::Isolate* isolate = info.GetIsolate();
  	v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);
	
	if (info[0]->IsNumber()) {
	 	info.GetReturnValue().Set(JsObjectConverter::ConvertToJava<T>(context, isolate, info[0]));
	}
}

void cb_int(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<int>(info);
}

void cb_double(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<double>(info);
}

void cb_float(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<float>(info);
}

void cb_long(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<long>(info);
}

void cb_short(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<short>(info);
}

void cb_byte(const v8::FunctionCallbackInfo<v8::Value>& info) {
	cb_numberConverter<jbyte>(info);
}

void cb_bool(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}

	v8::Isolate* isolate = info.GetIsolate();
  v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);

	info.GetReturnValue().Set(JsObjectConverter::ConvertToJava<bool>(context, isolate, info[0]));
}

void cb_char(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}

	v8::Isolate* isolate = info.GetIsolate();
	v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);
	
	info.GetReturnValue().Set(JsObjectConverter::ConvertToJava<char>(context, isolate, info[0]));
}

void cb_string(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}

	info.GetReturnValue().Set(info[0]);
}

void cb_array(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}

	v8::Isolate* isolate = info.GetIsolate();
	v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);

	if (info[0]->IsArray()) {
		if (info.Length() == 1) {
			info.GetReturnValue().Set(JsObjectConverter::ConvertToJava<jobjectArray>(context, isolate, info[0]));
		} else {
			v8::String::Utf8Value utf8ClassName(info[1]);
			std::string classNameStr (*utf8ClassName);
			if (classNameStr == "byte") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jbyteArray>(context, isolate, info[0]));
			} else if (classNameStr == "short") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jshortArray>(context, isolate, info[0]));
			} else if (classNameStr == "int") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jintArray>(context, isolate, info[0]));
			} else if (classNameStr == "float") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jfloatArray>(context, isolate, info[0]));
			} else if (classNameStr == "double") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jdoubleArray>(context, isolate, info[0]));
			} else if (classNameStr == "long") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jlongArray>(context, isolate, info[0]));
			} else if (classNameStr == "boolean") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jbooleanArray>(context, isolate, info[0]));
			} else if (classNameStr == "java.lang.String") {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<std::string>(context, isolate, info[0]));
			} else {
				info.GetReturnValue().Set(
					JsObjectConverter::ConvertToJava<jobjectArray>(context, isolate, info[0],
																   info[1]));
			}
		}
	}
}

void cb_arrayLength(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}
	
	v8::Isolate* isolate = info.GetIsolate();
	v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);

	JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
	int objectId = JsJavaInterface::ExtractJavaIdentifier(context, info[0]);
	if (objectId == -1) info.GetReturnValue().SetUndefined();
  
	jclass clazz = jniEnv->FindClass("io/smartface/ExposingEngine/JsObjectCollection");
	if(clazz) {
		jmethodID methodId = jniEnv->GetStaticMethodID(clazz, "getExchangeValue", "(I)Ljava/lang/Object;");
		if (methodId != 0) {
			jobject object = jniEnv->CallStaticObjectMethod(clazz, methodId, objectId);

			if(object != NULL) {
				clazz = jniEnv->FindClass("io/smartface/ExposingEngine/ExchangeValue");
				jfieldID arrayLengthID = jniEnv->GetFieldID(clazz, "arrayLength", "I");
				
				if(arrayLengthID != 0) {
					int length = jniEnv->GetIntField(object, arrayLengthID);
					if(length >= 0) {
						info.GetReturnValue().Set(v8::Number::New(isolate, length));
						return;
					}
				}
			}
		} 
	} 

	info.GetReturnValue().SetUndefined();
}

void cb_toJSArray(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) {
		info.GetReturnValue().SetUndefined();
		return;
	}
	
	v8::Isolate* isolate = info.GetIsolate();
	v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);

	JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
	int objectId = JsJavaInterface::ExtractJavaIdentifier(context, info[0]);
	if (objectId == -1) info.GetReturnValue().Set(v8::Null(isolate));
  
	jclass clazz = jniEnv->FindClass("io/smartface/ExposingEngine/JsObjectCollection");
	if(clazz) {
		jmethodID methodId = jniEnv->GetStaticMethodID(clazz, "getExchangeValue", "(I)Ljava/lang/Object;");
		
		if (methodId != 0) {
			jobject object = jniEnv->CallStaticObjectMethod(clazz, methodId, objectId);
			if(object == NULL) {
				info.GetReturnValue().SetUndefined();
				return;
			}
			info.GetReturnValue().Set(JsJavaInterface::ConvertToJSArray(object, context, isolate));
			return;
		}
	}

	info.GetReturnValue().SetUndefined();
}

void cb_delete(const v8::FunctionCallbackInfo<v8::Value>& info) {
	if (info.Length() == 0) return;
	if (!info[0]->IsObject()) return;

	v8::Local<v8::Context> context = smf_v8_global_context.Get(info.GetIsolate());
	v8::Local<v8::Object> object = info[0]->ToObject(context).ToLocalChecked();
	JsJavaInterface::DeleteJavaObject(object);
}