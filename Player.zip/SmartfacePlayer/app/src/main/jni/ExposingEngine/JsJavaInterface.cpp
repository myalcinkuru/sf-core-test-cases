#include "ExposingEngine/JsJavaInterface.h"
#include "ExposingEngine/SpJSFunctionsPlugins.h"
#include "NfProfiler.hpp"
#include "Core/SpLog.h"
#include "ExposingEngine/JsObjectConverter.h"
#include "Core/SpContext.h"
#include "v8.h"
#include "ExposingEngine/SpDynamicObjectRef.h"

JNIEnv* JsJavaInterface::jniEnv;

jclass JsJavaInterface::JsObjectCollection;
jmethodID JsJavaInterface::AddMethodID;
jmethodID JsJavaInterface::RemoveMethodID;

jclass JsJavaInterface::JavaJsInterface;
jmethodID JsJavaInterface::RequireClassMethodID;
jmethodID JsJavaInterface::ConstructObjectMethodID;
jmethodID JsJavaInterface::GetPropertyMethodID;
jmethodID JsJavaInterface::SetPropertyMethodID;
jmethodID JsJavaInterface::InvokeMethodMethodID;
jmethodID JsJavaInterface::GetMessageMethodID;

jclass JsJavaInterface::ExchangeValue;
jmethodID JsJavaInterface::ExchangeValueConstructorMethodID;
jmethodID JsJavaInterface::GetElementIdByIndexMethodID;
jfieldID JsJavaInterface::ByteValueFieldID;
jfieldID JsJavaInterface::ShortValueFieldID;
jfieldID JsJavaInterface::IntValueFieldID;
jfieldID JsJavaInterface::FloatValueFieldID;
jfieldID JsJavaInterface::DoubleValueFieldID;
jfieldID JsJavaInterface::LongValueFieldID;
jfieldID JsJavaInterface::BooleanValueFieldID;
jfieldID JsJavaInterface::ObjectIdFieldID;
jfieldID JsJavaInterface::ByteArrayFieldID;
jfieldID JsJavaInterface::ShortArrayFieldID;
jfieldID JsJavaInterface::IntArrayFieldID;
jfieldID JsJavaInterface::FloatArrayFieldID;
jfieldID JsJavaInterface::DoubleArrayFieldID;
jfieldID JsJavaInterface::LongArrayFieldID;
jfieldID JsJavaInterface::BooleanArrayFieldID;
jfieldID JsJavaInterface::StringValueFieldID;
jfieldID JsJavaInterface::StringArrayFieldID;
jfieldID JsJavaInterface::ObjectArrayFieldID;
jfieldID JsJavaInterface::TypeFieldID;

std::map<std::string, v8::Global<v8::Value>> JsJavaInterface::classCache;
v8::Global<v8::ObjectTemplate> JsJavaInterface::classTemplate;
bool JsJavaInterface::initializedTemplate;

extern v8::Persistent<v8::Context> smf_v8_global_context;

jobject JsJavaInterface::ConvertToJavaType(v8::Local<v8::Value> value, v8::Local<v8::Context> context, v8::Isolate* isolate) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  if (value->IsObject()) {
    v8::Local<v8::Object> object = value->ToObject(context).ToLocalChecked();
    if (object->InternalFieldCount() > 0) {
      v8::Local<v8::External> internal = v8::Local<v8::External>::Cast(object->GetInternalField(0));
      int objectId = (uintptr_t)internal->Value();
      jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
      jniEnv->SetIntField(exchangeValue, ObjectIdFieldID, objectId);
      return exchangeValue;
    } else {
      jvalue param;
      SpJsValue argValue;
      argValue->Reset(isolate, object);
      SpDynamicObjectRef::jsValueToJava(argValue, "Lio/smartface/plugin/SMFJSObject;", &param);
      if (param.l) {
        int objectId = jniEnv->CallStaticIntMethod(JsObjectCollection, AddMethodID, param.l);
        jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
        jniEnv->SetIntField(exchangeValue, ObjectIdFieldID, objectId);
        return exchangeValue;
      }
    }
  } else if (value->IsBoolean()) {
    jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
    jniEnv->SetBooleanField(exchangeValue, BooleanValueFieldID, v8::Boolean::Cast(*value)->Value());
    jniEnv->SetIntField(exchangeValue, TypeFieldID, EXCHANGEVALUE_TYPE_BOOLEAN);
    return exchangeValue;
  } else if (value->IsString()) {
    jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
    v8::String::Utf8Value utf8Parameter(value);
    std::string value(*utf8Parameter);
    jstring stringValue = jniEnv->NewStringUTF(value.c_str());
    jniEnv->SetObjectField(exchangeValue, StringValueFieldID, stringValue);
    jniEnv->SetIntField(exchangeValue, TypeFieldID, EXCHANGEVALUE_TYPE_STRING);
    jniEnv->DeleteLocalRef(stringValue);
    return exchangeValue;
  } else if (value->IsNumber()) {
    double doubleValue = value->ToNumber(context).ToLocalChecked()->Value();
    if ((doubleValue - ((int)doubleValue)) == 0) {
      jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
      jniEnv->SetIntField(exchangeValue, IntValueFieldID, (int)doubleValue);
      jniEnv->SetIntField(exchangeValue, TypeFieldID, EXCHANGEVALUE_TYPE_INT);
      return exchangeValue;
    } else {
      jobject exchangeValue = jniEnv->NewObject(ExchangeValue, ExchangeValueConstructorMethodID);
      jniEnv->SetFloatField(exchangeValue, FloatValueFieldID, (float)doubleValue);
      jniEnv->SetIntField(exchangeValue, TypeFieldID, EXCHANGEVALUE_TYPE_FLOAT);
      return exchangeValue;
    }
  }

  return NULL;
}

v8::Local<v8::Value> JsJavaInterface::ConvertToJSArray(jobject object, v8::Local<v8::Context> context, v8::Isolate* isolate) {
  if (object == NULL) return v8::Undefined(isolate);

  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  int type = jniEnv->GetIntField(object, TypeFieldID);
  switch (type) {
    case EXCHANGEVALUE_TYPE_BYTEARRAY: {
      jbyteArray byteArray = (jbyteArray) jniEnv->GetObjectField(object, ByteArrayFieldID);
      int length = jniEnv->GetArrayLength(byteArray);
      jbyte* nativeArray = jniEnv->GetByteArrayElements(byteArray, NULL);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jsArray->Set(context, i, v8::Number::New(isolate, nativeArray[i]));
      }

      jniEnv->ReleaseByteArrayElements(byteArray, nativeArray, JNI_ABORT);
      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_SHORTARRAY: {
      jshortArray shortArray = (jshortArray) jniEnv->GetObjectField(object, ShortArrayFieldID);
      int length = jniEnv->GetArrayLength(shortArray);
      jshort* nativeArray = jniEnv->GetShortArrayElements(shortArray, NULL);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jsArray->Set(context, i, v8::Number::New(isolate, nativeArray[i]));
      }

      jniEnv->ReleaseShortArrayElements(shortArray, nativeArray, JNI_ABORT);
      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_INTARRAY: {
      jintArray intArray = (jintArray) jniEnv->GetObjectField(object, IntArrayFieldID);
      int length = jniEnv->GetArrayLength(intArray);
      jint* nativeArray = jniEnv->GetIntArrayElements(intArray, NULL);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jsArray->Set(context, i, v8::Number::New(isolate, nativeArray[i]));
      }

      jniEnv->ReleaseIntArrayElements(intArray, nativeArray, JNI_ABORT);
      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_FLOATARRAY: {
      jfloatArray floatArray = (jfloatArray) jniEnv->GetObjectField(object, FloatArrayFieldID);
      int length = jniEnv->GetArrayLength(floatArray);
      jfloat* nativeArray = jniEnv->GetFloatArrayElements(floatArray, NULL);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jsArray->Set(context, i, v8::Number::New(isolate, nativeArray[i]));
      }

      jniEnv->ReleaseFloatArrayElements(floatArray, nativeArray, JNI_ABORT);
      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_DOUBLEARRAY: {
      jdoubleArray doubleArray = (jdoubleArray) jniEnv->GetObjectField(object, DoubleArrayFieldID);
      int length = jniEnv->GetArrayLength(doubleArray);
      jdouble* nativeArray = jniEnv->GetDoubleArrayElements(doubleArray, NULL);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jsArray->Set(context, i, v8::Number::New(isolate, nativeArray[i]));
      }

      jniEnv->ReleaseDoubleArrayElements(doubleArray, nativeArray, JNI_ABORT);
      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_STRINGARRAY: {
      jobjectArray stringArray = (jobjectArray) jniEnv->GetObjectField(object, StringArrayFieldID);
      int length = jniEnv->GetArrayLength(stringArray);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jstring nativeString = (jstring) jniEnv->GetObjectArrayElement(stringArray, i); 
        const char* stringValue = jniEnv->GetStringUTFChars(nativeString, NULL);     
        v8::Local<v8::Value> jsStringValue = v8::String::NewFromUtf8(isolate, stringValue);  
        jsArray->Set(context, i, jsStringValue);
        jniEnv->ReleaseStringUTFChars(nativeString, stringValue);
        jniEnv->DeleteLocalRef(nativeString);
      }

      return jsArray;
    }
    case EXCHANGEVALUE_TYPE_OBJECTARRAY: {
      jobjectArray objectArray = (jobjectArray) jniEnv->GetObjectField(object, ObjectArrayFieldID);
      if(objectArray == NULL) 
        return v8::Null(isolate);
      int length = jniEnv->GetArrayLength(objectArray);

      v8::Local<v8::Array> jsArray = v8::Array::New(isolate, length);
      for (int i = 0; i < length; i++) {
        jint jval = (jint) jniEnv->CallIntMethod(object, GetElementIdByIndexMethodID, (jint) i);  
        v8::Local<v8::Object> element = CreateJavaScriptObject((int) jval);
        jsArray->Set(context, i, element);
      }

      return jsArray;
    }
  }

  return v8::Number::New(isolate, type);
}

v8::Local<v8::Value> JsJavaInterface::ConvertToJSType(jobject object, v8::Local<v8::Context> context, v8::Isolate* isolate) {
  if (object == NULL) return v8::Undefined(isolate);

  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  int type = jniEnv->GetIntField(object, TypeFieldID);
  switch (type) {
    case EXCHANGEVALUE_TYPE_OBJECT: {
      int objectId = jniEnv->GetIntField(object, ObjectIdFieldID);
      return CreateJavaScriptObject(objectId);
    }
    case EXCHANGEVALUE_TYPE_STRING: {
      jstring value = (jstring) jniEnv->GetObjectField(object, StringValueFieldID);
      const char* stringValue = jniEnv->GetStringUTFChars(value, NULL);
      v8::Local<v8::Value> jsStringValue = v8::String::NewFromUtf8(isolate, stringValue);
      jniEnv->ReleaseStringUTFChars(value, stringValue);
      jniEnv->DeleteLocalRef(value);
      return jsStringValue;
    }
    case EXCHANGEVALUE_TYPE_INT: {
      int value = jniEnv->GetIntField(object, IntValueFieldID);
      return v8::Number::New(isolate, value);
    }
    case EXCHANGEVALUE_TYPE_DOUBLE: {
      float value = jniEnv->GetDoubleField(object, DoubleValueFieldID);
      return v8::Number::New(isolate, value);
    }
    case EXCHANGEVALUE_TYPE_LONG: {
      float value = jniEnv->GetLongField(object, LongValueFieldID);
      return v8::Number::New(isolate, value);
    }
    case EXCHANGEVALUE_TYPE_FLOAT: {
      float value = jniEnv->GetFloatField(object, FloatValueFieldID);
      return v8::Number::New(isolate, value);
    }
    case EXCHANGEVALUE_TYPE_BOOLEAN: {
      bool value = jniEnv->GetBooleanField(object, BooleanValueFieldID);
      return v8::Boolean::New(isolate, value);
    }
    case EXCHANGEVALUE_TYPE_BYTEARRAY:
    case EXCHANGEVALUE_TYPE_SHORTARRAY: 
    case EXCHANGEVALUE_TYPE_INTARRAY: 
    case EXCHANGEVALUE_TYPE_FLOATARRAY:
    case EXCHANGEVALUE_TYPE_DOUBLEARRAY: 
    case EXCHANGEVALUE_TYPE_OBJECTARRAY:
    case EXCHANGEVALUE_TYPE_STRINGARRAY:  {
      int objectId = jniEnv->GetIntField(object, ObjectIdFieldID);
      return CreateJavaScriptObject(objectId);
    }
  }

  return v8::Undefined(isolate);
}

void JsJavaInterface::Initialize(JNIEnv* env) {
  jniEnv = env;

  JavaJsInterface = (jclass) jniEnv->NewGlobalRef(jniEnv->FindClass("io/smartface/ExposingEngine/JavaJsInterface"));

  RequireClassMethodID = jniEnv->GetStaticMethodID(JavaJsInterface, "RequireClass", "(Ljava/lang/String;)Lio/smartface/ExposingEngine/ExchangeValue;");
  ConstructObjectMethodID = jniEnv->GetStaticMethodID(JavaJsInterface, "ConstructObject", "(Lio/smartface/ExposingEngine/ExchangeValue;[Lio/smartface/ExposingEngine/ExchangeValue;)Lio/smartface/ExposingEngine/ExchangeValue;");
  GetPropertyMethodID = jniEnv->GetStaticMethodID(JavaJsInterface, "GetProperty", "(Lio/smartface/ExposingEngine/ExchangeValue;Ljava/lang/String;)Lio/smartface/ExposingEngine/ExchangeValue;");
  SetPropertyMethodID = jniEnv->GetStaticMethodID(JavaJsInterface, "SetProperty", "(Lio/smartface/ExposingEngine/ExchangeValue;Ljava/lang/String;Lio/smartface/ExposingEngine/ExchangeValue;)Z");
  InvokeMethodMethodID = jniEnv->GetStaticMethodID(JavaJsInterface, "InvokeMethod", "(Lio/smartface/ExposingEngine/ExchangeValue;[Lio/smartface/ExposingEngine/ExchangeValue;)Lio/smartface/ExposingEngine/ExchangeValue;");

  ExchangeValue = (jclass) jniEnv->NewGlobalRef(jniEnv->FindClass("io/smartface/ExposingEngine/ExchangeValue"));
  ExchangeValueConstructorMethodID = jniEnv->GetMethodID(ExchangeValue, "<init>", "()V");
  GetElementIdByIndexMethodID = jniEnv->GetMethodID(ExchangeValue, "GetElementIdByIndex", "(I)I");
  ByteValueFieldID = jniEnv->GetFieldID(ExchangeValue, "byteValue", "B");
  ShortValueFieldID = jniEnv->GetFieldID(ExchangeValue, "shortValue", "S");
  IntValueFieldID = jniEnv->GetFieldID(ExchangeValue, "intValue", "I");
  FloatValueFieldID = jniEnv->GetFieldID(ExchangeValue, "floatValue", "F");
  DoubleValueFieldID = jniEnv->GetFieldID(ExchangeValue, "doubleValue", "D");
  LongValueFieldID = jniEnv->GetFieldID(ExchangeValue, "longValue", "J");
  BooleanValueFieldID = jniEnv->GetFieldID(ExchangeValue, "booleanValue", "Z");
  StringValueFieldID = jniEnv->GetFieldID(ExchangeValue, "stringValue", "Ljava/lang/String;");
  ObjectIdFieldID = jniEnv->GetFieldID(ExchangeValue, "objectId", "I");
  ByteArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "byteArray", "[B");
  ShortArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "shortArray", "[S");
  IntArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "intArray", "[I");
  FloatArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "floatArray", "[F");
  DoubleArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "doubleArray", "[D");
  LongArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "longArray", "[J");
  BooleanArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "booleanArray", "[Z");
  StringArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "stringArray", "[Ljava/lang/String;");
  ObjectArrayFieldID = jniEnv->GetFieldID(ExchangeValue, "objectArray", "[Ljava/lang/Object;");
  TypeFieldID = jniEnv->GetFieldID(ExchangeValue, "type", "I");

  JsObjectCollection = (jclass) jniEnv->NewGlobalRef(jniEnv->FindClass("io/smartface/ExposingEngine/JsObjectCollection"));
  AddMethodID = jniEnv->GetStaticMethodID(JsObjectCollection, "add", "(Ljava/lang/Object;)I");
  RemoveMethodID = jniEnv->GetStaticMethodID(JsObjectCollection, "remove", "(I)V");

  jclass ThrowableClass = (jclass) jniEnv->FindClass("java/lang/Throwable");
  GetMessageMethodID = jniEnv->GetMethodID(ThrowableClass, "getMessage", "()Ljava/lang/String;");

  classCache.clear();
}

v8::Local<v8::Value> JsJavaInterface::RequireClass(const std::string& name) {
  // NfProfiler profiler("RequireClass");
  v8::Isolate* isolate = v8::Isolate::GetCurrent();
  if (!initializedTemplate) CreateClassTemplate(isolate);

  // If found in cache return result
  if (classCache.find(name) != classCache.end()) {
    v8::Local<v8::Value> jsClass = classCache[name].Get(isolate);
    return jsClass;
  }

  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  // Ask runtime to check if class exists
  jstring jClassName = jniEnv->NewStringUTF(name.c_str());
  jobject result = jniEnv->CallStaticObjectMethod(JavaJsInterface, RequireClassMethodID, jClassName);
  jniEnv->DeleteLocalRef(jClassName);
  if (result == NULL) return v8::Undefined(isolate);

  jthrowable exception = jniEnv->ExceptionOccurred();
  if (exception != NULL) {
    jniEnv->ExceptionDescribe();
    jniEnv->ExceptionClear();
    jstring exceptionMessage = (jstring) jniEnv->CallObjectMethod(exception, GetMessageMethodID);
    if (exceptionMessage != NULL) {
      const char* exceptionMessageStr = jniEnv->GetStringUTFChars(exceptionMessage, NULL);
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, exceptionMessageStr)));
      jniEnv->ReleaseStringUTFChars(exceptionMessage, exceptionMessageStr);
      jniEnv->DeleteLocalRef(exceptionMessage);
    } else {
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, "An exception occured")));
    }
  }

  // Save class in cache and return
  int id = jniEnv->GetIntField(result, ObjectIdFieldID);
  jniEnv->DeleteLocalRef(result);
  v8::Local<v8::Object> jsClass = CreateJavaScriptObject(id);
  classCache[name] = v8::Global<v8::Value>(isolate, jsClass);
  return jsClass;
}

void JsJavaInterface::ConstructorCallback(const v8::FunctionCallbackInfo<v8::Value>& info) {
  if (!info.IsConstructCall()) {
    InvokeMethod(info);
    return;
  }
  // NfProfiler profiler("ConstructorCallback");

  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Isolate* isolate = info.GetIsolate();
  v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);
  jobjectArray parametersArray = jniEnv->NewObjectArray(info.Length(), ExchangeValue, NULL);

  for (int i = 0; i < info.Length(); i++) {
    jobject parameter = ConvertToJavaType(info[i], context, isolate);
    jniEnv->SetObjectArrayElement(parametersArray, i, parameter);
    jniEnv->DeleteLocalRef(parameter);
  }

  v8::Local<v8::External> internal = v8::Local<v8::External>::Cast(info.Holder()->GetInternalField(0));
  jobject id = ConvertToJavaType(info.This(), context, isolate);
  jobject result = jniEnv->CallStaticObjectMethod(JavaJsInterface, ConstructObjectMethodID, id, parametersArray);

  jniEnv->DeleteLocalRef(id);
  jniEnv->DeleteLocalRef(parametersArray);
  
  jthrowable exception = jniEnv->ExceptionOccurred();
  if (exception != NULL) {
    jniEnv->ExceptionDescribe();
    jniEnv->ExceptionClear();
    jstring exceptionMessage = (jstring) jniEnv->CallObjectMethod(exception, GetMessageMethodID);
    if (exceptionMessage != NULL) {
      const char* exceptionMessageStr = jniEnv->GetStringUTFChars(exceptionMessage, NULL);
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, exceptionMessageStr)));
      jniEnv->ReleaseStringUTFChars(exceptionMessage, exceptionMessageStr);
      jniEnv->DeleteLocalRef(exceptionMessage);
    } else {
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, "An exception occured")));
    }

    return;
  }

  if (result != NULL) {
    int resultId = jniEnv->GetIntField(result, ObjectIdFieldID);
    jniEnv->DeleteLocalRef(result);
    if(resultId >= 0) {
      info.GetReturnValue().Set(CreateJavaScriptObject(resultId));
    } else {
      info.GetReturnValue().Set(v8::Null(isolate));
    }
  }
}

void JsJavaInterface::GetPropertyCallback(v8::Local<v8::Name> property,
                                          const v8::PropertyCallbackInfo<v8::Value>& info) {
  // NfProfiler profiler("GetPropertyCallback");
  if(property->IsSymbol()) {
    info.GetReturnValue().SetUndefined();
    return;
  }

  // Call runtime to get field of the class
  v8::String::Utf8Value utf8Value(property);
  std::string propertyName(*utf8Value);
  v8::Isolate* isolate = info.GetIsolate();

  if (propertyName == "implement") {
    info.GetReturnValue().Set(v8::Function::New(smf_v8_global_context.Get(isolate), cb_implement).ToLocalChecked());
    return;
  }

  if (propertyName == "extend") {
    info.GetReturnValue().Set(v8::Function::New(smf_v8_global_context.Get(isolate), cb_extend).ToLocalChecked());
    return;
  }

  jobject id = ConvertToJavaType(info.This(), smf_v8_global_context.Get(isolate), isolate);

  if (propertyName == "valueOf") {
    info.GetReturnValue().Set(v8::Number::New(isolate, 10));
    return;
  }

  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  jstring jProperty = jniEnv->NewStringUTF(propertyName.c_str());
  jobject result = jniEnv->CallStaticObjectMethod(JavaJsInterface, GetPropertyMethodID, id, jProperty);
  jniEnv->DeleteLocalRef(jProperty);
  jniEnv->DeleteLocalRef(id);

  jthrowable exception = jniEnv->ExceptionOccurred();
  if (exception != NULL) {
    jniEnv->ExceptionDescribe();
    jniEnv->ExceptionClear();
    jstring exceptionMessage = (jstring) jniEnv->CallObjectMethod(exception, GetMessageMethodID);
    if (exceptionMessage != NULL) {
      const char* exceptionMessageStr = jniEnv->GetStringUTFChars(exceptionMessage, NULL);
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, exceptionMessageStr)));
      jniEnv->ReleaseStringUTFChars(exceptionMessage, exceptionMessageStr);
      jniEnv->DeleteLocalRef(exceptionMessage);
    } else {
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, "An exception occured")));
    }
  }

  // Return JavaScript representation of result
  if (result != NULL) {
    v8::Local<v8::Value> returnValue = ConvertToJSType(result, smf_v8_global_context.Get(isolate), isolate);
    jniEnv->DeleteLocalRef(result);
    info.GetReturnValue().Set(returnValue);
  }
}

void JsJavaInterface::SetPropertyCallback(v8::Local<v8::Name> property,
                                          v8::Local<v8::Value> value,
                                          const v8::PropertyCallbackInfo<v8::Value>& info) {
  // NfProfiler profiler("SetPropertyCallback");
  v8::Isolate* isolate = info.GetIsolate();
  v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
                                      
  jobject valueId = ConvertToJavaType(value, context, isolate);

  // Call runtime to get field of the class
  v8::String::Utf8Value utf8Value(property);
  jstring jProperty = jniEnv->NewStringUTF(*utf8Value);
  jobject id = ConvertToJavaType(info.This(), context, isolate);
  bool result = (bool) jniEnv->CallStaticBooleanMethod(JavaJsInterface, SetPropertyMethodID, id, jProperty, valueId);
  jniEnv->DeleteLocalRef(jProperty);
  jniEnv->DeleteLocalRef(valueId);
  jniEnv->DeleteLocalRef(id);

  jthrowable exception = jniEnv->ExceptionOccurred();
  if (exception != NULL) {
    jniEnv->ExceptionDescribe();
    jniEnv->ExceptionClear();
    jstring exceptionMessage = (jstring) jniEnv->CallObjectMethod(exception, GetMessageMethodID);
    if (exceptionMessage != NULL) {
      const char* exceptionMessageStr = jniEnv->GetStringUTFChars(exceptionMessage, NULL);
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, exceptionMessageStr)));
      jniEnv->ReleaseStringUTFChars(exceptionMessage, exceptionMessageStr);
      jniEnv->DeleteLocalRef(exceptionMessage);
    } else {
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, "An exception occured")));
    }
    return;
  }
}

void JsJavaInterface::InvokeMethod(const v8::FunctionCallbackInfo<v8::Value>& info) {
  // NfProfiler profiler("InvokeMethod");
  v8::Isolate* isolate = info.GetIsolate();
  v8::Local<v8::Context> context = smf_v8_global_context.Get(isolate);
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();

  jobjectArray parametersArray = jniEnv->NewObjectArray(info.Length(), ExchangeValue, NULL);
  for (int i = 0; i < info.Length(); i++) {
    jobject parameter = ConvertToJavaType(info[i], context, isolate);
    jniEnv->SetObjectArrayElement(parametersArray, i, parameter);
    jniEnv->DeleteLocalRef(parameter);
  }

  jobject id = ConvertToJavaType(info.Holder(), context, isolate);
  jobject result = jniEnv->CallStaticObjectMethod(JavaJsInterface, InvokeMethodMethodID, id, parametersArray);
  jniEnv->DeleteLocalRef(parametersArray);
  jniEnv->DeleteLocalRef(id);

  jthrowable exception = jniEnv->ExceptionOccurred();
  if (exception != NULL) {
    jniEnv->ExceptionDescribe();
    jniEnv->ExceptionClear();
    jstring exceptionMessage = (jstring) jniEnv->CallObjectMethod(exception, GetMessageMethodID);
    if (exceptionMessage != NULL) {
      const char* exceptionMessageStr = jniEnv->GetStringUTFChars(exceptionMessage, NULL);
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, exceptionMessageStr)));
      jniEnv->ReleaseStringUTFChars(exceptionMessage, exceptionMessageStr);
      jniEnv->DeleteLocalRef(exceptionMessage);
    } else {
      isolate->ThrowException(v8::Exception::Error(v8::String::NewFromUtf8(isolate, "An exception occured")));
    }
  }

  if (result != NULL) {
    v8::Local<v8::Value> returnValue = ConvertToJSType(result, context, isolate);
    jniEnv->DeleteLocalRef(result);
    info.GetReturnValue().Set(returnValue);
  }
}


v8::Local<v8::Object> JsJavaInterface::CreateJavaScriptObject(int id) {
  v8::Isolate* isolate = v8::Isolate::GetCurrent();
  v8::Local<v8::Object> jsClass = classTemplate.Get(isolate)->NewInstance();

  jsClass->SetInternalField(0, v8::External::New(isolate, (void*) ((uintptr_t) id)));
  return jsClass;
}

int JsJavaInterface::ExtractJavaIdentifier(v8::Local<v8::Context> context, v8::Local<v8::Value> jsObject) {
  if (!jsObject->IsObject()) {
    return -1;
  }

  v8::Local<v8::Object> object = jsObject->ToObject(context).ToLocalChecked();
  if (object->InternalFieldCount() == 0) return -1;
  return ExtractJavaIdentifier(object);
}

int JsJavaInterface::ExtractJavaIdentifier(v8::Local<v8::Object> jsObject) {
  v8::Local<v8::External> internal = v8::Local<v8::External>::Cast(jsObject->GetInternalField(0));
  return (int) ((uintptr_t) internal->Value());
}

void JsJavaInterface::DeleteJavaObject(v8::Local<v8::Object> jsObject) {
  int id = ExtractJavaIdentifier(jsObject);
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jniEnv->CallStaticVoidMethod(JsObjectCollection, RemoveMethodID, id);
}

void JsJavaInterface::CreateClassTemplate(v8::Isolate* isolate) {
  v8::Local<v8::ObjectTemplate> localTemplate = v8::ObjectTemplate::New(isolate);
  localTemplate->SetInternalFieldCount(1);
  localTemplate->SetCallAsFunctionHandler(JsJavaInterface::ConstructorCallback);
  localTemplate->SetHandler(v8::NamedPropertyHandlerConfiguration(
    JsJavaInterface::GetPropertyCallback,
    JsJavaInterface::SetPropertyCallback
  ));

  classTemplate = v8::Global<v8::ObjectTemplate>(isolate, localTemplate);
  initializedTemplate = true;
}