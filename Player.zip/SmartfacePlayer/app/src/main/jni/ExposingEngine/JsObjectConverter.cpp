#include "ExposingEngine/JsJavaInterface.h"
#include "ExposingEngine/JsObjectConverter.h"

#include "Core/SpLog.h"
#include "Core/SpContext.h"

JNIEnv* JsObjectConverter::jniEnv = nullptr;

jclass JsObjectConverter::jObjectConversions = nullptr;

jmethodID JsObjectConverter::ToPrimitiveStringMethodId = nullptr;
jmethodID JsObjectConverter::ToIntegerMethodId = nullptr;
jmethodID JsObjectConverter::ToDoubleMethodId = nullptr;
jmethodID JsObjectConverter::ToFloatMethodId = nullptr;
jmethodID JsObjectConverter::ToLongMethodId = nullptr;
jmethodID JsObjectConverter::ToShortMethodId = nullptr;
jmethodID JsObjectConverter::ToBooleanMethodId = nullptr;
jmethodID JsObjectConverter::ToCharacterMethodId = nullptr;
jmethodID JsObjectConverter::ToStringMethodId = nullptr;
jmethodID JsObjectConverter::ToArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToByteArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToShortArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToIntArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToFloatArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToDoubleArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToLongArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToBooleanArrayMethodId = nullptr;
jmethodID JsObjectConverter::ToStringArrayMethodId = nullptr;

void CheckExceptionAndClear(JNIEnv* env) {
  env->ExceptionClear();
}

void JsObjectConverter::Initialize(JNIEnv* env) {
  jniEnv = env;

  jObjectConversions = (jclass) jniEnv->NewGlobalRef(jniEnv->FindClass("io/smartface/ExposingEngine/JsObjectConversions"));

  ToPrimitiveStringMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToPrimitiveString", "(I)Ljava/lang/String;");

  ToIntegerMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToInteger", "(I)I");
  ToDoubleMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToDouble", "(D)I");
  ToFloatMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToFloat", "(F)I");
  ToLongMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToLong", "(J)I");
  ToShortMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToShort", "(S)I");
  ToBooleanMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToBoolean", "(Z)I");
  ToCharacterMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToCharacter", "(C)I");
  ToStringMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToString", "(Ljava/lang/String;)I");
  ToArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToArray", "([ILjava/lang/String;)I");
  ToByteArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToByteArray", "([B)I");
  ToShortArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToShortArray", "([S)I");
  ToIntArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToIntArray", "([I)I");
  ToFloatArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToFloatArray", "([F)I");
  ToDoubleArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToDoubleArray", "([D)I");
  ToLongArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToLongArray", "([J)I");
  ToBooleanArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToBooleanArray", "([Z)I");
  ToStringArrayMethodId = jniEnv->GetStaticMethodID(jObjectConversions, "ToStringArray", "([Ljava/lang/String;)I");
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJs<std::string>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  int objectId = JsJavaInterface::ExtractJavaIdentifier(context, jsValue);
  if (objectId == -1) return v8::Null(isolate);

  jstring value = (jstring) jniEnv->CallStaticObjectMethod(jObjectConversions, ToPrimitiveStringMethodId, objectId);
  CheckExceptionAndClear(jniEnv);
  const char* valueAsChars = jniEnv->GetStringUTFChars(value, JNI_FALSE);
  v8::Local<v8::Value> result = v8::String::NewFromUtf8(isolate, valueAsChars);
  jniEnv->ReleaseStringUTFChars(value, valueAsChars);
  jniEnv->DeleteLocalRef(value);
  return result;
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<int>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jint intValue = (int) jsValue->ToNumber(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToIntegerMethodId, intValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<double>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jdouble doubleValue = jsValue->ToNumber(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToDoubleMethodId, doubleValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<float>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jfloat floatValue = (jfloat) jsValue->ToNumber(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToFloatMethodId, floatValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<long>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jlong longValue = (jlong) jsValue->ToNumber(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToLongMethodId, longValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}



template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<short>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jshort shortValue = (jshort) jsValue->ToNumber(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToShortMethodId, shortValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<bool>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  jboolean booleanValue = (jboolean) jsValue->ToBoolean(context).ToLocalChecked()->Value();
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToBooleanMethodId, booleanValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<signed char>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::String::Utf8Value utf8Parameter(jsValue);
  std::string value(*utf8Parameter);
  jchar charValue = value[0];
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToCharacterMethodId, charValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<char>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::String::Utf8Value utf8Parameter(jsValue);
  std::string value(*utf8Parameter);
  jchar charValue = value[0];
  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToCharacterMethodId, charValue);
  CheckExceptionAndClear(jniEnv);
  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jobjectArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  int* intArray = new int[length];
  jintArray javaIntArray = jniEnv->NewIntArray(length);
  for (int i = 0; i < length; ++i) {
    intArray[i] = JsJavaInterface::ExtractJavaIdentifier(context, array->Get(context, i).ToLocalChecked());
  }
  jniEnv->SetIntArrayRegion(javaIntArray, 0, length, intArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToArrayMethodId, javaIntArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaIntArray);
  delete[] intArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jobjectArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue, v8::Local<v8::Value> classNameValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  int* intArray = new int[length];
  jintArray javaIntArray = jniEnv->NewIntArray(length);
  for (int i = 0; i < length; ++i) {
    intArray[i] = JsJavaInterface::ExtractJavaIdentifier(context, array->Get(context, i).ToLocalChecked());
  }
  jniEnv->SetIntArrayRegion(javaIntArray, 0, length, intArray);

  jstring className = nullptr;
  if (classNameValue->IsString()) {
    v8::String::Utf8Value utf8ClassName(classNameValue);
    className = jniEnv->NewStringUTF(*utf8ClassName);
  }

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToArrayMethodId, javaIntArray, className);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaIntArray);
  delete[] intArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}


template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jbyteArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jbyte* nativeArray = new jbyte[length];
  jbyteArray javaArray = jniEnv->NewByteArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetByteArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToByteArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jshortArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jshort* nativeArray = new jshort[length];
  jshortArray javaArray = jniEnv->NewShortArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetShortArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToShortArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jintArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jint* nativeArray = new jint[length];
  jintArray javaArray = jniEnv->NewIntArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetIntArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToIntArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jfloatArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jfloat* nativeArray = new jfloat[length];
  jfloatArray javaArray = jniEnv->NewFloatArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetFloatArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToFloatArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jdoubleArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jdouble* nativeArray = new jdouble[length];
  jdoubleArray javaArray = jniEnv->NewDoubleArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetDoubleArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToDoubleArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jlongArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jlong* nativeArray = new jlong[length];
  jlongArray javaArray = jniEnv->NewLongArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Number::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetLongArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToLongArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<jbooleanArray>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jboolean* nativeArray = new jboolean[length];
  jbooleanArray javaArray = jniEnv->NewBooleanArray(length);
  for (int i = 0; i < length; ++i) {
    nativeArray[i] = v8::Boolean::Cast(*(array->Get(context, i).ToLocalChecked()))->Value();
  }
  jniEnv->SetBooleanArrayRegion(javaArray, 0, length, nativeArray);

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToBooleanArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);
  delete[] nativeArray;

  return JsJavaInterface::CreateJavaScriptObject(result);
}

template<>
v8::Local<v8::Value> JsObjectConverter::ConvertToJava<std::string>(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue) {
  JNIEnv* jniEnv = SpContext::GetInstance()->GetJniEnvironment();
  v8::Array* array = v8::Array::Cast(*jsValue);
  int length = array->Length();

  jclass stringClazz = jniEnv->FindClass("java/lang/String");
  jstring empty = jniEnv->NewStringUTF("");
  jobjectArray javaArray = jniEnv->NewObjectArray(length, stringClazz, empty);
  jniEnv->DeleteLocalRef(stringClazz);
  jniEnv->DeleteLocalRef(empty);
  for (int i = 0; i < length; ++i) {
    v8::String::Utf8Value str(array->Get(context, i).ToLocalChecked());
    jstring jStr = jniEnv->NewStringUTF(*str);
    jniEnv->SetObjectArrayElement(javaArray, i, jStr);
    jniEnv->DeleteLocalRef(jStr);
  }

  int result = jniEnv->CallStaticIntMethod(jObjectConversions, ToStringArrayMethodId, javaArray, nullptr);
  CheckExceptionAndClear(jniEnv);

  jniEnv->DeleteLocalRef(javaArray);

  return JsJavaInterface::CreateJavaScriptObject(result);
}