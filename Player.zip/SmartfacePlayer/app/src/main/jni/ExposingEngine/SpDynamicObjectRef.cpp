#include "../headers/ExposingEngine/SpDynamicObjectRef.h"
#include "../headers/ExposingEngine/SpJSFunctionsPlugins.h"
#include "Core/SpBrString.h"
#include "Core/SpApplication.h"
#include "Core/SpBrBase.h"
#include "SPJavaScript/SpJSCommon.h"
#include "Core/SpLog.h"
#include "Core/SpBrNuiFactory.h"
#include <algorithm>
#include <string>

#include "SpClass/SharedJSObject.h"

using namespace v8;

#define V8Begin() \
    lock_guard<recursive_mutex> lock (smf_v8_isolate_lock); \
    SpJsEngineReady (); \
    Locker __isolatelock__ (smf_v8_isolate); \
    Isolate::Scope __isolate__ (smf_v8_isolate); \
    HandleScope __handles__ (smf_v8_isolate); \
    Context::Scope __context__ (smf_v8_global_context.Get (smf_v8_isolate))

extern recursive_mutex smf_v8_isolate_lock;
extern Isolate* smf_v8_isolate;
extern Persistent<Context> smf_v8_global_context;

SpDynamicObjectRef::SpDynamicObjectRef()
{
    jsObjectRef = SpJsNullObject;
    isPluginObject = true;
}

SpDynamicObjectRef::~SpDynamicObjectRef()
{
    JNIEnv* env =  SpContext::GetInstance()->GetJniEnvironment();
    SpBrObject *dynamicObject = (SpBrObject *)SpJsGetPrivate(jsObjectRef);
    env->DeleteGlobalRef(dynamicObject->objectRef);
}

SpJsObject SpDynamicObjectRef::GetJSObjectRef()
{
    return jsObjectRef;
}

SpDynamicObjectBase::SpDynamicObjectBase()
{

}

SpDynamicObjectBase::~SpDynamicObjectBase()
{
}