/*
 * SpBrCryptoUtility.h
 *
 *  Created on: Sep 5, 2011
 *      Author: ugurkilic
 */

#ifndef SPBRCRYPTOUTILITY_H_
#define SPBRCRYPTOUTILITY_H_

#include "SpDefs.h"

#define MD5HexOutputLength  32
#define SHA1HexOutputLength 40

class SpBrString;

class SpBrCryptoUtility {
public:
	SpBrCryptoUtility();
	virtual ~SpBrCryptoUtility();

public:
    static SpBrString* GetSha(TShaType type, const char *data, int len);
    static SpBrString* GetMD5(const char *data, int len);
};

#endif /* SPBRCRYPTOUTILITY_H_ */
