#ifndef __SPNETWORKOBJECT_H__
#define __SPNETWORKOBJECT_H__

class SpNetworkObject {

};

#endif