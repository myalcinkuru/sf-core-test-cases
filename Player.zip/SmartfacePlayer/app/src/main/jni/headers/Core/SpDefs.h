#ifdef __APPLE__
#include <TargetConditionals.h>
#endif

#ifdef TARGET_PLATFORM_ANDROID
#include <android/log.h>
#endif

#include <iostream>
#include <string>

#ifndef __SPDEFS_H_
#define __SPDEFS_H_

#ifdef SPRAT_LOGGING
#define ACTIONEVENT_LOGGING
//#undef ACTIONEVENT_LOGGING
#define LOG_TO_FILE
#undef LOG_TO_FILE
#endif

//TODO clean up this mess here
//#define DEBUG_JSSCHEDULER 1
//#define RUN_EVENTS_SYNCHRONOUSLY_IN_JSSCHEDULER 1  //This shouldn't be defined, but currently the player wouldn't work very well without it
#define USE_SYNC_ALL 1 //Run synchronously even if using JSScheduler
//#define ANDROID_RUN_EVENTS_ON_MAIN_THREAD 1

#define DEBUG_ONDRAW 1
#undef DEBUG_ONDRAW

// note: this is not about debug functionality
#define DEVELOPER_DEBUGGING
#undef SPRAT_DEBUGGING

// for android ndk debugging
#define NDKDEBUG
#undef NDEBUG

#define ON_MEMORY_DB_DEV
//#undef ON_MEMORY_DB_DEV

#if defined(SMARTFACE_IOS_EMULATOR) || defined(TARGET_ANDROID_EMULATOR_RELEASE)
    #define SMARTFACE_EMULATOR
#endif

#ifdef DEBUGGER_PLAYER
#define LOG_NETWORK_TO_FILE
#endif

const char kPathSeparator =
#ifdef _WIN32
                            '\\';
#else
                            '/';
#endif

const std::string ANDROID_PACKAGE_NAME("io.smartface.SmartfaceDev");
const std::string ANDROID_DATA_PATH("/storage/emulated/0/Android/data/");

#define TARGET_PLATFORM_WINDOWS
#undef TARGET_PLATFORM_WINDOWS

#define ANDROID_INIT_TIME_BUFFER 10
#undef ANDROID_INIT_TIME_BUFFER

#define SMFEXPORT __attribute__ ((visibility ("default")))

#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
    #include "IOS/SPDefsIOS.h"

    #define SMF_USING_SSL

    #undef DEBUG_JSSCHEDULER
    #undef RUN_EVENTS_SYNCHRONOUSLY_IN_JSSCHEDULER

    #define TARGET_PLATFORM_IOS

    #define SPRAT_LOGGING
    #define ACTIONEVENT_LOGGING

    #if defined __arm__ || defined __thumb__ || defined __arm64__
        #define TARGET_PLATFORM_IOS_DEVICE
    #else
        #define TARGET_PLATFORM_IOS_SIMULATOR
    #endif

    #ifdef DEVELOPER_DEBUGGING
        #undef DEBUGGER_PLAYER
    #endif

	#ifdef IOS_PLAYER
        #undef SPRAT_LOGGING
        #undef DEVELOPER_DEBUGGING
        #undef ACTIONEVENT_LOGGING
        #undef DEBUGGER_PLAYER
		#ifdef LOG_NETWORK_TO_FILE
        	#undef LOG_NETWORK_TO_FILE
		#endif
    #endif
    #ifdef SMARTFACE_IOS_EMULATOR
        #undef DEVELOPER_DEBUGGING
        //#define DEBUGGER_PLAYER
		#ifdef LOG_NETWORK_TO_FILE
        	#undef LOG_NETWORK_TO_FILE
		#endif
    #endif
#elif _WIN32
    #define TARGET_PLATFORM_WINDOWS
 	#define TARGET_PLATFORM_ANDROID
	#define snprintf sprintf_s
	#define GL_GLEXT_PROTOTYPES
#else
    #define GL_GLEXT_PROTOTYPES
    #undef DEVELOPER_DEBUGGING
#endif

#ifdef TARGET_ANDROID_PLAYER_RELEASE
    #ifdef ACTIONEVENT_LOGGING
        #undef ACTIONEVENT_LOGGING
    #endif
	#ifdef LOG_NETWORK_TO_FILE
		#undef LOG_NETWORK_TO_FILE
	#endif
#elif defined(TARGET_ANDROID_EMULATOR_RELEASE)
    #ifdef ACTIONEVENT_LOGGING
        #undef ACTIONEVENT_LOGGING
    #endif
	#ifndef DEBUGGER_PLAYER
		#define DEBUGGER_PLAYER
	#endif
	#ifdef LOG_NETWORK_TO_FILE
		#undef LOG_NETWORK_TO_FILE
	#endif
#endif

#ifdef NULL
#undef NULL
#endif

#define NULL 0

#define HTTP_CONNECTION_TIMEOUT 30

typedef enum {
    VATop = 0,
    VAMiddle,
    VABottom
} TVerticalAlign;

typedef enum {
    HALeft = 0,
    HACenter,
    HARight
} THorizontalAlign;

typedef enum {
    STSha160,
    STSha224,
    STSha256,
    STSha384,
    STSha512
} TShaType;

typedef enum {
    FSNormal,
    FSBold,
    FSItalic,
    FSBoldItalic,
} TFontStyle;

typedef enum {
    PENone,
    PEAccelerating,
    PEDecelerating,
    PEPlain,
    PEAccelerateAndDecelerate,
    PEBounce
} TPageEffectEase;

typedef enum {
    AAODeviceOrientationUnknown = 0x01,
    AAODeviceOrientationPortrait = 0x02,
    AAODeviceOrientationUpsideDown = 0x04,
    AAODeviceOrientationLandscapeRight = 0x08,
    AAODeviceOrientationLandscapeLeft = 0x10,
    AAODeviceOrientationFaceUp = 0x20,
    AAODeviceOrientationFaceDown = 0x40
} TApplicationAllowedOrientation;

typedef enum {
    TRPurchased,
    TRRestored,
    TRKeyInvalid,
    TRUserCancelled,
    TRGenericError
} TTransactionResult;

typedef enum {
	GVTPixel,
	GVTPercent,
	GVTDp,
	GVTPunto,
} GeometryValueTypes;

typedef enum {
	THMGet,
	THMPost,
	THMPut,
	THMDelete,
} THttpMethod;

typedef enum {
	TLTDemo,
	TLTCommunity,
	TLTFull,
    TLTIndividual,
    TLTCommercial,
    TLTEnterprise
} TLicenceType;

typedef enum {
    AppCTCall,
    AppCTCallBack
} AppCallType;

typedef enum {
    NTLocal,
    NTRemote
} NotificationType;

typedef enum {
    IOSTRead,
    IOSTWrite,
    IOSTAppend
} IOStreamType;

typedef enum {
    IOAPApplicationDataDirectory,
    IOAPApplicationCacheDirectory,
    IOAPApplicationImages,
    IOAPApplicationTemporaryData,
    IOAPExternalStroges,
    IOAPApplicationAssets,
} IOApplicationPath;

typedef enum {
    FTAssests,
    FTResources
} FType;

typedef enum {
    TINYXML_DOCUMENT = 0,
    TINYXML_ELEMENT = 1,
    TINYXML_COMMENT = 2,
    TINYXML_UNKNOWN = 3,
    TINYXML_TEXT = 4,
    TINYXML_DECLARATION = 5,
    TINYXML_TYPECOUNT = 6
} TiXmlNodeTypes;

#define KTrue                               "true"

#define KDefaultWebTimeOutValue             60

#define KSpYES                              "1"
#define KAppActive                          "0"
#define KAppInactive                        "1"
#define KAppBackground                      "2"

extern const char *kSmfAccessibilityIdentifierKey;

#ifndef _WINRT_DLL
    #define SMARTFACE_MUTEX pthread_mutex_t
    #define SMARTFACE_MUTEX_INIT(lockmutex) pthread_mutex_init(&lockmutex,NULL)
    #define SMARTFACE_MUTEX_DESTROY(lockmutex) pthread_mutex_destroy(&lockmutex)
    #define SMARTFACE_MUTEX_LOCK(lockmutex) pthread_mutex_lock(&lockmutex)
    #define SMARTFACE_MUTEX_UNLOCK(lockmutex) pthread_mutex_unlock(&lockmutex)
#else
    #define SMARTFACE_MUTEX std::mutex
    #define SMARTFACE_MUTEX_INIT(lockmutex)
    #define SMARTFACE_MUTEX_DESTROY(lockmutex)
    #define SMARTFACE_MUTEX_LOCK(lockmutex) lockmutex.lock()
    #define SMARTFACE_MUTEX_UNLOCK(lockmutex) lockmutex.unlock()
#endif

#endif
