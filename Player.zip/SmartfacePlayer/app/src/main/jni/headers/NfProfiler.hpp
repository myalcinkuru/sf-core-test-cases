#ifndef __NFPROFILER_HPP__
#define __NFPROFILER_HPP__

#include "Core/SpLog.h"

#include <chrono>
#include <string>
#include <map>

class NfProfiler {
public:
    NfProfiler(std::string name) : name(name) {
        start = std::chrono::high_resolution_clock::now();
        if (NfProfiler::total.find(name) == NfProfiler::total.end()) {
            NfProfiler::total[name] = 0;
        }
    }

    ~NfProfiler() {
        std::chrono::duration<double, std::milli> diff = 
                std::chrono::high_resolution_clock::now() - start;
                
        NfProfiler::total[name] += diff.count();
        splog(SPDEB, "[PROFILING]", "%s Took: %f ms\t\tTotal: %f", name.c_str(), diff.count(), 
                NfProfiler::total[name]);
    }
private:
    std::string name;
    std::chrono::time_point<std::chrono::high_resolution_clock> start;
    static std::map<std::string, double> total;
};

#endif //__NFPROFILER_HPP__