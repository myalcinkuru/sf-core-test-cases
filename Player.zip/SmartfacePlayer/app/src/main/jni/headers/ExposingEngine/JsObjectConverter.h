#ifndef __JSOBJECTCONVERTER_H__
#define __JSOBJECTCONVERTER_H__

#define BOOLEAN 0
#define BYTE 1
#define CHARACTER 2
#define DOUBLE 3
#define FLOAT 4
#define INTEGER 5
#define LONG 6
#define SHORT 7
#define CLASS 8
#define STRING 9
#define METHOD 10

#include <jni.h>
#include "v8.h"

class JsObjectConverter {
public:
  static void Initialize(JNIEnv* env);

  template<typename T>
  static v8::Local<v8::Value> ConvertToJava(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue);
  
  template<typename T>
  static v8::Local<v8::Value> ConvertToJava(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue, v8::Local<v8::Value> classNameValue);

  template<typename T>
  static v8::Local<v8::Value> ConvertToJs(v8::Local<v8::Context> context, v8::Isolate* isolate, v8::Local<v8::Value> jsValue);
    
private:
  static JNIEnv* jniEnv;

  static jclass jObjectConversions;

  static jmethodID ToPrimitiveStringMethodId;
  static jmethodID ToIntegerMethodId;
  static jmethodID ToDoubleMethodId;
  static jmethodID ToFloatMethodId;
  static jmethodID ToLongMethodId;
  static jmethodID ToShortMethodId;
  static jmethodID ToBooleanMethodId;
  static jmethodID ToCharacterMethodId;
  static jmethodID ToStringMethodId;
  static jmethodID ToArrayMethodId;
  static jmethodID ToByteArrayMethodId;
  static jmethodID ToShortArrayMethodId;
  static jmethodID ToIntArrayMethodId;
  static jmethodID ToFloatArrayMethodId;
  static jmethodID ToDoubleArrayMethodId;
  static jmethodID ToLongArrayMethodId;
  static jmethodID ToBooleanArrayMethodId;
  static jmethodID ToStringArrayMethodId;
};

#endif // __JSOBJECTCONVERTER_H__