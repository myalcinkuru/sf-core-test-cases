//
// Created by nosaiba on 22/11/16.
//
#include "SpJsEngine/Core/SpJsEngine.h"

#ifndef SMF_FUNCTIONS_PLUGINS_H
#define SMF_FUNCTIONS_PLUGINS_H

extern std::map<std::string,SpJsObject> dynamicJSClassObjects;

void cb_requireClass(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_int(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_double(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_float(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_long(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_short(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_bool(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_byte(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_char(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_string(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_array(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_toJSArray(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_arrayLength(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_delete(const v8::FunctionCallbackInfo<v8::Value>& info);

void cb_implement(const v8::FunctionCallbackInfo<v8::Value>& info);
void cb_extend(const v8::FunctionCallbackInfo<v8::Value>& info);

template<typename>
void cb_numberConverter(const v8::FunctionCallbackInfo<v8::Value>& info);

#endif //SMF_GIT_SPJSFUNCTIONSPLUGINS_H
