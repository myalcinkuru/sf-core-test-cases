#ifndef SPDYNAMICOBJECTREF_H_
#define SPDYNAMICOBJECTREF_H_


#include <string>
#include <vector>
#include <map>
#include "Core/SpDefs.h"
#include "Core/SpBrObject.h"

#ifdef TARGET_PLATFORM_ANDROID
#include <jni.h>
#endif

#include <SpJsEngine/Core/SpJsEngine.h>

class SpBrString;

class SpDynamicObjectBase{
public:
    SpDynamicObjectBase();
    ~SpDynamicObjectBase();

    static bool jsValueToJava(SpJsValue& theValue, const char* expectedType, jvalue* dest);
};

class SpDynamicObjectRef : public SpBrObject, public SpDynamicObjectBase{
public:
    SpDynamicObjectRef();
    ~SpDynamicObjectRef();
    SpJsObject GetJSObjectRef ();
};


#endif /* SPDYNAMICOBJECTREF_H_ */
