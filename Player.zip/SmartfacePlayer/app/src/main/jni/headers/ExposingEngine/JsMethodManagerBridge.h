#ifndef __JSMETHODMANAGERBRIDGE_H__
#define __JSMETHODMANAGERBRIDGE_H__

#include <jni.h>
#include "v8.h"

class JsMethodManagerBridge {
public:
  static void Initialize(JNIEnv* env);
  /**
   *  This function creates a JavaScript function holding method identifier and object identifier
   *  as its internals. When created JavaScript function is invoked from JavaScript code,
   *  JsMethodManagerBridge::Callback function is called.
   */
  static v8::Local<v8::Value> CreateJavaScriptMethod(v8::Isolate* isolate, int objectId, int methodId);

  /**
   *  V8 callback for exposed Java methods.
   */
  static void Callback(const v8::FunctionCallbackInfo<v8::Value>& info);

private:
  static JNIEnv* jniEnv;
  static jclass jMethodManager;
  static jclass jClassManager;

  static jmethodID invokeMethodId;
  static jmethodID getTypeMethodId;
};

#endif //__JSMETHODMANAGERBRIDGE_H__