#ifndef __JSJAVAINTERFACE_H__
#define __JSJAVAINTERFACE_H__

#include <jni.h>
#include <map>
#include <string>
#include "v8.h"

#define EXCHANGEVALUE_TYPE_INT 2
#define EXCHANGEVALUE_TYPE_FLOAT 3
#define EXCHANGEVALUE_TYPE_DOUBLE 4
#define EXCHANGEVALUE_TYPE_LONG 5
#define EXCHANGEVALUE_TYPE_BOOLEAN 6
#define EXCHANGEVALUE_TYPE_OBJECT 7
#define EXCHANGEVALUE_TYPE_BYTEARRAY 8
#define EXCHANGEVALUE_TYPE_SHORTARRAY 9
#define EXCHANGEVALUE_TYPE_INTARRAY 10
#define EXCHANGEVALUE_TYPE_FLOATARRAY 11
#define EXCHANGEVALUE_TYPE_DOUBLEARRAY 12
#define EXCHANGEVALUE_TYPE_LONGARRAY 13
#define EXCHANGEVALUE_TYPE_BOOLEANARRAY 14
#define EXCHANGEVALUE_TYPE_OBJECTARRAY 15
#define EXCHANGEVALUE_TYPE_STRING 16
#define EXCHANGEVALUE_TYPE_STRINGARRAY 17

class JsJavaInterface {
public:
  static void Initialize(JNIEnv* jniEnv);

  static v8::Local<v8::Value> RequireClass(const std::string& name);
  static void ConstructorCallback(const v8::FunctionCallbackInfo<v8::Value>& info); 
  static void GetPropertyCallback(v8::Local<v8::Name> property,
                                  const v8::PropertyCallbackInfo<v8::Value>& info);
  static void SetPropertyCallback(v8::Local<v8::Name> property,
                                  v8::Local<v8::Value> value,
                                  const v8::PropertyCallbackInfo<v8::Value>& info);
  static void InvokeMethod(const v8::FunctionCallbackInfo<v8::Value>& info);

  /**
   *  Creates JavaScript object with given class identifier set as internal to it.
   */
  static v8::Local<v8::Object> CreateJavaScriptObject(int classId);

  static int ExtractJavaIdentifier(v8::Local<v8::Context> context, v8::Local<v8::Value> jsObject);
  static int ExtractJavaIdentifier(v8::Local<v8::Object> jsObject);

  static jobject ConvertToJavaType(v8::Local<v8::Value> value, v8::Local<v8::Context> context, v8::Isolate* isolate);
  static v8::Local<v8::Value> ConvertToJSType(jobject object, v8::Local<v8::Context> context, v8::Isolate* isolate);
  static v8::Local<v8::Value> ConvertToJSArray(jobject object, v8::Local<v8::Context> context, v8::Isolate* isolate);
    

  static void DeleteJavaObject(v8::Local<v8::Object> value);
private:
  static jclass JsObjectCollection;
  static jmethodID AddMethodID;
  static jmethodID RemoveMethodID;

  static JNIEnv* jniEnv;
  static jclass JavaJsInterface;
  static jmethodID RequireClassMethodID;
  static jmethodID ConstructObjectMethodID;
  static jmethodID GetPropertyMethodID;
  static jmethodID SetPropertyMethodID;
  static jmethodID InvokeMethodMethodID;
  static jmethodID GetMessageMethodID;

  static jclass ExchangeValue;
  static jmethodID ExchangeValueConstructorMethodID;
  static jmethodID GetElementIdByIndexMethodID;
  static jfieldID ByteValueFieldID;
  static jfieldID ShortValueFieldID;
  static jfieldID IntValueFieldID;
  static jfieldID FloatValueFieldID;
  static jfieldID DoubleValueFieldID;
  static jfieldID LongValueFieldID;
  static jfieldID BooleanValueFieldID;
  static jfieldID ObjectIdFieldID;
  static jfieldID ByteArrayFieldID;
  static jfieldID ShortArrayFieldID;
  static jfieldID IntArrayFieldID;
  static jfieldID FloatArrayFieldID;
  static jfieldID DoubleArrayFieldID;
  static jfieldID LongArrayFieldID;
  static jfieldID BooleanArrayFieldID;
  static jfieldID StringValueFieldID;
  static jfieldID StringArrayFieldID;
  static jfieldID ObjectArrayFieldID;
  static jfieldID TypeFieldID;

  static std::map<std::string, v8::Global<v8::Value>> classCache;
  static v8::Global<v8::ObjectTemplate> classTemplate;
  static bool initializedTemplate;

  static void CreateClassTemplate(v8::Isolate* isolate);
};

#endif