#ifndef __JSCLASSMANAGERBRIDGE_H__
#define __JSCLASSMANAGERBRIDGE_H__

#include <jni.h>
#include <map>
#include <string>
#include "v8.h"

/**
 *  This class is a bridge between JsClassManager (io.smartface.ExposingEngine.JsClassManager) and
 *  JavaScript. It helps generating JavaScript ObjectTemplates as a representation of Java classes.
 *  By using cache it is designed to be as fast as possible. 
 */
class JsClassManagerBridge {
public:
  /**
   *  Initializes required members for further usages. This method should be invoked before using
   *  other methods.
   */
  static void Initialize(JNIEnv* env);

  /**
   *  Returns JavaScript representation of Java class which name is specified with className
   *  parameter. If class is not found on runtime undefined will be returned.
   *
   *  @pre className Class name is expected in Java notation (e.g. java.lang.Integer)
   */
  static v8::Local<v8::Value> GetClass(const std::string& className);

  /**
   *  Creates JavaScript object with given class identifier set as internal to it.
   */
  static v8::Local<v8::Object> CreateJavaScriptClass(int classId);

  /**
   *  This is V8 constructor callback for JavaScript classes returned as representation of Java
   *  classes. It is called when JavaScript object, returned from GetClass, is called as constructor
   *  with new operator.
   */
  static void ConstructorCallback(const v8::FunctionCallbackInfo<v8::Value>& info);

  /**
   *  This is V8 get property callback for JavaScript classes returned as representation of Java
   *  classes. It is called when a property is requested from JavaScript objec (returned from 
   *  GetClass). To return the value of the requested property, it asks Java runtime then converts
   *  retrieved result to JavaScript object and returns it.
   */
  static void GetPropertyCallback(v8::Local<v8::Name> property,
    const v8::PropertyCallbackInfo<v8::Value>& info);

private:
  static std::map<std::string, v8::Global<v8::Value>> classCache;
  static JNIEnv* jniEnv;
  static bool initializedTemplate;

  static jclass jClassManager;
  static jclass jObjectCollection;

  static jmethodID getClassMethodId;
  static jmethodID getPropertyMethodId;
  static jmethodID getTypeMethodId;
  static jmethodID getMethodId;

  static v8::Global<v8::ObjectTemplate> classTemplate;

  static void CreateClassTemplate(v8::Isolate* isolate);
  static int GetClassFromNative(const std::string& className);
};

#endif //__JSCLASSMANAGERBRIDGE_H__